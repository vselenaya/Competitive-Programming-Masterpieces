from math import factorial, ceil

def C(n, m):
    c = ceil(factorial(n) // (factorial(m) * factorial(n - m)) / 2)
    return max(1, c)

n, k = int(input()), int(input())

a = 0
if k >= n:
    a = n
else:
    a = k

b = 0
if k >= n:
    b = k - n
else:
    b = 0 

sum_d = 0

while a >= b:
    sum_d += C(n, a) + C(n, b)
    a -= 1
    b += 1

print(sum_d)