#include <iostream>
#include <vector>
#include <string>
#include <cmath>

int main() {
	int n, d = 0, max = 0, j=0;
	int size, temp = 0, tempTrue=0, stack = 0;
	std::cin >> size;
	std::vector<int> arr;
	std::vector<int> arr2;
	for (int i = 0; i < size; i++)
	{
		std::cin >> n;
		arr.push_back(n);
	}
	arr2 = arr;

	for (int i = 0; i < size; i++)
		if (arr[i] > max)
			max = arr[i];

	while (true)
	{
		for (int i = 0; i < arr.size(); i++) {
			if (arr[i] - stack <= d)
			{
				stack = arr[i];
				arr.erase(arr.begin() + i);
				i--;
				temp++;
			}
		}
		if (temp == tempTrue)
		{
			d++;
			stack = 0;
			temp = tempTrue = 0;
			arr = arr2;
		}
		else {
			if (temp == size)
			{
				break;
			}
			else {
				tempTrue = temp;
			}
		}
		j++;
		if (d == j) {
			d = 0;
			break;
		}
	}

	

	std::cout << d;
}