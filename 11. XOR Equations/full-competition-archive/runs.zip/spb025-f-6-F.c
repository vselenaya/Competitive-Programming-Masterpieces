#include <stdio.h>
#include <math.h>



int main(void){

    int pos = 0;
    int neg = 0;
    int i;
    int j;
    int k;
    int arr[3000] = {0};
    int len;

    float A, D;

    int d;
    float P;
    scanf("%d %f", &d, &P);
    for (i=0;i<d;i++)
        scanf("%d", &arr[i]);

    for (i=0;i<d-2;i++){
        for (j=i+2;j<d;j++){
            len = (j-i+1);
            A = (arr[j]-arr[i])/(len-1.0);

            D = 0;
            for (k=1;k<len;k++){
                D += (arr[i+k]-arr[i+k-1] - A) * (arr[i+k]-arr[i+k-1] - A);
            }

            D = sqrt(D/(len-1.0));

            if (A == 0.0)
                continue;
            if (D == 0.0) {
                if (A > 0)
                    pos += 1;
                else
                    neg += 1;
            }

            else {
                if (A/D >= P)
                    pos +=1;
                else {
                    if (A/D <= -P)
                        neg += 1;

                }

            }



        }

    }
    printf("%d %d", pos, neg);

    return 0;
}
