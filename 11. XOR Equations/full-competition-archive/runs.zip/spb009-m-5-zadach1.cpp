#include <iostream>
#include <vector>
#include <string>
#include <cmath>
#include <cstdlib>

int compare(const void* x1, const void* x2)
{
	return (*(int*)x1 - *(int*)x2);
}

int main() {
	int n, d, a,b,c;
	int size, stack = 0;
	std::cin >> size;
	int* array = new int[size];
	for (int i = 0; i < size; i++)
		std::cin >> array[i];

	qsort(array, size, sizeof(int), compare);
	

	a = array[1] - array[0];
	c = a + 1;
	for (int i = 1; i < size-1; i++)
	{
		b = array[i + 1] - array[i];
		if (b <= c) {
			a = b;
			d = a;
			c = a + 1;
		}
		else {
			d = 0;
			break;
		}
	}
	std::cout << d;
}