#include <iostream>
#include <string>
#include <math.h>
using namespace std;
int main()
{
  int N;
  cin>>N;
  int t=int(sqrt(N));
  for(int i=1;i<=t;i++)
  for(int j=1;j<=t;j++)
      if(i*i+j*j==N)
      {
          cout<<"0 0\n"<<i<<" "<<j<<"\n"<<i-j<<" "<<i+j<<"\n"<<-1*j<<" "<<i<<"\n";
                 return 0;
      }
  cout<<"Impossible\n";
}
