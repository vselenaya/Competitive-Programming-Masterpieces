#include "iostream"
#include "map"

int main()
{
    int s;
    std::cin >> s;
    int good_a = -1, good_b;
    for (int a = 1;a <= 1000;a++)
    {
        for (int b = 0;a * a + b * b <= s;b++)
        {
            if (a * a + b * b == s)
            {
                good_a = a;
                good_b = b;
            }
        }
    }
    if (good_a == -1)
    {
        std::cout << "Impossible";
        return 0;
    }

    std::pair<int, int> dots[4];
    dots[0] = std::make_pair(0, 0);
    dots[1] = std::make_pair(good_a, good_b);
    dots[2] = std::make_pair(-good_b, good_a);
    dots[3] = std::make_pair(-good_b + good_a, good_a + good_b);

    for (int i = 0;i < 4;i++)
    {
        std::cout << dots[i].first << " " << dots[i].second << std::endl;
    }
}