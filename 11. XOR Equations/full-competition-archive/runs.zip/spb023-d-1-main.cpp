#include <bits/stdc++.h>

using namespace std;

#ifdef DEBUG
ifstream in("input");
#define cin in
#else
#define endl '\n'
#endif

#define EPS 0.000000001

void fast_io() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  cout.setf(ios::fixed);
  cout.precision(20);
}

int n, w, h, s;
char best_ch;
string target = "#.";
int max_sw = 0;

int get_substr(const string &s) {
  int num = 0;
  size_t pos = 0;
  while ((pos = s.find(target, pos)) != std::string::npos) {
    ++num;
    pos += target.length();
  }
  return num;
}

void get_ch() {
  char ch;
  cin >> ch;
  string s;
  for (int i = 0; i < h; ++i) {
    cin >> s;
    s += '.';
    int switches = get_substr(s) * 2;
    if (switches > max_sw) {
      best_ch = ch;
      max_sw = switches;
    }
  }
}

void get_ch();

void solve() {
  // amin'
  cin >> n >> w >> h >> s;
  for (; n--;) {
    get_ch();
  }
  for (int i = 0; i < ceil(s * 1.0 / max_sw); ++i) {
    cout << best_ch;
  }
}

int main() {
  fast_io();
  solve();
  return 0;
}