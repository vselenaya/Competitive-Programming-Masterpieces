#include <iostream>
#include <iomanip>
#include <cmath>
#include <algorithm>
#include <set>
#include <iterator>
using namespace std;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    long long n;
    cin >> n;
    string a;
    while(1)
    {
        for(int i = 0; i < n-1; i++)
        {
            for(int j = i+1; j < n; j++)
            {
                cout << i+1 << " " << j+1 << endl;
                cin >> a;
                if(a == "WIN")
                {
                    return 0;
                }else if(a == "STAYED")
                {
                    break;
                }
            }
        }
    }
}
