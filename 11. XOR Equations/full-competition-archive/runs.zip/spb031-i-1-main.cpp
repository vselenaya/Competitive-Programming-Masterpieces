﻿// Author: Igor Smirnov
#ifdef DEBUG_MODE
#define _GLIBCXX_DEBUG 1
#endif
#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx")
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef unsigned int ui;
typedef unsigned long long ull;

#ifndef CERR_ON
#define cerr if (false) cerr
#endif
#define forn(i, n) for (int i = 0; i < n; ++i)
#define all(a) (a).begin(), (a).end()
#define f first
#define s second
#define mp make_pair
#define pb push_back
#define next next42

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    vector<pii> nxt(1001, mp(-1, -1));
    map<int, int> int2sq;
    forn(i, 1001) {
        int2sq[i] = i;
    }
    forn(a, 1001) {
        forn(b, 1001) {
            int len = a * a + b * b;
            if (int2sq[len] != 0) {
                nxt[int2sq[len]] = {a, b};
            }
        }
    }
    int s;
    cin >> s;
    if (nxt[s] == mp(-1, -1)) {
        cout << "Impossible\n";
    }
    else {
        auto [a, b] = nxt[s];
        cout << 0 << ' ' << 0 << endl;
        cout << a << ' ' << b << endl;
        cout << a + b << ' ' << b - a << endl;
        cout << b << ' ' << -a << endl;
    }
}