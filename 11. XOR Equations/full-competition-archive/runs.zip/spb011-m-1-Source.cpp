#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
	int n, card, d;
	int temp;
	vector<int> cards;
	vector<int> div;
	vector<int> div1;
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> card;
		cards.push_back(card);
	}
	sort(cards.begin(), cards.end());
	/*for (auto el : cards) {
		cout << el << " ";
	}
	cout << endl;*/
	for (int i = 1; i < n; i++) {
		temp = cards[i] - cards[i - 1];
		div.push_back(temp);
	}
	
	int maxVal = *max_element(div.begin(), div.end());
	/*for (auto el : div) {
		cout << el << " ";
	}*/
	//cout << maxVal << endl;
	for (int i = 1; i < n -1; i++) {
		temp = cards[i + 1] - cards[i - 1];
		div1.push_back(temp);
	}

	for (auto el : div1) {
		if (el <= maxVal) {
			cout << 0;
			//system("pause");
			return 0;
		}
	}
	cout << maxVal;
	//system("pause");
	return 0;
}