#include <bits/stdc++.h>
//#define FAST_ALLOCATOR_MEMORY 2e8
//#include "optimization.h"
using namespace std;

#define int long long
#define double long double
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
mt19937 rnd(chrono::high_resolution_clock::now().time_since_epoch().count());

struct query {
    int a, b, c;
};

vector<int> bad, bsame;
const int N = 2e5 + 47;
multiset<pair<int, int>> g[N];
vector<query> q;

void no() {
    cout << "No";
    exit(0);
}

signed main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    cout << fixed << setprecision(20);
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    int n, start;
    cin >> n >> start;
    q.resize(n);
    for(auto& i : q) {
        cin >> i.a >> i.b >> i.c;
    }

    vector<int> t = {start};
    for(auto& i : q) {
        t.push_back(i.a);
        t.push_back(i.b);
    }
    sort(all(t));
    t.erase(unique(all(t)), t.end());
    start = lower_bound(all(t), start) - t.begin();
    for(auto& i : q) {
        i.a = lower_bound(all(t), i.a) - t.begin();
        i.b = lower_bound(all(t), i.b) - t.begin();
    }

    for(int i = 0; i < n; ++i) {
        if (q[i].c) g[q[i].a].insert({q[i].b, i});
        else if (q[i].a == start) bsame.push_back(i);
        else bad.push_back(i);
    }

    vector<pair<int, int>> st;
    st.push_back({start, -1});
    vector<int> ans;
    while(!st.empty()) {
        int u = st.back().first;
        int idx = st.back().second;
        if(g[u].empty()) {
            ans.push_back(idx);
            st.pop_back();
        } else {
            st.push_back(*g[u].begin());
            g[u].erase(g[u].begin());
        }
    }
    ans.pop_back();
    reverse(ans.begin(), ans.end());

    int cnt = ans.size();
    for(int i = 0; i < ans.size(); ++i) {
        if(q[ans[i]].a != start) {
            cnt = i;
            break;
        }
    }

    for(auto& i : g) {
        if(!i.empty()) no();
    }

    vector<int> res;
    for(auto& i : bad) res.push_back(i);
    for(int i = 0; i < cnt; ++i) res.push_back(ans[i]);
    for(auto& i : bsame) res.push_back(i);
    for(int i = cnt; i < ans.size(); ++i) {
        res.push_back(ans[i]);
    }
    for(auto& i : res) {
        if((start == q[i].a) == q[i].c) {
            if(start == q[i].a) start = q[i].b;
        } else no();
    }
    cout << "Yes\n";
    for(auto& i : res) cout << i + 1 << ' ';
}