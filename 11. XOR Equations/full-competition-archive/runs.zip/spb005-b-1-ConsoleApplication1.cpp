﻿#include <iostream>
#include <vector>
#include<string>
#include<set>
#include<cmath>
#include<map>
#include<algorithm>

using namespace std;

int main()
{
	int a, b, x, y,t,tt;
	cin >> a >> x >> b >> y >> tt;
	if (tt < 30)t = 30;
	else t = tt;
	cout << a + ((t - 30) * x) * 21 << " ";
	if (tt < 45)t = 45;
	else t = tt;
	cout<< b + ((t - 45) * y)*21;
}

