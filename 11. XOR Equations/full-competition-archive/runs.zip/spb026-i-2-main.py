#
import math

if __name__ == '__main__':
    sq=list()
    for i in range(0, 1000):
        sq.append(i*i)
    # print (sq)
    s=int(input())
    flag=0
    for a in range(s+1):
        if (a in sq and flag==0):
            for b in range(s+1):
                # print(a,b)
                if   (a*a+b*b)==s:
                    print (-1000,-1000+a)
                    print (-1000+b,-1000)
                    print (-1000+a+b,-1000+b )
                    print(-1000+a,-1000+a+b)
                    flag=1
                    break
        if (flag==1):
            break
    if (flag==0):
        print("Impossible")
