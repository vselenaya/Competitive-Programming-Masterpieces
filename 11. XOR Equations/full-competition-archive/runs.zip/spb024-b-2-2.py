a = int(input())
x = int(input())
b = int(input())
y= int(input())
T = int(input())
p1 = 21 * (T - 30) * x
p2 = 21 * (T - 45) * y
if (p1 < 0):
    p1 = 0
if (p2 < 0):
    p2 = 0

print(a + p1, b + p2) 
