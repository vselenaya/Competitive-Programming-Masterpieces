package com.company;

import javafx.util.Pair;

import java.util.*;

public class Main {

    public static LinkedList<Integer> V = new LinkedList<>(), notV = new LinkedList<>();
    public static long v;
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt(); v = sc.nextLong();
        HashMap<Long,LinkedList<Pair<Long,Integer>>> map = new HashMap<>();
        for(int i = 0; i < n; i++){
            long a = sc.nextLong(), b = sc.nextLong(), w = sc.nextLong();
            if(w == 1){
                Pair<Long, Integer> pair = new Pair<>(b,i + 1);
                if(!map.containsKey(a))
                {
                    LinkedList<Pair<Long, Integer>> list = new LinkedList<>();
                    list.add(pair);
                    map.put(a, list);
                }
                else map.get(a).add(pair);
            }else{
                if(a != v)
                    notV.add(i +1);
                else
                    V.add(i + 1);
            }
        }
        if(map.get(v) != null){
        long c = map.get(v).get(0).getKey();
        LinkedList<Integer> res = new LinkedList<>();
        res.addAll(notV);
        res = checkAll(c, map, res, n, map.get(v).get(0), v);
        if(res.size() == n){
            System.out.println("Yes");
            res.forEach(x -> System.out.print(x + " "));
        }
        else System.out.println("No");
        }else System.out.println("No");

    }
    static LinkedList<Integer> checkAll(long c, HashMap<Long,LinkedList<Pair<Long, Integer>>> map,LinkedList<Integer> res, int n, Pair<Long, Integer> pair, long last){
        res.add(pair.getValue());
        map.get(last).remove(pair);
        if(c != v && res.size() == notV.size() + 1)
            res.addAll(V);

        if(map.get(c) != null && res.size() <= n){
            for (Pair<Long, Integer> it: map.get(c)) {
                res = checkAll(it.getKey(), map, res, n, it, c);
                if(res.size() == n)
                    return res;
            }
        }
        return res;
    }
}