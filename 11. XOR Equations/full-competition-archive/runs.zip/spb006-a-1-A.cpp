#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
typedef long double ld;

#define pb push_back
#define forn(i, n) for (int i = 0; i < (int)(n); i++)
#define forrn(i, s, n) for (int i = (int)(s); i < (int)(n); i++)
#define PYMOD(a, m) ((((a) % (m)) + (m)) % (m))
#define all(v) v.begin(), v.end()
#define rall(v) v.rbegin(), v.rend()
#define mp make_pair
#define ff first
#define ss second

const string winners[] = {
    "ITMO",
    "SPbSU",
    "SPbSU",
    "ITMO",
    "ITMO",
    "SPbSU",
    "ITMO",
    "ITMO",
    "ITMO",
    "ITMO",
    "ITMO",
    "PetrSU, ITMO",
    "SPbSU",
    "SPbSU",
    "ITMO",
    "ITMO",
    "ITMO",
    "ITMO",
    "SPbSU",
    "ITMO",
    "ITMO",
    "ITMO",
    "ITMO",
    "SPbSU",
    "ITMO"
};

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    // Code here:

    int y;
    cin >> y;
    cout << winners[y - 1995] << endl;

    return 0;
}
