import math

s = int(input())
if math.sqrt(s) % 1 == 0:
    print (0, 0)
    print (0, int(math.sqrt(s)))
    print (int(math.sqrt(s)), 0)
    print (int(math.sqrt(s)), int(math.sqrt(s)))
else:
    for i in range(1, s):
        if math.sqrt(i) % 1 == 0 and math.sqrt(s - i) % 1 == 0:
            print (0, int(math.sqrt(i)))
            print (int(math.sqrt(s-i)), 0)
            print (int(math.sqrt(i)), int(math.sqrt(s-i)+ math.sqrt(i)))
            print (int(math.sqrt(s-i) + math.sqrt(i)), int(math.sqrt(s - i)))
            break
    else:
        print('Impossible')
        
