#include <iostream>
#include <string>
#include <math.h>
using namespace std;
int main()
{
  int N;
  cin>>N;
  int t=int(sqrt(N));
  if(t*t==N)t--;
  for(int i=t;i>0;i--)
  {
      int s=N-i*i;
      int j=int(sqrt(s));
      if(j*j==s){cout<<"0 0\n"<<i<<" "<<j<<"\n"<<i-j<<" "<<i+j<<"\n"<<-j<<" "<<i<<"\n";return 0;}
  }
  cout<<"Impossible\n";
}
