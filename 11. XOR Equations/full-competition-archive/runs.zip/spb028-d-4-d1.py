n, w, h, s = [int(x) for x in input().split()]
ch=[]
array = [[]]*n
a = []
for i in range(n):
    ch.append(input())
    for j in range(h):
        x=0
        pr = input()
        if pr[0]=="#": x += 1
        if pr[w-1]=="#": x += 1
        x = x + pr.count(".#") + pr.count("#.")
        a.append(x)
    array[i]=a
    a=[]
ind = 0
r=0
mama = max(max(array))
for i in range(n):
    for j in range(h):
        if array[i][j]==mama:
            ind = i
            r=1
            break
    if r==1: break
cnt = s//mama
if ((cnt*mama)!=s): cnt+=1
ans = ''
for i in range(cnt):
    ans += ch[ind]
print(ans)