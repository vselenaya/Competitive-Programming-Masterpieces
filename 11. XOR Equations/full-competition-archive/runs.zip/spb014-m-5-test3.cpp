
#include <iostream>
#include <cassert>

using namespace std;

int main()
{
    long long count;
    cin >> count;
    long long* array = new long long[count];

    for (long long i = 0; i < count; i++)
        cin >> array[i];

    long long temp, current = 0, min = 0;

    for (long long i = 0; i < count - 1; ++i)
    {
        for (long long j = 0; j < count - 1; ++j)
        {
            if (array[j + 1] < array[j])
            {
                temp = array[j + 1];
                array[j + 1] = array[j];
                array[j] = temp;
            }
        }
    }

    min = array[0];
    long long tempgap, gap = min;

    for (long long i = 0; i < count - 1; i++) {
        tempgap = array[i + 1] - array[i];
        if (tempgap > gap)
            gap = tempgap;
    }

    bool p = false;

    for (long long i = 1; i < gap; i++) {
        if (array[i] <= gap)
            p = true;
        else
            break;
    }

    if ((array[0] > gap) || p)
        cout << "0";
    else
        cout << gap;

    return 0;
}