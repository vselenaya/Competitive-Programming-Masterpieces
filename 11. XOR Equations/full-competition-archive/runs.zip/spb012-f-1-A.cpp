#include <algorithm>
#include <bitset>
#include <cstdlib>
#include <iostream>
#include <random>
#include <set>
#include <vector>

// #define FAST_ALLOCATOR_MEMORY 256000000
// #include "optimization.h"
#include <bits/stdc++.h>

using namespace std;

// #define USE_INT128
// #define int int64_t

// #undef _DEBUG

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()

#ifdef USE_INT128
#define lint __int128
#define ulint __int128
#else
#define lint int64_t
#define ulint int64_t
#endif

typedef long double ld;
#define f first
#define s second
typedef pair<int, int> pint;

const int inf = 1 << 30;

template <class T>
T mineq(T& a, const T& b) {
    return a = min(a, b);
}

template <class T>
T maxeq(T& a, const T& b) {
    return a = max(a, b);
}

mt19937 rd(533);
// end of default file

int32_t main() {
    // srand(5332017);
    ios::sync_with_stdio(false);
    cin.tie();
    cout.tie();
    cout << fixed;
    cout.precision(4); // !!

#ifdef _DEBUG
    freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
#else
    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
#endif

    int d;
    ld P;
    cin >> d >> P;
    vector<ld> c(d);
    for (auto& i : c) cin >> i;

    const int n = d - 1;
    vector<ld> b(n);
    for (int i = 0; i < d - 1; i++) {
        b[i] = c[i + 1] - c[i];
    }

    int p_cnt = 0;
    int n_cnt = 0;

    const ld eps = 1e-10;

    for (int l = 0; l < n; l++) {
        ld s1 = 0;
        ld s2 = 0;

        for (int r = l; r < n; r++) {
            // s1 += b[r];
            s1 = c[r + 1] - c[l];
            s2 += b[r] * b[r];

            int len = r - l + 1;
            if (len >= 2) {
                ld A = s1 / len;
                ld A2 = A * A;
                ld D2 = (s2 - 2 * A * s1 + A2 * len) / len;

                if (D2 < eps * eps) {
                    if (A > eps)
                        p_cnt++;
                    if (A < -eps)
                        n_cnt++;
                } else {
                    ld ad2 = A2 / D2;
                    if (ad2 > (P - eps) * P) {
                        if (A > 0)
                            p_cnt++;
                        else
                            n_cnt++;
                    }
                }
            }

            #ifdef _DEBUG
            cerr << l << ' ' << r << ' ' << p_cnt << ' ' << n_cnt << '\n';
#endif
        }
    }

    cout << p_cnt << ' ' << n_cnt << endl;

    return 0;
}
