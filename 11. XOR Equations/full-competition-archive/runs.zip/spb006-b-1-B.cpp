#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
typedef long double ld;

#define pb push_back
#define forn(i, n) for (int i = 0; i < (int)(n); i++)
#define forrn(i, s, n) for (int i = (int)(s); i < (int)(n); i++)
#define PYMOD(a, m) ((((a) % (m)) + (m)) % (m))
#define all(v) v.begin(), v.end()
#define rall(v) v.rbegin(), v.rend()
#define mp make_pair
#define ff first
#define ss second

int count(int a, int m, int x, int t) {
    if (t <= m)
        return a;
    return a + (t - m) * x * 21;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    // Code here:

    int a, x, b, y, t;
    cin >> a >> x >> b >> y >> t;

    cout << count(a, 30, x, t) << " " << count(b, 45, y, t) << endl;

    return 0;
}
