#include <iostream>

using namespace std;

int main()
{
int n, a, b, x, mx = 0, vmx = 0;
char ms[100], ans, s;
cin >> n >> a >> b >> x;
for (int i = 0; i < n; i++)
{
cin >> s;
for(int j = 0; j < b; j++)
{
vmx = 0;
ms[0] = '.';
ms[a+1] = '.';
for(int f = 1; f <= a; f++)
{
cin >> ms[f];
}
for(int f = 0; f <= a; f++)
{
if (ms[f] != ms[f + 1]) vmx++;
}
if (vmx >= mx)
{
mx = max(mx, vmx);
ans = s;
}
}
}
// cout � mx � endl;
int pr = mx;
while (mx <= x)
{
cout << ans;
mx += pr;
}
if (mx - x < pr) cout << ans;
return 0;
}
