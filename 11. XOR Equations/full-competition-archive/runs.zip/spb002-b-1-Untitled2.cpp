#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    long long a, b, x, y, t;
    cin >> a >> x >> b >> y >> t;
    long long z = 0;
    long long ans1, ans2;
    ans1 = max(t-30, z)*x*21+a;
    ans2 = max(t-45, z)*y*21+b;
    cout << ans1 << " " << ans2 << endl;
}
