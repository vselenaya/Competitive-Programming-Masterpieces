#include <iostream>

using namespace std;

int main() {
	int n;
	bool ok = false;
	cin >> n;
	int i = 0,j = 0;
	for (i = 0 ; i < n; i++ ){
        if (i*i > n){
            break;
        }
	}
	for (; i >= 0; i--) {
		for (; j <= i; j++) {
			if (i * i + j * j > n) {
				break;
			}
			if (i * i + j * j == n) {
				ok = true;
				break;
			}
		}
		if (ok) break;
	}
	if (ok)
    {
		cout << 0 << " " << 0 << endl;
		cout << i << " " << j << endl;
		cout << -j << " " << i << endl;
		cout << i - j << " " << i + j << endl;
	}
	else
        cout << "Impossible";
	return 0;
}
