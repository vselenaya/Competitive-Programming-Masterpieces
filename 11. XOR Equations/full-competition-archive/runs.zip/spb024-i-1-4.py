s = int(input())

so = 1
k = 1

while (s > so):
    k = k + 1
    so = k * k

val = 0

if (k * k == s):
    print(0, 0)
    print(k, 0)
    print(k, k)
    print(0, k)
else:
    for i in range(0, k+1):
        if (((k - i)**2 + i * i) == s) or (i*i == s):
            val = i
            break

    if (val == 0):
        print("Impossible")
    else:
        print(0, k-i)
        print(k-i, k)
        print(k, i)
        print(i, 0)
