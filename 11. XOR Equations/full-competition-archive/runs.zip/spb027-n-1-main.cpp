#include <iostream>
#include <string>
#include <unordered_map>
using namespace std;
int main()
{
  long long pow[100];
  unsigned long long bin[100][100];
  pow[0] = 1;
  for(int i = 1; i<=50; i++)
  {
    pow[i] = pow[i-1]*2;
  }
  for(int i = 0; i<=50; i++)
  {
    bin[0][i] = 0;
    bin[i][0] = 1;
  }
  for(int i = 1; i<=50; i++)
  {
    for(int j = 1; j<=50; j++)
    {
      bin[i][j] = bin[i-1][j] + bin[i-1][j-1];
    }
  }
  int n,k;
  unsigned long long ans = 0;
  cin >> n >> k;
  if(k>n)k=n-k;
  for(int i = 0; i<=k; i++)
  {
    if(k%2==0 && i==k/2)
    {
      if(n%2==0 && i%2==0)
      {
        ans+=(bin[n][i]-bin[n/2][i/2]);
        ans+=bin[n/2][i/2]*2;
      }
      if(n%2==0 && i%2!=0)
      {
        ans+=bin[n][i];
      }
      if(n%2==1 && i%2==0)
      {
        ans+=(bin[n][i]-bin[n/2][i/2]);
        ans+=bin[n/2][i/2]*2;
      }
      if(n%2==1 && i%2==1)
      {
        ans+=(bin[n][i]-bin[n/2][i/2]);
        ans+=bin[n/2][i/2]*2;
      }      
    }
    else 
    {
      if(n%2==0 && i%2==0)
      {
        ans+=(bin[n][i]-bin[n/2][i/2])/2;
        ans+=bin[n/2][i/2];
      }
      if(n%2==0 && i%2!=0)
      {
        ans+=bin[n][i]/2;
      }
      if(n%2==1 && i%2==0)
      {
        ans+=(bin[n][i]-bin[n/2][i/2])/2;
        ans+=bin[n/2][i/2];
      }
      if(n%2==1 && i%2==1)
      {
        ans+=(bin[n][i]-bin[n/2][i/2])/2;
        ans+=bin[n/2][i/2];
      }
    }
  }
  cout << ans << endl;
  
}
