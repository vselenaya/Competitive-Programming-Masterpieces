#include <iostream>
#include <iomanip>
#include <cmath>
#include <algorithm>
#include <set>
#include <iterator>
using namespace std;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    long long n, w, h, s;
    char a;
    cin >> n >> w >> h >> s;
    char q;
    long long maxSw = 0;
    char ind;
    for(int i = 0; i < n; i++)
    {
        cin >> a;
        for(int j = 0; j < h; j++)
        {
            char flag, prev_flag;
            long long sw = 0;
            cin >> flag;
            prev_flag = flag;
            if(flag == '#')
            {
                sw++;
            }
            for(int k = 1; k < w; k++)
            {
                cin >> flag;
                if(flag != prev_flag)
                {
                    sw++;
                }
                prev_flag = flag;
            }
            if(flag == '#')
            {
                sw++;
            }
            if(sw > maxSw)
            {
                maxSw = sw;
                ind = a;
            }
        }
    }
    long long ans;
    if(s % maxSw == 0)
    {
        ans = s/maxSw;
    }else{
        ans = s/maxSw + 1;
    }
    for(int i = 0; i < ans; i++)
    {
        cout << ind;
    }
    cout << endl;
}
