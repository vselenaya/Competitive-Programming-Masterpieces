﻿
#include <iostream>
#include <vector>

int main()
{
    //Вектор с годами
    std::vector <int> Year
    { 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019};  
    
    //Вектор с университетами
    std::vector <std::string> University
    { "ITMO","SPbSU","SPbSU","ITMO","ITMO","SPbSU","ITMO","ITMO","ITMO","ITMO","ITMO","PetrSU, ITMO","SPbSU","SPbSU","ITMO","ITMO","ITMO","ITMO","SPbSU","ITMO","ITMO","ITMO","ITMO","SPbSU","ITMO" };

    int number;
    //вводим год
    std::cin >> number;

    //проходим по вектору с годами
    for (int i = 0; i < Year.size(); i++) {
        //если находим такой год то выводим Университет с таким же порядковым номером в листе
        if (number == Year[i]) {
            std::cout << University[i] << "\n";
            break;
        }
    }
}




















