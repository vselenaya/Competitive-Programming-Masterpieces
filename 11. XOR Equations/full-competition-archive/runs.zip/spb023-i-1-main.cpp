#include <bits/stdc++.h>

using namespace std;

#ifdef DEBUG
ifstream in("input");
#define cin in
#else
#define endl '\n'
#endif

#define EPS 0.000000001

void fast_io() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  cout.setf(ios::fixed);
  cout.precision(20);
}

bool is_sqrted(double s) {
  int no_point = sqrt(s);
  return abs(sqrt(s) - (double)no_point) < EPS;
}

int a, b;

bool is_summed(int s) {
  int tmpa = 1, tmpb = 1;
  int skv;
  for (; tmpa * tmpa + tmpb * tmpb <= s; ++tmpa) {
    for (tmpb = tmpa; true; ++tmpb) {
      skv = tmpa * tmpa + tmpb * tmpb;
      if (skv == s) {
        a = tmpa;
        b = tmpb;
        return true;
      } else if (skv > s) {
        break;
      }
    }
  }
  return false;
}

void solve() {
  // amin'
  double s;
  cin >> s;
  if (is_sqrted(s)) {
    int sqr = sqrt(s);
    cout << 0 << ' ' << 0 << endl
         << 0 << ' ' << sqr << endl
         << sqr << ' ' << sqr << endl
         << sqr << ' ' << 0 << endl;
  } else if (is_summed(s)) {
    cout << 0 << ' ' << a << endl
         << a << ' ' << a + b << endl
         << a + b << ' ' << b << endl
         << b << ' ' << 0 << endl;
  } else {
    cout << "Impossible" << endl;
  }
}

int main() {
  fast_io();
  solve();
  return 0;
}