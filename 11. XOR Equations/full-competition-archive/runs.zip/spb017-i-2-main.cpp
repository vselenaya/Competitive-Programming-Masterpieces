#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int n,s,f;
    cin >> n;
    bool ok = false;
    for (int i = 1; i < n ; i++)
    {
        if (sqrt(n - i) - ceil(sqrt(n - i)) == 0 && sqrt(i) - ceil(sqrt(i)) == 0)
        {
            s = sqrt(n - i);
            f = sqrt(i);
            break;
        }
        else{
            ok = true;
        }
    }
    if (ok){
        cout << "Impossible";
        return 0;
    }
    cout << 0 << " " << f << endl;
    cout << s << " " << 0 << endl;
    cout << f << " " << -s << endl;
    cout << f - s << " " << -s + f << endl;
    return 0;
}
