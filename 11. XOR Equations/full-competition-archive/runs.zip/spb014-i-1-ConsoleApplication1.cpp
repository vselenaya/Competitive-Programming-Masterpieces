﻿#include <iostream>;

using namespace std;

bool IsPosbl(int s, int &n) {
	int start = 5;
	int i = 2;
	do {
		n = i - 1;
		if (s == start)
			return true;
		else if (s < start)
			return false;
		start += 4 * i++;
	} while (true);
}

int main() {
	int s;
	int n;
	int &ref = n;
	cin >> s;
	double sq = sqrt(s);
	if (sq == (long long)sq) {
		cout << "0 0" << endl;
		cout << "0 " << sq << endl;
		cout << sq << " 0" << endl;
		cout << sq << " " << sq << endl;
	}	
	else if (IsPosbl(s, ref)){
		cout << s - 3 * n << " " << s - n << endl;
		cout << s - 2 * n << " " << s - 3 * n << endl;
		cout << s - n << " " << s << endl;
		cout << s << " " << s - 2 * n << endl;
	}
	else {
		cout << "Impossible";
	}
	return 0;
}