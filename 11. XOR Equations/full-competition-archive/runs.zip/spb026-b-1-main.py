#
if __name__ == '__main__':
    # a,x,b,y,t
    a=int(input())
    x=int(input())
    b=int(input())
    y=int(input())
    t=int(input())
    sum1=a+21*(t -30)*x
    sum2 = b + 21 * (t - 45)*y
    print(sum1,sum2)