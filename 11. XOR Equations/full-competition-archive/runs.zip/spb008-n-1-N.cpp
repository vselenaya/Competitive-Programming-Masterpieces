#include <iostream>

unsigned long long part_f(unsigned long long a, unsigned long long b)
{
    return (a != b) ? a * part_f(a - 1, b) : 1;
}

using namespace std;

int main()
{
    short int n, k;
    cin >> n >> k;
    unsigned long long sum = 0;
    for (short int a = (k / n) ? n : k, b = (k / n) ? k % n : 0; a > b; a--, b++)
    {
        sum += part_f(n, n - a) + part_f(n, n - b);
    }
    if (sum == 0)
        sum = 2;
    cout << sum;
}