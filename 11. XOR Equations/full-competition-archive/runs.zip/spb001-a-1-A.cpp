#include <bits/stdc++.h>

using namespace std;

unordered_map<int, string> ht;

int main() {

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    ht[1995] = "ITMO";
    ht[1996] = "SPbSU";
    ht[1997] = "SPbSU";
    ht[1998] = "ITMO";
    ht[1999] = "ITMO";
    ht[2000] = "SPbSU";
    ht[2001] = "ITMO";
    ht[2002] = "ITMO";
    ht[2003] = "ITMO";
    ht[2004] = "ITMO";
    ht[2005] = "ITMO";
    ht[2006] = "PetrSU, ITMO";
    ht[2007] = "SPbSU";
    ht[2008] = "SPbSU";
    ht[2009] = "ITMO";
    ht[2010] = "ITMO";
    ht[2011] = "ITMO";
    ht[2012] = "ITMO";
    ht[2013] = "SPbSU";
    ht[2014] = "ITMO";
    ht[2015] = "ITMO";
    ht[2016] = "ITMO";
    ht[2017] = "ITMO";
    ht[2018] = "SPbSU";
    ht[2019] = "ITMO";
    int n;
    cin >> n;
    cout << ht[n];
}
