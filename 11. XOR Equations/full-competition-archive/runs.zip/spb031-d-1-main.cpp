﻿// Author: Igor Smirnov
#ifdef DEBUG_MODE
#define _GLIBCXX_DEBUG 1
#endif
#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx")
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef unsigned int ui;
typedef unsigned long long ull;

#ifndef CERR_ON
#define cerr if (false) cerr
#endif
#define forn(i, n) for (int i = 0; i < n; ++i)
#define all(a) (a).begin(), (a).end()
#define f first
#define s second
#define mp make_pair
#define pb push_back
#define next next42

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int n, w, h, s;
    cin >> n >> w >> h >> s;
    int best_ans = INT_MAX;
    char bans = '0';
    vector<pair<char, vector<int>>> strs;
    forn(i, n) {
        char c;
        cin >> c;
        forn(j, h) {
            string st;
            cin >> st;
            st = "." + st + ".";
            int ch = 0;
            forn(i, st.size()) {
                if (i == 0) continue;
                if (st[i] != st[i - 1]) {
                    ch++;
                }
            }
            if (ch != 0) {
                int nans = s / ch + min(s % ch, 1);
                if (nans < best_ans) {
                    best_ans = nans;
                    bans = c;
                }
            }
        }
    }
    forn(i, best_ans) {
        cout << bans;
    }
    cout << '\n';
}