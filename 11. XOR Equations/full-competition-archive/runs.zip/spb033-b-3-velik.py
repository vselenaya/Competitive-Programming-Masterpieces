def set_price():
    price = int(input())
    while (price >= 100) and (price <= 0):
        price = int(input())
    return price


a = set_price()
x = set_price()
b = set_price()
y = set_price()
T = int(input())
while (T >= 1440) and (T <= 1):
    T = int(input())

spend_list = []
spend_a = 0
spend_b = 0
# Option 'a', 30 min
if T <= 30:
    spend_a = a
    spend_list.append(spend_a)
else:
    spend_a = a + ((T - 30) * x)*21
    spend_list.append(spend_a)

# Option 'b', 45 min
if T <= 45:
    spend_b = b
    spend_list.append(spend_b)
else:
    spend_b = b + ((T - 45) * y)*21
    spend_list.append(spend_b)

print(f'{spend_list[0]} {spend_list[1]}')
