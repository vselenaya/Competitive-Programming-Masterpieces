#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <string>
using namespace std;
#define ll long long
#define FOR(i,a,b) for(int i=a;i<b;i++)

vector<pair<int, int>> ans;
void quickSort(vector <int> arr, int left, int right) {
	int i = left, j = right;
	int tmp;
	int pivot = arr[(left + right) / 2];

	while (i <= j) {
		while (arr[i] < pivot)
			i++;
		while (arr[j] > pivot)
			j--;
		if (i <= j) {
			tmp = arr[i];
			arr[i] = arr[j];
			arr[j] = tmp;
			ans.push_back(make_pair(i+1, j+1));
			i++;
			j--;
		}
	};

	if (left < j)
		quickSort(arr, left, j);
	if (i < right)
		quickSort(arr, i, right);

}

int main()
{
	ll n;
	string str;
	cin >> n;

	vector<int> Arr(n);
	FOR(i, 0, n)
	{
		Arr[i] = (n - i);
	}
	quickSort(Arr, 0, n - 1);
	
	int ind = 0;
	cout << ans[ind].first << " " << ans[ind].second << "\n";
	while (1) {
		cin >> str;
		if (str == "WIN")
			break;
		if (str == "SWAPPED")
		{
			cout << ans[++ind].first << " " << ans[++ind].second << "\n";
		}
		if (str == "STAYED")
		{
			cout << ans[++ind].first << " " << ans[++ind].second << "\n";
		}
	}

	//system("pause");
	return 0;
}