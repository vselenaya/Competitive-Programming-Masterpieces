#include <bits/stdc++.h>

using namespace std;

#ifdef DEBUG
ifstream in("input");
#define cin in
#else
#define endl '\n'
#endif

#define EPS 0.000000001

void fast_io() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  cout.setf(ios::fixed);
  cout.precision(20);
}

int n;
vector<int> v;
const int inf = 1e9 + 5;

void solve() {
  // amin'
  cin >> n;
  v.resize(n + 1);
  v[0] = 0;
  for (int i = 1; i <= n; ++i)
    cin >> v[i];
  sort(begin(v), end(v));
  int max_dist = -1;
  int dist_when_collision = inf;
  for (auto it = begin(v); it + 1 != end(v); ++it) {
    int el2 = (it + 2 == end(v) ? -1 : *(it + 2));
    int el1 = *(it + 1);
    int el = *it;
    max_dist = max(max_dist, el1 - el);
    dist_when_collision =
        min(dist_when_collision, (el2 == -1 ? inf : el2 - el));
  }
  if (max_dist >= dist_when_collision) {
    cout << 0 << endl;
  } else
    cout << max_dist << endl;
}

int main() {
  fast_io();
  solve();
  return 0;
}