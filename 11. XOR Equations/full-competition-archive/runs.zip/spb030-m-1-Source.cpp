#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;
#define ll long long
int main()
{
	ll n;
	cin >> n;
	vector<ll> Vec(n+1,0);
	for (ll i = 1; i <= n; i++)
	{
		cin >> Vec[i];
	}
	sort(Vec.begin(), Vec.end());
	ll nMin = -1;
	ll nMax = -1;
	for (ll i = 0; i <= n - 2; i++)
	{
		ll left = Vec[i + 1] - Vec[i];
		ll right = Vec[i + 2] - Vec[i];
		if (nMin == -1 || nMin < left)
			nMin = left;
		if (nMax == -1 || nMax > right)
			nMax = right;
	}
	if (nMax - nMin <= 1)
		cout << 0 << "\n";
	else
		cout << nMin + 1 << "\n";
	//system("pause");
	return 0;
}