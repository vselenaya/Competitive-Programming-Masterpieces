zz=input().split()
n=int(zz[0])
c=int(zz[1])
s=""
exit=False
ans=[[0 for i in range(n)] for j in range(2)]
for i in range(n):
    zzz=input().split()
    if int(zzz[2])==0:
        ans[0][i]=-int(zzz[0])
    else:
        ans[0][i]=int(zzz[0])
        ans[1][i]=int(zzz[1])
a_check=[False for i in range(n)]
def reverse(cc, s):
    global exit
    global a_check
    if exit==True:
        return s
    for i in range(n):
        if a_check[i]==1:
            continue
        ccc=cc
        if cc==ans[0][i]:
            cc=ans[1][i]
        elif (cc==-ans[0][i]) or ((ans[0][i]>0) and (cc!=ans[0][i])):
            continue
        ss=s
        a_check[i]=True
        s+=str(i+1)+" "
        if a_check.count(False)==0:
            exit=True
            return s
        s=reverse(cc, s)
        if exit==True:
            return s
        a_check[i]=False
        s=ss
        cc=ccc
    return "No"
s=reverse(c, s)
if s=="No":
    print(s)
else:
    print("Yes")
    print(s)       

        
        