#include <iostream>
#include <vector>
#include <string>
#include <cmath>

int main() {
	int a;
	std::string arr[] = { "ITMO", "SPbSU", "SPbSU", "ITMO", "ITMO", "SPbSU", "ITMO", "ITMO", "ITMO", "ITMO", "ITMO", "PetrSU, ITMO", "SPbSU", "SPbSU", "ITMO", "ITMO", "ITMO", "ITMO", "SPbSU", "ITMO", "ITMO", "ITMO", "ITMO", "SPbSU", "ITMO"};
	std::cin >> a;
	a = a - 1995;
	std::cout << arr[a];
}