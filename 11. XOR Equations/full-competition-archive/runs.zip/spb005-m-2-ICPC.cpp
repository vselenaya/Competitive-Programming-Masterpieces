﻿#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
int main()
{
    int n;
    cin >> n;
    long temp;
    vector<long> a,b,c;
    for (int i = 0; i < n; i++) {
        cin >> temp;
        a.push_back(temp);
    }
    a.push_back(0);
    sort(a.begin(), a.end());
    
    for (int i = 0; i < n; i++) {
        b.push_back(a.at(i + 1) - a.at(i));
        if (i != n-1) c.push_back(a.at(i + 2) - a.at(i));
    }
    vector<long>::iterator max;
    max = max_element(b.begin(), b.end());
    vector<long>::iterator min;
    min = min_element(c.begin(), c.end());
    
    if (*max < *min) {
        cout << *max;
    }
    else {
        cout << 0;
    }
    return 0;
}
