#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
typedef long double ld;
 
mt19937 rnd(time(0));
#define rall(x) (x).rbegin(), (x).rend()
#define all(x) (x).begin(), (x).end()
#define pNN pair <Node *, Node *>
#define SZ(x) (int)(x).size()
#define pii pair <int, int>
#define pb push_back
#define eb emplace_back
#define rev reverse
#define ins insert
#define ers erase
#define S second
#define F first
const int N = 110, INF = 1e9 + 10, M = 1e9 + 7;

void solve() {

    map <int, string> ans;
    ans[1995] = "ITMO";
    ans[1996] = "SPbSU";
    ans[1997]  = "SPbSU";
    ans[1998] = "ITMO";
    ans[1999] = "ITMO";
    ans[2000] = "SPbSU";
    ans[2001] = "ITMO";
    ans[2002] = "ITMO";
    ans [2003] = "ITMO";
    ans[2004] = "ITMO";
    ans[2005] = "ITMO";
    ans[2006] = "PetrSU, ITMO";
    ans[2007] = "SPbSU";
    ans[2008] = "SPbSU";
    ans[2009] = "ITMO";
    ans[2010] = "ITMO";
    ans[2011] = "ITMO";
    ans[2012] =  "ITMO";
    ans[2013] ="SPbSU";
    ans[2014] = "ITMO";
    ans[2015] = "ITMO";
    ans[2016] = "ITMO";
    ans[2017] = "ITMO";
    ans[2018] =  "SPbSU";
    ans[2019] = "ITMO";

int y;
cin >> y;
cout << ans[y] << endl;


}

signed main () {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cout.precision(12);
    #ifdef fleek$
        assert(freopen("input.txt", "r", stdin));
    #endif
    int t = 1;
    //cin >> t;
    while(t--) solve();
    return 0;
}