#include <iostream>
#include <iomanip>
#include <string>
#include <map>
#include <algorithm>
#include <math.h>
#include <vector>
#include <unordered_map>
//#include <fstream>
//#include <cstdio>

using namespace std;

int main()
{
	long n, w, h, s;
	
	//FILE* stream;

	//freopen_s(&stream, "input.txt", "r", stdin);

	cin >> n >> w >> h >> s;

	unordered_map<char, vector<vector<int>>> characters;

	for (int i = 0; i < n; i++)
	{
		char char_symbol;
		cin >> char_symbol;

		vector<vector<int>> symbol(h);
		for (int y = 0; y < h; y++)
		{
			vector<int> line(w);
			for (int x = 0; x < w; x++)
			{
				char ch;
				cin >> ch;
				if (ch == '#')
					line[x] = 1;
				else
					line[x] = 0;
			}
			symbol[y] = line;
		}
		characters[char_symbol] = symbol;
	}

	unordered_map<char, int> price;
	unordered_map<char, int> price_if_not_end;

	for (auto [key, val] : characters)
	{
		vector<int> resource(h);
		vector<int> current_column(h);

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				if (current_column[y] != val[y][x])
					resource[y]++;

				current_column[y] = val[y][x];
			}
		}

		price[key] = *max_element(resource.begin(), resource.end());

		for (int y = 0; y < h; y++)
		{
			if (current_column[y] != 0)
				resource[y]++;
		}

		price_if_not_end[key] = *max_element(resource.begin(), resource.end());
	}




	auto x = max_element(price.begin(), price.end(),
		[](const pair<int, int>& p1,
			const pair<int, int>& p2)
			{ return p1.second < p2.second; });

	auto x_at_end = max_element(price_if_not_end.begin(), price_if_not_end.end(),
		[](const pair<int, int>& p1,
			const pair<int, int>& p2)
		{ return p1.second < p2.second; });

	
	int amount_of_symbols = ceil((double)(s - (long)(x_at_end->second)) / (double)x->second);

	for (int i = 0; i < amount_of_symbols; i++)
		cout << x->first;

	cout << x_at_end->first;

	return 0;
}