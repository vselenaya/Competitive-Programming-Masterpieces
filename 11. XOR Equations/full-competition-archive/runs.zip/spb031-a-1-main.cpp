#ifdef DEBUG_MODE
#define _GLIBCXX_DEBUG 1
#endif
#pragma comment(linker, "/stack:200000000")
#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx")
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

using namespace std;

void solve() {
    int n;
    cin >> n;
    map<int, string> mp = {
            {1995, "ITMO"},
            {1996, "SPbSU"},
            {1997, "SPbSU"},
            {1998, "ITMO"},
            {1999, "ITMO"},
            {2000, "SPbSU"},
            {2001, "ITMO"},
            {2002, "ITMO"},
            {2003, "ITMO"},
            {2004, "ITMO"},
            {2005, "ITMO"},
            {2006, "PetrSU, ITMO"},
            {2007, "SPbSU"},
            {2008, "SPbSU"},
            {2009, "ITMO"},
            {2010, "ITMO"},
            {2011, "ITMO"},
            {2012, "ITMO"},
            {2013, "SPbSU"},
            {2014, "ITMO"},
            {2015, "ITMO"},
            {2016, "ITMO"},
            {2017, "ITMO"},
            {2018, "SPbSU"},
            {2019, "ITMO"},
    };
    cout << mp[n];
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);

#ifdef DEBUG_MODE
    freopen("input.txt", "r", stdin);
#endif

    solve();

    return 0;
}