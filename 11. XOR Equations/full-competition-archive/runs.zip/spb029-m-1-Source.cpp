#include <iostream>
#include <iomanip>
#include <string>
#include <map>
#include <algorithm>
#include <math.h>
#include <vector>

using namespace std;

int main()
{
	long n;
	cin >> n;

	vector<long> a(n + 1);
	a[0] = 0;

	for (int i = 0; i < n; i++)
		cin >> a[i + 1];

	sort(a.begin(), a.end());

	long max1 = -1, min2 = LONG_MAX;
	for (int i = 0; i < a.size() - 1; i++)
	{
		if (a[i + 1] - a[i] > max1)
			max1 = a[i + 1] - a[i];
	}

	for (int i = 0; i < n - 2; i++)
	{
		if (a[i + 2] - a[i] < min2)
			min2 = a[i + 2] - a[i];
	}

	if (max1 < min2)
		cout << max1;
	else
		cout << 0;

	return 0;
}