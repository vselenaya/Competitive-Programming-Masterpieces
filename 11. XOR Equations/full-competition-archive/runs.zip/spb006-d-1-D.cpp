#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
typedef long double ld;

#define pb push_back
#define forn(i, n) for (int i = 0; i < (int)(n); i++)
#define forrn(i, s, n) for (int i = (int)(s); i < (int)(n); i++)
#define PYMOD(a, m) ((((a) % (m)) + (m)) % (m))
#define all(v) v.begin(), v.end()
#define rall(v) v.rbegin(), v.rend()
#define mp make_pair
#define ff first
#define ss second

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    // Code here:

    int n, w, h, s;
    cin >> n >> w >> h >> s;
    char mx = 0;
    int mxa = 0;
    forn(i, n) {
        char c;
        cin >> c;
        forn(j, h) {
            string s;
            cin >> s;
            char cur = '.';
            int cans = 0;
            for (char t : s) {
                if (t != cur)
                    cans++;
                cur = t;
            }
            if (c != '.')
                cans++;
            if (cans > mxa) {
                mx = c;
                mxa = cans;
            }
        }
    }

    int cnt = (s + mxa - 1) / mxa;
    forn(i, cnt)
        cout << mx;
    cout << endl;

    return 0;
}
