#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <map>
#include <string>
#include <sstream>
#include <random>
#include <climits>
#include <iomanip>
#include <queue>
#include <bitset>
#include <cctype>
#include <functional>
#include <complex>
#include <fstream>
#include <unordered_set>
#include <unordered_map>
#include <ctime>
#include <deque>
#include <numeric>
#include <assert.h>
using namespace std;

typedef long long li;

#define forn(i,n) for (li i = 0;i < li(n);i++)
#define ford(i,n) for (li i = li(n)-1;i >=0;i--)
#define fore(i,l,r) for (li i = li(l);i < li(r);i++)
#define forv(v,arr) for (auto& v : (arr))
#define correct(x,n) (((x) >= 0) && ((x) < n))
#define all(a) (a).begin(),(a).end()
#define rnd() (rand() + (RAND_MAX+1)*rand())

//#define x first
//#define y second
//#define x real()
//#define y imag()

using vi = vector<li>;
using vptvi = vector<vi *>;
using pi = pair<li, li>;
using vpi = vector<pi>;
using vvi = vector<vector<li>>;
using vvpi = vector<vpi>;
using ld = long double;
using Point = pair<li, li>;
//using Point = complex<li>;
//using Point = complex<ld>;

void fail()
{
	cout << "No" << endl;
	exit(0);
}

struct Graph
{
	vvpi a;
	vi w;
	li n,m, c;
	map<int, int> num2vertex;
	map<pi, int> edge_num;
	vi fail_edges_c;
	vi fail_edges_not_c;
	vi ans;
	vi ans_vertex;

	int vertex(li val)
	{
		if (!num2vertex.count(val))
		{
			num2vertex[val] = num2vertex.size();
			a.push_back(vpi());
		}
		return num2vertex[val];
	}

	void addEdge(int i)
	{
		int l, r;
		cin >> l >> r >> w[i];
		l = vertex(l);
		r = vertex(r);
		c = vertex(c);
		if (w[i])
		{
			a[l].push_back({ (li)r,(li)i + 1 });
			m++;
		}
		else
			(l == c ? fail_edges_not_c.emplace_back(i + 1) : fail_edges_c.emplace_back(i + 1));
		edge_num[{l, r}] = i + 1;
	}

	Graph()
	{
		cin >> n >> c;
		m = 0;
		w.assign(n,0);
		forn(i, n)
			addEdge(i);
		int k = 0;
		forv(arr, a)
			k += (arr.size() % 2 != 0);
		if (k > 2)
			fail();
	}

	void dfs(int v,int p = -1)
	{
		while (a[v].size())
		{
			int to = a[v].back().first;
			int num = a[v].back().second;
			a[v].pop_back();
			dfs(to,num);
		}
		if (p != -1)
			ans.push_back(p);
		ans_vertex.push_back(v);
	}

	void solve()
	{
		dfs(c);
		if (ans.size() != m)
			fail();
		vi res;
		forv(e, fail_edges_c)
			res.push_back(e);
		bool failed = 0;
		forn(i, m)
		{
			res.push_back(ans[i]);
			if (!failed && ans_vertex[i] != c)
			{
				failed = 1;
				forv(e, fail_edges_not_c)
					res.push_back(e);
			}
		}
		if (!failed)
		{
			if (ans_vertex.back() == c)
				fail();
			forv(e, fail_edges_not_c)
				res.push_back(e);
		}
		cout << "Yes" << endl;
		forv(v, res)
			cout << v << " ";
		cout << endl;
	}
};

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	Graph g;
	g.solve();
}