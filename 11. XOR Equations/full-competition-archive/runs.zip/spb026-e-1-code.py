n , c = input().split()
n, c = int(n),int(c)
mass = []
for i in range(n):
    a, b , w= input().split()
    a, b , w= int(a), int(b), int(w)
    mass.append((a,b, w))

v = c
k = 0
new_mass = []
i = 0
for a,b,w in mass:
    i += 1
    if w == 1:
        if v != a:
            continue
        else:
            new_mass.append([[i],b])
    if w == 0:
        if v  != a:
            new_mass.append([[i], v])
        else:
            continue

for _prov_,v in new_mass:
    i = 0
    for a,b,w in mass:
        i += 1
        if i in _prov_:
            continue
        if w == 1:
            if v != a:
                continue
            else:
                new_mass.append([_prov_ + [i], b])
        if w == 0:
            if v != a:
                new_mass.append([_prov_ + [i], v])
            else:
                continue

if len(new_mass[-1][0]) == n:
    print('Yes')
    for i in new_mass[-1][0]:
        print(i,end=' ')
else:
    print('No')