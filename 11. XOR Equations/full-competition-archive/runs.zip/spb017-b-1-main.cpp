#include <iostream>

using namespace std;

int main()
{
    int a, b, x, y, t, ans1, ans2;
    cin >> a >> x >> b >> y >> t;
    ans1 = (t - 30) * 21 * x + a;
    ans2 = (t - 45) * 21 * y + b;
    if (t <= 30) ans1 = a;
    if (t <= 45) ans2 = b;
    cout << ans1 <<  " " << ans2;
return 0;
}
