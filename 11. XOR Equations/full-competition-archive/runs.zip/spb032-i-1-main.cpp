#include <bits/stdc++.h>

#define V vector<
#define VV vector<vector<
#define VVV vector<vector<vector<
#define for1 for(int i1 = 0; i1 < LIMIT1; i1++)
#define for2 for(int i2 = 0; i2 < LIMIT2; i2++)
#define for3 for(int i3 = 0; i3 < LIMIT3; i3++)
#define for4 for(int i4 = 0; i4 < LIMIT4; i4++)
#define int1 int
#define int2 long long
#define int3 unsigned int
#define int4 unsigned long long
#define SZ size()
#define PUSH push_back
#define POP pop_back

//#define STRESS_TESTING
//#define FILEIO

using namespace std;

bool comp(int a, int b){
    return false;
};

int main(){
    // For variances with determined meaning
    int1 LIMIT1, LIMIT2, LIMIT3, LIMIT4;
    // -------------------------------------
#ifdef STRESS_TESTING
    while(true){
        // Variances for lite solve

        // ---------------------------------
        // Generate

        // ---------------------------------
        // Copy

        // ---------------------------------
        // Lite solve

        // ---------------------------------
#else
    // Input
#ifdef FILEIO
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    long long n;
    cin >> n;
    for(int i = 0; i <=n + 1; i++){
        int ii = i * i;
        int d = n - ii;
        if(d < 0){
            cout << "Impossible" << endl;
            return 0;
        };
        int j = -1;
        for(int ir = 0; ir <=d; ir++) if(ir*ir==d) j = ir;
        if(j!=-1){
            cout << "0 0" << endl;
            cout << -i <<" " << j << endl;
            cout << j-i<<" " << j+i<< endl;
            cout << j << " " << i << endl;
            return 0;
        };
    };
    // -------------------------------------
#endif
    // Solve

    // -------------------------------------
#ifdef STRESS_TESTING
    bool IS_EQUAL = true;
        // Compare

        // ---------------------------------
        if(!IS_EQUAL){
            // Return test

            // -----------------------------
            break;
        };
    };
#else
    // Output

    // -------------------------------------
#endif
    return 0;
};





















/*


#include <bits/stdc++.h>

template <typename T, std::size_t Capacity>
struct MyHeapForSmallTypes{
private:
    [[nodiscard]] bool Comparator(T const &A, T const &B)const{
        return A < B;
    };
    T Data[Capacity]{};
    std::size_t Size = 0;
    [[nodiscard]] std::size_t Parent(std::size_t Vertex)const{
        return (Vertex - 1) / 2;
    };
    enum ParentInfo{
        WeAreLeftChild,
        WeAreRightChild,
        WeAreRoot
    };
    [[nodiscard]] ParentInfo ParentAnalyze(std::size_t Vertex)const{
        if(Vertex == 0) return WeAreRoot;
        if(Vertex % 2 == 1) return WeAreLeftChild;
        return WeAreRightChild;
    };
    enum ChildrenInfo{
        WeHaveTwoChildren,
        WeHaveOneChildren,
        WeHaveNoChildren
    };
    [[nodiscard]] ChildrenInfo ChildrenAnalyze(std::size_t Vertex)const{
        if(2 * Vertex + 1 >= Size) return WeHaveNoChildren;
        if(2 * Vertex + 2 == Size) return WeHaveOneChildren;
        return WeHaveTwoChildren;
    };
    void Swap(std::size_t const A, std::size_t const B){
        T Temp = Data[A];
        Data[A] = Data[B];
        Data[B] = Temp;
    };
    void SiftUp(){
        std::size_t Index = Size - 1;
        while(ParentAnalyze(Index) != WeAreRoot) if(Comparator(Data[Index], Data[Parent(Index)])){
            Swap(Index, Parent(Index));
            Index = Parent(Index);
        };
    };
    void SiftDown(std::size_t Index){
        while(ChildrenAnalyze(Index) != WeHaveNoChildren){
            if(ChildrenAnalyze(Index) == WeHaveOneChildren){
                if(Comparator(Data[2 * Index + 1], Data[Index])) Swap(2 * Index + 1, Index);
                return;
            };
            std::size_t LowerChild = 2 * Index + 1;
            if(Comparator(Data[LowerChild + 1], Data[LowerChild])) LowerChild++;
            if(Comparator(Data[LowerChild], Data[Index])){
                Swap(LowerChild, Index);
                Index = LowerChild;
                continue;
            };
            return;
        };
    };
public:
    [[nodiscard]] std::size_t size()const{
        return Size;
    };
    [[nodiscard]] bool empty()const{
        return Size == 0;
    };
    [[nodiscard]] T const &top()const{
        return Data[0];
    };
    void pop(){
        Data[0] = Data[Size - 1];
        Size--;
        SiftDown(0);
    };
    void push(T const &Element){
        Data[Size] = Element;
        Size++;
        SiftUp();
    };
    explicit MyHeapForSmallTypes(std::vector<T> &Input){
        Size = Input.size();
        for(std::size_t i = 0; i < Size; i++) Data[i] = Input[i];
        if(Size > 0) for(std::size_t i = Size - 1; i + 1; i--) SiftDown(i);
    };
};

int main(){
    std::vector<int> arr;
    MyHeapForSmallTypes<int, 10> a(arr);

    a.push(10);
    a.push(10);
    //std::cout << a.top();
    //a.push(5);
    //std::cout << a.top();
    return 0;
};


*/



/*
#include <bits/stdc++.h>

#define V vector<
#define VV vector<vector<
#define VVV vector<vector<vector<
#define for1 for(int i1 = 0; i1 < LIMIT1; i1++)
#define for2 for(int i2 = 0; i2 < LIMIT2; i2++)
#define for3 for(int i3 = 0; i3 < LIMIT3; i3++)
#define for4 for(int i4 = 0; i4 < LIMIT4; i4++)
#define int1 long long
#define int2 long long
#define int3 unsigned int
#define int4 unsigned long long
#define SZ size()
#define PUSH push_back
#define POP pop_back

//#define STRESS_TESTING
//#define FILEIO

using namespace std;

int1 LIMIT1, LIMIT2, LIMIT3, LIMIT4;

struct xyi{
    int1 capital;
    string town;
    string xyimya;
};

void vxyi(unordered_map<string, xyi> &xyis, vector<pair<string, int1>> &capitals){
    int1 capital;
    string xyimya;
    string town;
    cin >> xyimya >> town >> capital;
    xyi XYI;
    XYI.capital = capital;
    XYI.town = town;
    XYI.xyimya = xyimya;
    xyis[xyimya] = XYI;
    capitals.push_back({town, capital});
};

bool comp(const pair<string, int1>&a,const pair<string, int1>&b){
    return a.second<b.second;
};

int1 zrec(vector<pair<string, int1>>&capitals){
    ...
    return (*it).first;
};

int main(){
    // For variances with determined meaning
    int1 n;
    cin >> n;
    unordered_map<string, xyi> xyis;
    vector<pair<string, int1>>capitalss;
    LIMIT1 = n;
    for1 vxyi(xyis, capitalss);
    sort(capitalss.begin(), capitalss.end());
    vector<pair<string, int1>>capitals(1, capitalss[0]);
    LIMIT1 = capitalss.size()-1;
    for1 if(capitalss[i1].first!=capitalss[i1-1].first) capitals.push_back(capitalss[i1]);else capitals[capitals.size()-1].second+=capitalss[i1].second;
    // -------------------------------------
#ifdef STRESS_TESTING
    while(true){
        // Variances for lite solve

        // ---------------------------------
        // Generate

        // ---------------------------------
        // Copy

        // ---------------------------------
        // Lite solve

        // ---------------------------------
#else
    // Input
#ifdef FILEIO
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    // -------------------------------------
#endif
    // Solve
    int1 m, k;
    cin >> m >> k;
    map<string, int1>rec;
    string str;
    str = zrec(capitals);
    int1 day = 1;
    LIMIT1 = k;
    for1{
        int1 day1;
        string xyima, town;
        cin >> day1 >> xyima >> town;
        int1 l = 0;
        int1 r=capitals.size();
        while(r-l>1){
            int1 m=(l+r)/2;
            if(xyis[xyima].town>=capitals[m].first) l=m;else r=m;
        };
        capitals[l] -= xyis[xyima].capital;
        int1 l = 0;
        int1 r=capitals.size();
        while(r-l>1){
            int1 m=(l+r)/2;
            if(town>=capitals[m].first) l=m;else r=m;
        };
        capitals[l] += xyis[xyima].capital;
        xyis[xyima].town = town;
        rec[str] += day1 + 1 - day;
        day = day1 + 1;
        str = zrec(capitals);
    };
    rec[str] += m + 1 - day;

    // -------------------------------------
#ifdef STRESS_TESTING
    bool IS_EQUAL = true;
        // Compare

        // ---------------------------------
        if(!IS_EQUAL){
            // Return test

            // -----------------------------
            break;
        };
    };
#else
    // Output
    V pair<string,int1> > arrrrr;
for(auto it = rec.begin(); it!=rec.end();it++) if((*it).first!="-"&&(*it).second!=0)arrrrr.push_back(*it);
sort(arrrrr.begin(),arrrrr.end());
LIMIT1 = arrrrr.size();
for1 cout<<arrrrr[i1].first<<' '<<arrrrr[i1].second<<endl;

    // -------------------------------------
#endif
    return 0;
};


*/

/*
#include <bits/stdc++.h>

#define V vector<
#define VV vector<vector<
#define VVV vector<vector<vector<
#define for1 for(int i1 = 0; i1 < LIMIT1; i1++)
#define for2 for(int i2 = 0; i2 < LIMIT2; i2++)
#define for3 for(int i3 = 0; i3 < LIMIT3; i3++)
#define for4 for(int i4 = 0; i4 < LIMIT4; i4++)
#define int1 int
#define int2 long long
#define int3 unsigned int
#define int4 unsigned long long
#define SZ size()
#define PUSH push_back
#define POP pop_back

//#define STRESS_TESTING
//#define FILEIO

using namespace std;

int1 LIMIT1, LIMIT2, LIMIT3, LIMIT4;

struct OneVal{
    int1 Val = 0;
    V int1 > Numbers;
};

void watch (V OneVal > &kuchkuch) {
    int1 se = 0;
    while(2 * se + 1 < kuchkuch.size()) se = 2 * se + 1;
    int1 see = 0;
    while(2 * see + 1 < kuchkuch[se].Numbers.size()) see = 2 * see + 1;
    cout << kuchkuch[se].Numbers[see] << endl;
    LIMIT2 = kuchkuch.size();
    for2{
        cout << "===" << endl;
        cout << kuchkuch[i2].Val << endl;
        LIMIT3 = kuchkuch[i2].Numbers.size();
        for3 cout << kuchkuch[i2].Numbers[i3] << endl;
        cout << "===" << endl;
    };
};

void write (V OneVal > &kuchkuch) {
    return;
};

void ask (V OneVal > &kuchkuch) {
    char c;
    cin >> c;
    if (c == '?') {
        watch(kuchkuch);
        return;
    };
    write(kuchkuch);
};

int main () {

    // Input for BAZA ========================
    int1 n;
    cin >> n;
    V int1 > arr(n);
    LIMIT1 = n;
    for1 cin >> arr[i1];
    // =======================================

    // Make heap by VALUE ====================
    // This is the heap and elements ordered by
    V OneVal > kuchkuch;

    V int1 > ar(n);        // In which element of heap is ar

    LIMIT1 = n;
    for1 {
        int1 flag = 0;     // 0 - need new elem
        int1 se = 0;       // and if 1 se is number of elem
        while (se < kuchkuch.size()) {
            if (kuchkuch[se].Val == arr[i1]) {
                flag = 1;
                break;
            } else {
                se *= 2;
                se++;
                if (kuchkuch[se / 2].Val < arr[i1]) {
                    se++;
                };
            };
        };
        // now we have flag and se
        if (flag) {
            kuchkuch[se].Numbers.push_back(i1);
            int1 see = (int1)kuchkuch[se].Numbers.size() - 1;
            while (see) {
                if (see % 2 && kuchkuch[se].Numbers[see] > kuchkuch[se].Numbers[see / 2]) {
                    int1 temp = kuchkuch[se].Numbers[see];
                    kuchkuch[se].Numbers[see] = kuchkuch[se].Numbers[see / 2];
                    kuchkuch[se].Numbers[see / 2] = temp;
                    continue;
                };
                if (see % 2 == 0 && kuchkuch[se].Numbers[see] < kuchkuch[se].Numbers[(see - 1) / 2]) {
                    int1 temp = kuchkuch[se].Numbers[see];
                    kuchkuch[se].Numbers[see] = kuchkuch[se].Numbers[(see - 1) / 2];
                    kuchkuch[se].Numbers[(see - 1) / 2] = temp;
                    continue;
                };
                break;
            };
        } else {
            OneVal elem;
            elem.Val = arr[i1];
            elem.Numbers.push_back(i1);
            kuchkuch.push_back(elem);
            int1 y = (int1)kuchkuch.size() - 1;
            while (y) {
                if (y % 2 && kuchkuch[y].Val > kuchkuch[y / 2].Val) {
                    elem = kuchkuch[y];
                    kuchkuch[y] = kuchkuch[y / 2];
                    kuchkuch[y / 2] = elem;
                    continue;
                };
                if (y % 2 == 0 && kuchkuch[y].Val < kuchkuch[(y - 1) / 2].Val) {
                    elem = kuchkuch[y];
                    kuchkuch[y] = kuchkuch[(y - 1) / 2];
                    kuchkuch[(y - 1) / 2] = elem;
                    continue;
                };
                break;
            };
        };
    };
    int1 q;
    cin >> q;
    LIMIT1 = q;
    for1 ask(kuchkuch);
    return 0;
};*/