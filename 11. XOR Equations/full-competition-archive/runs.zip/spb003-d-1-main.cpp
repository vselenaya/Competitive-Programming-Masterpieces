#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <stack>
#include <queue>
#include <algorithm>
#include <cmath>

using namespace std;

int main()
{
    int n, w, h, s;
    cin >> n >> w >> h >> s;
    cin.get();

    map<char, vector<int>> m;

    for (int i = 0; i < n; ++i) {
        char c;
        cin >> c;
        cin.get();

        vector<int> v;
        v.resize(h);

        for (int j = 0; j < h; ++j) {
            char curr, prev = '.';
            for (int k = 0; k < w; ++k) {
                cin >> curr;
                if (curr != prev)
                    v[j]++;
                prev = curr;
            }

            if (prev != '.')
                v[j]++;

            cin.get();
        }

        m[c] = v;
    }

    int max = 0;
    char c;
    for (auto v : m) {
        for (auto i : v.second) {
            if (i > max) {
                max = i;
                c = v.first;
            }
        }
    }

    int chars = (s / max);
    if (s % max != 0)
        chars++;

    for (int i = 0; i < chars; ++i) {
        cout << c;
    }

    return 0;
}


/*
int main() {
    int n;
    cin >> n;
    cin.get();

    int c = 0;
    string s;


    for (int k = 0; k < n; ++k) {

        //sort
        for (int j = 0; j < n - k - 1; ++j) {
            cout << j + 1 << ' ' << j + 2;
            getline(cin, s);

            if (s == "WIN")
                return 0;
        }

        //skip
        for (int i = 0; i < n - k + 1; ++i) {
            cout << 1 << ' ' << 2;
            getline(cin, s);
        }

        //search for swapped
        for (int i = n - 1; i >= n - (c + 1); --i) {
            cout << 1 << ' ' << i + 1;
            getline(cin, s);
            if (s != "STAYED") {
                c = i;
                break;
            }
        }


    }
    return 0;
}
*/