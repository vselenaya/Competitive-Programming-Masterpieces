#include <bits/stdc++.h>

using namespace std;

int main()
{
  ios_base::sync_with_stdio(0);
  cin.tie(0), cout.tie(0);

  int d, s1 = 0, s2 = 0;
  double p, a, t;

  cin >> d >> p;

  int m[d];

  for (int i = 0; i < d; i++)
    cin >> m[i];

  for(int i = 0; i < d - 2; i++){
    for(int j = i + 2; j < d; j++){
      a = (double)(m[j] - m[i])/(double)(j - i + 1);
      //cout << j << " " << i << " " << j - i + 1 << " ";

      t = a*(a*(double)(j - i) + 2*m[j] - 2*m[i]);

      for (int k = i + 1; k < j; k++){
        t += (double)(m[k + 1] - m[k])*(double)(m[k + 1] - m[k]);
      }

      t = sqrt(t/(double)(j - i + 1));

      if (t == 0){
        if (a > 0)
          s1++;

        if (a < 0)
          s2++;
      }
      else
        if (a != 0){
          if (a >= p*t)
            s1++;

          if (a <= -p*t)
            s2++;
        }

    }
  }

  cout << s1 << " " << s2;
  return 0;
}
