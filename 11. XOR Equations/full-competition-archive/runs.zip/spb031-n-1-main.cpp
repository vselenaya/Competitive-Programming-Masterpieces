#ifdef DEBUG_MODE
#define _GLIBCXX_DEBUG 1
#endif
#pragma comment(linker, "/stack:200000000")
#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx")

#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const ll maxn = 102;
ll C[maxn + 1][maxn + 1];

ll symm(ll n, ll a) {
    if (a % 2 == 0) {
        return C[n / 2][a / 2];
    } else {
        if (n % 2 == 0) {
            return 0;
        } else {
            return C[n / 2][(a - 1) / 2];
        }
    }
}

ll nosymm(ll n, ll a) {
    return C[n][a] - symm(n, a);
}

ll solve(ll n, ll k) {
    ll ans = 0;
    for (ll a = 0; a < (k + 1) / 2; ++a) {
        if (k - a > n) continue;
        ll aa = C[n][a];
        ll b = C[n][k - a];
        ll c = nosymm(n, a);
        ll d = nosymm(n, k - a);
        ans += aa + b - c / 2 - d / 2;
    }
    if (k % 2 == 0) {
        ans += C[n][k / 2] + symm(n, k / 2);
    }
    return ans;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);

#ifdef DEBUG_MODE
    freopen("input.txt", "r", stdin);
#endif

    for (int n = 0; n <= maxn; ++n) {
        C[n][0] = C[n][n] = 1;
        for (int k = 1; k < n; ++k)
            C[n][k] = C[n - 1][k - 1] + C[n - 1][k];
    }
    ll n, k;
    cin >> n >> k;
    cout << solve(n, k);
    return 0;
}