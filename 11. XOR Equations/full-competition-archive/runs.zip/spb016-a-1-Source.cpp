#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <map>
#include <string>
#include <sstream>
#include <random>
#include <climits>
#include <iomanip>
#include <queue>
#include <bitset>
#include <cctype>
#include <functional>
#include <complex>
#include <fstream>
#include <unordered_set>
#include <unordered_map>
#include <ctime>
#include <deque>
#include <numeric>
#include <assert.h>
using namespace std;

typedef long long li;

#define forn(i,n) for (li i = 0;i < li(n);i++)
#define ford(i,n) for (li i = li(n)-1;i >=0;i--)
#define fore(i,l,r) for (li i = li(l);i < li(r);i++)
#define forv(v,arr) for (auto& v : (arr))
#define correct(x,n) (((x) >= 0) && ((x) < n))
#define all(a) (a).begin(),(a).end()
#define rnd() (rand() + (RAND_MAX+1)*rand())

//#define x first
//#define y second
//#define x real()
//#define y imag()

using vi = vector<li>;
using vptvi = vector<vi *>;
using pi = pair<li, li>;
using vpi = vector<pi>;
using vvi = vector<vector<li>>;
using ld = long double;
using Point = pair<li, li>;
//using Point = complex<li>;
//using Point = complex<ld>;

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	map<int, string> mp;
	mp[1995] = string("ITMO");
	mp[1996] = string("SPbSU");
	mp[1997] = string("SPbSU");
	mp[1998] = string("ITMO");
	mp[1999] = string("ITMO");
	mp[2000] = string("SPbSU");
	mp[2001] = string("ITMO");
	mp[2002] = string("ITMO");
	mp[2003] = string("ITMO");
	mp[2004] = string("ITMO");
	mp[2005] = string("ITMO");
	mp[2006] = string("PetrSU, ITMO");
	mp[2007] = string("SPbSU");
	mp[2008] = string("SPbSU");
	mp[2009] = string("ITMO");
	mp[2010] = string("ITMO");
	mp[2011] = string("ITMO");
	mp[2012] = string("ITMO");
	mp[2013] = string("SPbSU");
	mp[2014] = string("ITMO");
	mp[2015] = string("ITMO");
	mp[2016] = string("ITMO");
	mp[2017] = string("ITMO");
	mp[2018] = string("SPbSU");
	mp[2019] = string("ITMO");
	int year;
	cin >> year;
	cout << mp[year] << endl;
}