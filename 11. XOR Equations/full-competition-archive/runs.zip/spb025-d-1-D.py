import numpy as np

n, w, h, s = [int(i) for i in input().split()]

def check_symbol(st, w, h):
    arr = np.zeros((h,w+1))
    for row in range(h):
        for column in range(w):
            if st[row][column] == '#':
                arr[row][column] = 1
            else:
                arr[row][column] = 0

    change_matrix = np.zeros((h,w+1))
    for i in range(w):
        new_arr = np.roll(arr, -1, 1)
        new_arr[:,-1] = new_arr[:, -2]
        change_matrix += abs(arr - new_arr)
        arr = new_arr

    return change_matrix.max()

symbols = []
maxs = []

for i in range(n):
    symbols.append(input())
    st = []
    for row in range(h):
        st.append(input())
    maxs.append(check_symbol(st, w, h))

print(symbols[np.argmax(maxs)]*s)