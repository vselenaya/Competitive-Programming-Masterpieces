#include <iostream>
#include <string>
#include <unordered_map>
using namespace std;
int cnt = 1;
int c[10005];
int n;
bool check(int x){//kuda 1->
  while(c[x]!=1)
  {
    cnt++;
    x = c[x];
  }
  cout << cnt;
  if(cnt==n)return true;
  return false;
}


int main()
{
  int pi[10005];
  int t;
  cin >> t;
  for(int j = 1; j<=t; j++)
  {
    cin >> n;
    cout << '?' << ' ' << 2 << ' ' << 1 << ' ';
    for(int i = 3; i<=n; i++)
    {
      cout << i << ' ';
    }  
    cout << endl;

    for(int i = 1; i<=n; i++)
    {
      cin >> c[i];
    }
    int first=-1, second=-1;
    for(int i = 1; i<=n; i++)
    {
      if(c[i]!=i && first==-1)
      {
        first = c[i];
      }
      else if(c[i]!=i)
      {
        second = c[i];
      }
    }
    cout << '?' << ' ';
    for(int i = 1; i<n; i++)
    {
      cout << i+1 << ' ';
    }  
    cout << 1 << endl;
    for(int i = 1; i<=n; i++)
    {
      cin >> c[i];
    }
    cnt = 2;
    //cout << first << ' ' << second << endl;
      pi[1] = first;
      for(int i = 2; i<=n; i++)
      {
        pi[i] = c[first];
        first = pi[i];
      }

    cout << '!' << ' ';
    for(int i = 1; i<=n; i++)
    {
      cout << pi[i] << ' ';
    }
    cout << endl;
  }
  
}
