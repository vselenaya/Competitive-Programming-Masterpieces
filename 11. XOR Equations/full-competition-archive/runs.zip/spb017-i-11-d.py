s = int(input())

x1, y1 = 0, 0
x2 = None
def isInt(n):
    return int(n) == float(n)
for i in range(1, int(10**9/2)):
    y2 = i
    try:
        if isInt(math.sqrt(s - y2**2)):
            x2 = int(math.sqrt(s - y2**2))
            break
    except Exception as e:
        break

if x2 == None:
    print("Impossible")
else:
    print(x1, y1)
    print(x2, y2)
    print(-y2, x2)
    print(x2-y2, x2+y2)
