#include <climits>
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    vector<int> a(n + 1);
    a[0] = 0;
    for (int i = 1; i <= n; i++) {
	cin >> a[i];
    }
    int min_min = 0, max_min = INT_MAX, min_max = 0;
    sort(a.begin(), a.end());
    for (int i = 0; i < a.size() - 2; i++) {
	min_min = max(a[i + 1] - a[i], min_min);
	max_min = min(a[i + 2] - a[i], max_min);
    }
    min_min = max(a[n] - a[n - 1], min_min);
    if (min_min >= max_min) {
	cout << "0";
    } else {
	cout << min_min;
    }
    return 0;
}