﻿// Author: Igor Smirnov
#ifdef DEBUG_MODE
#define _GLIBCXX_DEBUG 1
#endif
#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx")
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef unsigned int ui;
typedef unsigned long long ull;

#ifndef CERR_ON
#define cerr if (false) cerr
#endif
#define forn(i, n) for (int i = 0; i < n; ++i)
#define all(a) (a).begin(), (a).end()
#define f first
#define s second
#define mp make_pair
#define pb push_back
#define next next42


int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int d;
    ld p;
    cin >> d >> p;
    vector<ll> c(d);
    forn(i, d) {
        cin >> c[i];
    }
    vector<ll> dif_prefsum(d + 1, 0);
    vector<ll> difsqr_prefsum(d + 1, 0);
    for (int i = 1; i < d; ++i) {
        dif_prefsum[i] = dif_prefsum[i - 1] + c[i] - c[i - 1];
        difsqr_prefsum[i] = difsqr_prefsum[i - 1] + (c[i] - c[i - 1]) * (c[i] - c[i - 1]);
    }
    int pos = 0;
    int neg = 0;
    const ld eps = 1e-12;
    for (int left = 0; left < d; ++left) {
        for (int right = left + 2; right < d; ++right) {
            ll psum = dif_prefsum[right] - dif_prefsum[left];
            ll sqrsum = difsqr_prefsum[right] - difsqr_prefsum[left];
            ld A = 1.0 * psum / (right - left);
            ld D = sqrt((ld) (- 2 * psum * A + sqrsum + A * A * (right - left)) / (right - left));
            //cerr << left << ' ' << right << endl;
            //cerr << A << ' ' << D << endl;
            if (fabs(D) < eps) {
                if (fabs(A) > eps) {
                    if (A > 0) {
                        ++pos;
                    }
                    else {
                        ++neg;
                    }
                }
            } else {
                ld x = D * p;
                //cerr << ((ld) A / D) << endl;
                if (A >= x) {
                    ++pos;
                }
                else if (A <= -x) {
                    ++neg;
                }
            }
        }
    }
    cout << pos << ' ' << neg << endl;
}