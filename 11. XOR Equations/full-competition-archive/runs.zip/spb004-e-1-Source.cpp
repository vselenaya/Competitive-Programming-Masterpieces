#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;


int main() {
	int n, c , ps=0, pe=1;
	cin >> n >> c;
	vector<int> a(n), b(n), w(n), p;

	for (int i = 0; i < n; i++) {
		cin >> a[i] >> b[i] >> w[i];
	}
	while (ps != pe) {
		for (int i = 0; i < n; i++) {
			if (w[i] == 0 && a[i] != c) {
				p.push_back(i + 1);
				w[i] = 6;
			}
		}
		for (int i = 0; i < n; i++) {
			if (w[i] == 1 && a[i] == c) {
				for (int j = i; j < n; j++) {
					if (b[i] == a[j]) { p.push_back(i + 1); w[i] = 6; c = b[i]; }
				}
			}
		}
		ps = pe;
		pe = p.size();
	}


	if (p.size() == n)
	{
		cout << "YES" << endl;
		for (int i = 0; i < n; i++) {
			cout << p[i] << " ";
		}
	}
	else cout << "NO";
}