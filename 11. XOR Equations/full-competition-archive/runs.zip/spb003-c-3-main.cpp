#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <stack>
#include <queue>
#include <algorithm>
#include <cmath>

using namespace std;


int main() {
    int n;
    cin >> n;
    cin.get();

    int c = 0;
    string s;

    for (int i = 0; i < n - 1; ++i) {
        cout << i + 1 << ' ' << i + 2;
        getline(cin, s);

        if (s == "WIN")
            return 0;
    }

    for (int i = 0; i < n - 1; ++i) {
        cout << i + 1 << ' ' << i + 2;
        getline(cin, s);

        if (s == "WIN")
            return 0;
    }

    for (int i = 0; i < 2; ++i) {
        cout << 1 << ' ' << 2;
        getline(cin, s);

        if (s == "WIN")
            return 0;
    }

    cout << "2n" << endl;

    for (int k = 2; k < n; ++k) {

        //check
        int skip = n - 1;
        for (int i = n - 1; i > n - k; --i) {
            cout << i << ' ' << i + 1;
            getline(cin, s);

            if (s == "SWAPPED") {
                for (int j = 0; j < i; ++j) {
                    cout << j + 1 << ' ' << i + 1;
                    getline(cin, s);

                    if (s == "WIN")
                        return 0;
                }
                skip = 0;
                break;
            }
            skip--;
        }

        for (int i = 0; i < n - 1; ++i) {
            cout << i + 1 << ' ' << i + 2;
            getline(cin, s);

            if (s == "WIN")
                return 0;
        }

        //skip
        for (int i = 0; i < skip + 2; ++i) {
            cout << 1 << ' ' << 2;
            getline(cin, s);

            if (s == "WIN")
                return 0;
        }

        cout << "2n" << endl;
    }
    return 0;
}
