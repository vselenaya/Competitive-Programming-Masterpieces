#include <iostream>

using namespace std;

int main() {
	int a, x, b, y, T;
	cin >> a >> x >> b >> y >> T;
	long sum1 = 21 * ((T - 30)*x) + a, sum2 = 21 * ((T - 45)*y) + b;
	if (T < 30) {
		sum1 = a;
		sum2 = b;
	}
	else if (T < 45) {
		sum2 = b;
	}
	cout <<  sum1 << " " << sum2;
	return 0;
}