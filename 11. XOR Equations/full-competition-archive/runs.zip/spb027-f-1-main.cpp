#include <bits/stdc++.h>
//#define FAST_ALLOCATOR_MEMORY 2e8
//#include "optimization.h"
using namespace std;

#define int long long
#define double long double
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
mt19937 rnd(chrono::high_resolution_clock::now().time_since_epoch().count());

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    cout << fixed << setprecision(20);
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    const double eps = 1e-8;
    int n;
    double p;
    cin >> n >> p;
    vector<int> a(n);
    for (auto &i : a) cin >> i;

    vector<int> pref(n, 0);
    for (int i = 1; i < n; ++i) {
        pref[i] = pref[i - 1] + (a[i] - a[i - 1]) * (a[i] - a[i - 1]);
    }

    int a1 = 0, a2 = 0;
    for (int i = 0; i < n; ++i) {
        for (int j = i + 2; j < n; ++j) {
            int N = j - i;
            double A = (double) (a[j] - a[i]) / N;
            double D = sqrt((double) (pref[j] - pref[i] - 2 * A * (a[j] - a[i]) + N * A * A) / N);
            if(abs(A) > eps) {
                if (A / D >= p) ++a1;
                if (A / D <= -p) ++a2;
            }
        }
    }
    cout << a1 << ' ' << a2;
}