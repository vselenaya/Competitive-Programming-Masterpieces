#include <bits/stdc++.h>

using namespace std;

long long ans;
int N, K;
long long Cs[52][52];

long long C(int n, int k) {
    if (n < k) return 0;
    if (Cs[n][k]) return Cs[n][k];
    if ((n == k) || (k == 0)) {
        Cs[n][k] = 1;
        return 1;
    }
    Cs[n][k] = C(n - 1, k - 1) + C(n - 1, k);
    return Cs[n][k];
}

long long forEven(int n, int k) {
    return (C(n, k) - C(n / 2, k / 2)) / 2 + C(n / 2, k / 2);
}

long long forOdd(int n, int k) {
    return C(n, k) / 2;
}

int main() {

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    cin >> N >> K;
    for (int i = min(N, K); i + i >= K; i--) {
        int j = K - i;
        if (N % 2 == 0) {
            ans += (i % 2 == 0) ? forEven(N, i) : forOdd(N, i);
            ans += (j % 2 == 0) ? forEven(N, j) : forOdd(N, j);
        } else {
            if (i % 2 == 0) {
                ans += (i > 0) ? forEven(N - 1, i) + forOdd(N - 1, i - 1) : forEven(N - 1, i);
            } else {
                ans += (i > 0) ? forOdd(N - 1, i) + forEven(N - 1, i - 1) : forOdd(N - 1, i);
            }
            if (j % 2 == 0) {
                ans += (j > 0) ? forEven(N - 1, j) + forOdd(N - 1, j - 1) : forEven(N - 1, j);
            } else {
                ans += (j > 0) ? forOdd(N - 1, j) + forEven(N - 1, j - 1) : forOdd(N - 1, j);
            }

        }
    }
    cout << ans;

}
