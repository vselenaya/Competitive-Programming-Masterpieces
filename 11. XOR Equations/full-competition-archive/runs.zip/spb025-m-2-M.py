n = int(input())
arr = [0] + [int(i) for i in input().split()]
arr.sort()

l, r = arr[0], arr[-1]

for i in range(len(arr) - 2):
    L = arr[i + 1] - arr[i]
    R = arr[i + 2] - arr[i]
    if L > l:
        l = L
    if R < r:
        r = R

L = arr[-1] - arr[-2]
if L > l:
    l = L

if r - l >= 1:
    print(l)

else:
    print(0)