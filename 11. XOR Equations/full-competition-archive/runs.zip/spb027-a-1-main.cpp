#include <iostream>
#include <string>
#include <unordered_map>
using namespace std;
int main()
{
    //freopen("input.txt", "r", stdin);
    unordered_map <string, string> M;
    M["1995"] = "ITMO";
    M["1996"] = "SPbSU";
    M["1997"] = "SPbSU";
    M["1998"] = "ITMO";
    M["1999"] = "ITMO";
    M["2000"] = "SPbSU";
    M["2001"] = "ITMO";
    M["2002"] = "ITMO";
    M["2003"] = "ITMO";
    M["2004"] = "ITMO";
    M["2005"] = "ITMO";
    M["2006"] = "PetrSU, ITMO";
    M["2007"] = "SPbSU";
    M["2008"] = "SPbSU";
    M["2009"] = "ITMO";
    M["2010"] = "ITMO";
    M["2011"] = "ITMO";
    M["2012"] = "ITMO";
    M["2013"] = "SPbSU";
    M["2014"] = "ITMO";
    M["2015"] = "ITMO";
    M["2016"] = "ITMO";
    M["2017"] = "ITMO";
    M["2018"] = "SPbSU";
    M["2019"] = "ITMO";
    string n;
    cin >> n;
    cout << M[n];
}
