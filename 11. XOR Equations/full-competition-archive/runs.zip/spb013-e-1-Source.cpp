﻿#include <stdlib.h>
#include <iostream>
#include <deque>

using namespace std;
void quickSort(long long* arr, int left, int right)
{
	long long pivot; // разрешающий элемент
	int l_hold = left; //левая граница
	int r_hold = right; // правая граница
	pivot = arr[left];
	while (left < right) // пока границы не сомкнутся
	{
		while ((arr[right] >= pivot) && (left < right))
			right--; // сдвигаем правую границу пока элемент [right] больше [pivot]
		if (left != right) // если границы не сомкнулись
		{
			arr[left] = arr[right]; // перемещаем элемент [right] на место разрешающего
			left++; // сдвигаем левую границу вправо
		}
		while ((arr[left] <= pivot) && (left < right))
			left++; // сдвигаем левую границу пока элемент [left] меньше [pivot]
		if (left != right) // если границы не сомкнулись
		{
			arr[right] = arr[left]; // перемещаем элемент [left] на место [right]
			right--; // сдвигаем правую границу вправо
		}
	}
	arr[left] = pivot; // ставим разрешающий элемент на место
	pivot = left;
	left = l_hold;
	right = r_hold;
	if (left < pivot) // Рекурсивно вызываем сортировку для левой и правой части массива
		quickSort(arr, left, pivot - 1);
	if (right > pivot)
		quickSort(arr, pivot + 1, right);
}

int main()
{
	deque<long long> a;
	deque<long long> b;
	deque<int> w;

	deque<int> check;

	deque<int> end;

	long long n;
	cin >> n;
	long long c;
	cin >> c;

	for (int i = 0; i < n; i++) {
		long long aa;
		cin >> aa;
		a.push_back(aa);
		long long bb;
		cin >> bb;
		b.push_back(bb);
		int ww;
		cin >> ww;
		w.push_back(ww);
	}
	for (int i = 0; i < n; i++) {
		check.push_back(0);
	}
	bool f;
	while (true) {
		f = false;
		
		for (int i = 0; i < n; i++) {
			if ((c != a.at(i))&&(w.at(i)==0)) {
				if (check[i] == 1) {
					continue;
				}
				end.push_back(i+1);
				check[i] = 1;
			}	
		}

		for (int i = 0; i < n; i++) {
			if ((c == a.at(i)) && (w.at(i) == 1)) {				
				c = b.at(i);
				
				check[i] = 1;
				f = true;
				end.push_back(i+1);
				break;
			}
		}		

		if (f) {
			continue;
		}

		bool endend = false;
		for (int i = 0; i < n; i++) {
			if (check.at(i) == 0) {
				endend = true;
				break;
			}
		}
		if (endend) {
			cout << "No";
			return 0;
		}
		else {
			cout << "Yes" << endl;
			for (int i = 0; i < n; i++) {
				cout << end.at(i) << " ";
			}
			return 0;
		}

	}




}