n, k = [int(x) for x in input().split()]

C = [[0 for i in range(2 * n + 1)] for j in range(2 * n + 1)]

for i in range(2 * n + 1):
    C[i][0] = C[i][i] = 1
    for j in range(1, i):
        C[i][j] = C[i - 1][j - 1] + C[i - 1][j]

def pal(n, i):
    if n % 2 == 0:
        if i % 2 == 1:
            return 0
        return C[n // 2][i // 2]
    else:
        if i % 2 == 0:
            return C[(n - 1) // 2][i // 2]
        else:
            return C[(n - 1) // 2][(i - 1) // 2]


res = 0
for i in range(k + 1):
    res += (C[n][i] + pal(n, i)) // 2

if k % 2 == 0:
    res += (C[n][k // 2] + pal(n, k // 2)) // 2

print(res)