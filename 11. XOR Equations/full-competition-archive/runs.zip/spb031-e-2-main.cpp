#include<bits/stdc++.h>
#include<unordered_map>
#include<unordered_set>

using namespace std;

struct edge {
    int to;
    int ind;
};

std::vector<int> out_deg;
std::vector<int> in_deg;

std::vector<std::vector<edge>> gr;

std::vector<int> not_suc_ind_c;
std::vector<int> not_suc_ind_not_c;

std::vector<std::unordered_set<int>> is;
std::vector<int> del; // edges
std::vector<std::unordered_set<int>> vis1;

std::unordered_map<int, int> MAP;
int N = 0;
int n, c, c_val, all_edges_num;

vector<int> euler;
vector<int> edge_num;

inline void build_euler(int v, int e) {
    while (!gr[v].empty()) {
        auto u = gr[v].back();
        gr[v].pop_back();

        if (!del[u.ind]) {
            del[u.ind] = 1;
            //cerr << "FOLLOW EDGE " << v + 1 << ' ' << u.nxt + 1 << endl;
            build_euler(u.to, u.ind);
        }
    }
    euler.push_back(v);
    edge_num.push_back(e);
}

int ans_pos;

bool relax(int c) {
    int beg = -1;
    int end = -1;

    for (int v = 0; v < gr.size(); ++v) {
        if (out_deg[v] == in_deg[v]) {
            continue;
        } else if (out_deg[v] + 1 == in_deg[v]) {
            if (end != -1) {
                return false;
            }
            end = v;
        } else if (out_deg[v] - 1 == in_deg[v]) {
            if (beg != -1) {
                return false;
            }
            beg = v;
        } else {
            return false;
        }
    }

    if (beg != -1 && end == -1 || beg == -1 && end != -1) {
        return false;
    }

    bool not_cycle = false;
    if (beg != -1 && end != -1) {
        if (beg != c_val) {
            return false;
        }
        not_cycle = true;
        gr[end].push_back(edge{beg, n + 1});
    }

    del[n + 1] = true;
    build_euler(c_val, n + 1);

    if (!not_cycle && edge_num.size() - 1 != all_edges_num) {
        return false;
    } else if (not_cycle && edge_num.size() - 1 != all_edges_num) {
        return false;
    }

    reverse(euler.begin(), euler.end());
    reverse(edge_num.begin(), edge_num.end());

    for (int i = 0; i < euler.size(); i++) {
        if (edge_num[i] == n + 1) {
            ans_pos = i;
            break;
        }
    }
    return true;
}

int get_val(int a) {
    if (MAP.count(a) > 0) {
        return MAP[a];
    }

    MAP[a] = N++;
    return MAP[a];
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    cin >> n >> c;

    gr.resize(n * 2 + 1);
    is.resize(n * 2 + 1);
    del.resize(n + 2);
    out_deg.resize(n * 2 + 1);
    in_deg.resize(n * 2 + 1);

    c_val = get_val(c);

    for (int i = 0; i < n; i++) {
        int a, b, w;
        cin >> a >> b >> w;
        int a_val = get_val(a);
        int b_val = get_val(b);

        if (w == 1) {
            gr[a_val].push_back(edge{b_val, i});
            is[a_val].insert(b_val);
            out_deg[a_val]++;
            in_deg[b_val]++;
            all_edges_num++;
        } else {
            if (a_val == c_val) {
                not_suc_ind_not_c.push_back(i);
            } else {
                not_suc_ind_c.push_back(i);
            }
        }
    }
    bool res = relax(0);

    if (!res) {
        cout << "No";
        return 0;
    }

    vector<int> answer;

    for (auto kek: not_suc_ind_c) {
        answer.push_back(kek);
    }

    for (int i = 0; i < all_edges_num; i++) {
        int current_node = euler[(ans_pos + i) % euler.size()];
        while (current_node != c_val && !not_suc_ind_not_c.empty()) {
            answer.push_back(not_suc_ind_not_c.back());
            not_suc_ind_not_c.pop_back();
        }
        int kek = edge_num[(ans_pos + i + 1) % edge_num.size()];
        answer.push_back(kek);
    }
    int current_node = euler[(ans_pos + all_edges_num) % euler.size()];
    while (current_node != c_val && !not_suc_ind_not_c.empty()) {
        answer.push_back(not_suc_ind_not_c.back());
        not_suc_ind_not_c.pop_back();
    }

    if (answer.size() == n) {
        cout << "Yes\n";
        for (int k : answer) {
            cout << k + 1 << ' ';
        }
    } else {
        cout << "No";
    }

    return 0;
}
