#include <bits/stdc++.h>

using namespace std;

int n, w, h, s, ans;
char c, maxc;

int main() {

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    cin >> n >> w >> h >> s;
    for (int k = 0; k < n; k++) {
        cin >> c;
        int curmax = 0;
        for (int i = 0; i < h; i++) {
            char prev = '.', cur;
            int cnt = 0;
            for (int j = 0; j < w; j++) {
                cin >> cur;
                if (cur != prev) cnt++;
                prev = cur;
            }
            if (prev != '.') cnt++;
            if (cnt > curmax) curmax = cnt;
        }
        if (curmax > ans) ans = curmax, maxc = c;
    }
    ans =  (s % ans == 0) ? s / ans : s / ans + 1;
    for (int i = 0; i < ans; i++) cout << maxc;

}
