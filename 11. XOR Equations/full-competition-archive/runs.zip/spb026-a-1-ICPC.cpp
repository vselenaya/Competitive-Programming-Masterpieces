﻿// ICPC.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>

int main()
{
    int year;
        std::cin >> year;

        if (year == 2006) {
            std::cout << "PetrSU, ITMO";
        }
        else if ((((year % 10) > 0) && ((year % 10) < 3)) || ((year % 10) == 4) || ((year % 10) == 5) || ((year % 10) == 9) || (year == 1998) || (year == 2003) || (year == 2017) || (year == 1998) || (year == 2016)) {
            std::cout << "ITMO";
        }
        else {
            std::cout << "SPbSU";
        }
    return 0;
}
