#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll n;
ll a[100001];

int main()
{
    cin >> n;
    for (int i = 1; i <= n; ++i) {
        cin >> a[i];
    }
    sort(a, a+n+1);
    ll mx = 0;
    ll mn = 1000000001ULL;
    for (int i = 1; i <= n; ++i) {
        mn = min(a[i]-a[i-1], mn);
        mx = max(a[i]-a[i-1], mx);
    }
    for (int i = 0; i <= n; ++i) {
        ll cnt = 0;
        for(int j = i+1;j <= n && cnt < 2; j++) {
            if(a[i] + mx >= a[j]) {
                cnt++;
            } else {
                break;
            }
        }
        if(cnt >= 2) {
            mx = 0;
            break;
        }
    }
    cout << mx << endl;

    return 0;
}
