#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> pii;
typedef pair<long long, long long> pll;
typedef long long ll;
typedef unsigned int ui;
typedef unsigned long long ull;
typedef long double ld;

const int inf = 1e9;
const ll inf64 = 1e18;

int main() {

#ifdef DEBUG
    freopen("input.txt", "r", stdin);
#endif

    ios_base::sync_with_stdio(0);
    cin.tie(0);

    ll s;
    cin >> s;

    for (ll x = 0; x <= s; x++) {
        for (ll y = 0; y <= s; y++) {
            if (x * x + y * y == s) {
                cout << 0 << " " << 0 << "\n";
                cout << x << " " << y << "\n";
                cout << x - y << " " << y + x << "\n";
                cout << -y << " " << x << "\n";
                return 0;
            }
        }
    }

    cout << "Impossible\n";

    return 0;
}
