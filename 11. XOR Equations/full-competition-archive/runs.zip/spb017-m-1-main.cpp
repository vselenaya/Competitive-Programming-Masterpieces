#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main()
{
    int n, tmp, ans;
    cin >> n;
    vector<int> v;
    for(int i = 0; i < n; i++)
    {
        cin >> tmp;
        v.push_back(tmp);
    }
    sort(v.begin(),v.end());
    int f = v[0];
    for (int i = 1 ; i < v.size() ; i++)
    {
        if (v[i] - v[i - 1] > ans) ans = v[i] - f;
    }
    for (int i = 2; i < v.size(); i++){
        if (v[i] - v[i - 2] <= ans){
            cout << 0;
            return 0;
        }
    }
    cout << ans;
return 0;
}
