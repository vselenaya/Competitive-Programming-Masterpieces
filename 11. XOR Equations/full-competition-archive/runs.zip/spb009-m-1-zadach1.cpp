#include <iostream>
#include <vector>
#include <string>
#include <cmath>

int main() {
	int n, d = 0, max=0;
	int size,temp=0, tempTrue, stack = 0;
	std::cin >> size;
	std::vector<int> arr;
	for (int i = 0; i < size; i++)
	{
		std::cin >> n;
		arr.push_back(n);
	}
	
	for (int i = 0; i < size; i++)
	{
		if (arr[i] > max)
			max = arr[i];
	}

	for (int j = 0; j < max; j++) {
		tempTrue = temp;
		
		for (int i = 0; i < size; i++) {

			if ((arr[i] - stack) <= d)
			{
				stack = arr[i];
				temp++;
			}
		}

		if (temp == size)
			break;
		d++;
	}

	std::cout << d;
}