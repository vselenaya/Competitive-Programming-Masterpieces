#include <iostream>

using namespace std;

int main(void)
{
	int i = 2;
	int n = 0;
	int k = 0;
	int cyc = 0;
	string str;
	
	cin >> n;

	while (str != "WIN")
	{
		if (i == n + 1 || cyc == (2 * n))
		{
			while (i < n)
			{
				i = 1;
				cout << i << " " << i + 1 << endl;
				cin >> str;
				if (str == "WIN")
				{
					return 1;
				}
				i++;
			}
			i = 2;
			cyc = 0;
			k = 0;
		}
		if (i == 1)
		{
			i++;
		}
		cout << i - 1 << " " << i << endl;
		cin >> str;
		if (str == "SWAPPED")
		{
			if (k == 0)
			{
				k = i;
			}
			i--;
		}
		if (str == "STAYED")
		{
			i++;
		}
		if (k != 0 && i == 2)
		{
			cout << i - 1 << " " << i << endl;
			cin >> str;
			i = k + 1;
			k = 0;
		}
	}

	return 0;
}