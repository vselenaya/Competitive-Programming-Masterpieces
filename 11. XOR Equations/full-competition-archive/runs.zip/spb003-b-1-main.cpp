#include <iostream>

using namespace std;

int main()
{
    int a{},x{},b{},y{}, T{};
    cin >> a; //
    cin >> x; //
    cin >> b; //
    cin >> y; //
    cin >> T; //
    int S1{};
    int S2{};
    if (T > 30)
    {
        S1 = a + 21*(T-30)*x;
    }
    else
    {
        S1 = a;
    }
    if (T > 45)
    {
        S2 = b + 21*(T-45)*y;
    }
    else
    {
        S2 = b;
    }


    cout << S1 << ' ' << S2;
}
