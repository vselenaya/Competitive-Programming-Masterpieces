#include <iostream>
#include <string>

int main()
{
    int n;
    std ::cin >> n;
    std::string text = "";
    int last = n;
    while (text != "WIN")
    {
        std::cout << last - 1 << " " << last << std::endl;
        last = last - 1 == 1 ? n : last - 1;
        std::cin >> text;
    }
}