#include <iostream>
#include <unordered_map>

using namespace std;

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int s, a, b;
    unordered_map<int, int> sq;
    a = 1;
    while (a * a <= 1000) {
        sq[a * a] = a;
        a++;
    }
    cin >> s;
    for (int i = 0; i * i <= s; i++) {
        if (sq.find(s - i * i) != sq.end()) {
            a = i; b = sq[s - i * i];
            cout << 0 << ' ' << 0 << '\n';
            cout << -a << ' ' << b << '\n';
            cout << b << ' ' << a << '\n';
            cout << b - a << ' ' << b + a << '\n';
            return 0;
        }
    }
    cout << "Impossible\n";
    return 0;
}
