#include <iostream>
#include <string>
#include <math.h>
using namespace std;
int main()
{
  int N;
  cin>>N;
  int t=int(sqrt(N));
  if(t*t==N){cout<<"0 0\n"<<t<<" 0\n"<<t<<" "<<t<<"\n"<<"0 "<<t<<"\n";return 0;}
  for(int i=t;i>0;i--)
  {
      int s=N-i*i;
      int j=int(sqrt(s));
      if(j*j==s){cout<<"0 0\n"<<i<<" "<<j<<"\n"<<i-j<<" "<<i+j<<"\n"<<-j<<" "<<i<<"\n";return 0;}
  }
  cout<<"Impossible\n";
}
