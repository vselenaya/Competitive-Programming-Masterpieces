﻿#include <iostream>
#include <vector>

using namespace std;
typedef long long li;

#define forn(i,n) for (li i = 0;i < li(n);i++)
#define ford(i,n) for (li i = li(n)-1;i >=0;i--)
#define fore(i,l,r) for (li i = li(l);i < li(r);i++)
#define forv(v,arr) for (auto& v : (arr))


using vi = vector<li>;


using vvi = vector < vector < li>>;


int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);

	vvi _c(51, vi(51, 0));
	fore(i, 0, 51) fore(j, 0, 51)
	{
		if (i < j)
		{
			_c[i][j] = 0;
			continue;
		}
		if (i == j || j == 0)
		{
			_c[i][j] = 1;
			continue;
		}
		_c[i][j] = _c[i - 1][j - 1] + _c[i - 1][j];
	}

	auto c = [&](li n1, li k1)
	{
		if (n1 < k1)
			return 0LL;
		return _c[n1][k1];
	};

	li n, k;
	cin >>n >> k;
	li res = 0;
	fore(i, max(0ll, k - n), k + 1)
	{
		li d = c(n, i);
		if (n % 2)
			d += c(n / 2, i / 2);
		else
			d += c(n / 2, i / 2) * (i % 2 == 0);
		d /= 2;
		res += d;
		if (i * 2 == k)
			res += d;
	}
	cout<< res << endl;
}