﻿#include <random>
#include <numeric>
#include <iostream>
#include <ctime>
#include <algorithm>
using namespace std;

int main()
{
  int cards = 0;
  cin >> cards;
  int step = 0;

  int* arr = new int[cards];
  for (int i = 0; i < cards; i++)
  {
    arr[i] = i+1;
  }

  unsigned seed = 0;
  shuffle(arr, arr + cards,
    default_random_engine(seed));


  while (true)
  {
    srand(time(0));
    int i = rand() % cards + 1;
    int j = rand() % cards + i;

    cout << i << " " << j << endl;
    cout.flush();

    string input;
    cin >> input;

    if (input == "WIN")
    {
      return 0;
    }

    else if (input == "SWAPPED")
    {
      int tmp = arr[i-1];
      arr[i-1] = arr[j-1];
      arr[j-1] = tmp;
    }

    else if (input == "STAYED")
    {
    }
    
    if (step % 2 == 0) 
    {
      int m = rand() % cards + 1;
      int n = rand() % cards + m;
      int tmp = arr[m-1];
      arr[m-1] = arr[n-1];
      arr[n-1] = tmp;
    }
    step++;
  }
}
