n = int(input())
arr = [0] + [int(i) for i in input().split()]
arr.sort()

l, r = arr[0], arr[-1]

for i in range(len(arr)-2):
    L = arr[i+1]-arr[i]
    R = arr[i+2]-arr[i]
    if L > l:
        l = L
    if R < r:
        r = R

if r - l >= 2:
    print(r-1)
else:
    print(0)