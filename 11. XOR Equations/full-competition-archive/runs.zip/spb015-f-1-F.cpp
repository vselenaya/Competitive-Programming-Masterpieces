#include <iostream>

using namespace std;

long long int fact(int N)
{
	if (N < 0)
		return 0;
	if (N == 0)
		return 1;
	else
		return N * fact(N - 1);
}

int c(int n, int m)
{
	return (fact(n) / (fact(n - m) * fact(m)));
}

float getA (int **arr, int size, int row)
{
	int sum = 0;
	for (int i = 1; i < size; i++)
	{
		sum += (arr[row][i] - arr[row][i - 1]);
	}

	return ((1 / size) * sum);
}

float getD (int **arr, int size, int row, float a)
{
	int sum = 0;
	for (int i = 1; i < size; i++)
	{
		sum += ((arr[row][i] - arr[row][i - 1] - a)* (arr[row][i] - arr[row][i - 1] - a));
	}
	sum = (1 / size) * sum;

	return sqrt(sum);
}

int main() {
	int days = 0;
	float p = 0;
	int* prices;

	cin >> days >> p;
	prices = new int[days];

	for (int i = 0; i < days; i++)
	{
		cin >> prices[i];
	}
	
	int positive = 0,
		negative = 0;

	float a = 0, d = 0;
	
	for (int i = 3; i <= days; i++)
	{
		int size = c(days, i);
		int **vars = new int*[size];
		for (int j = 0; j < size; j++)
		{
			int someVal = 0;
			int tmpI, tmpJ;
			vars[j] = new int[i];
			for (int z = 0; z < i; z++)
			{
				vars[j][z] = prices[someVal++];
				if (someVal == days)
					someVal = 0;
			}
			
			float a = getA(vars, i, j),
				d = getD(vars, i, j, a);

			if (a > 0 && d == 0)
			{
				positive++;
				continue;
			}
			if (a < 0 && d == 0)
			{
				negative++;
				continue;
			}
			if (a == 0)
			{
				continue;
			}
			if ((a / d) >= p)
			{
				positive++;
				continue;
			}
			if ((a / d) <= (1 - p))
			{
				negative++;
				continue;
			}
		}	
	}
}