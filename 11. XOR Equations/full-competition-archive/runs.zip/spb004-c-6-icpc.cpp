﻿#define _CRT_SECURE_NO_WARNINGS

#include <algorithm>
#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <cmath>
#include <queue>
#include <map>
#include <set>

using namespace std;

#pragma GCC optimize ("-O3")

#define wt int t; cin>>t; while(t--)
#define all(v) v.begin(),v.end()
#define max(a,b) (a>b?a:b)
#define min(a,b) (a<b?a:b)
#define max3(a,b,c) max(max(a,b),max(a,c))
#define min3(a,b,c) min(min(a,b),min(a,c))
#define pi 3.141592653
#define ll long long
#define ull unsignate long long

struct ch
{
    char cha;
    vector<int> map;
};

bool extSwap(int i1, int i2)
{
    string str;
    cout << i1 << ' ' << i2 << '\n';
    cin >> str;
    if (str == "SWAPPED")
        return true;
    else if (str == "WIN")
        exit(0);
    else 
        return false;
}

int main()
{
#ifdef ASD
    freopen("a.in", "r", stdin);
#endif
    int n = 0, j;
    cin >> n;
    for (size_t i = 0; i < n; i++)
    {
        j = i;
        while (extSwap(i, j)) j++;
    }

    return 0;
}