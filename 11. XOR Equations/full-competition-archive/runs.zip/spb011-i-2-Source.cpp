#include <iostream>

using namespace std;

int main() {
	int square;
	cin >> square;
	int a, b, x;
	bool isTrue = false;
	float y;
	if (square == 1) {
		cout << "0 0" << endl;
		cout << "0 1" << endl;
		cout << "1 0" << endl;
		cout << "1 1" << endl;
		//system("pause");
		return 0;
	}
	for (int i = 1; i < square; i++) {
		y = sqrt(- (i * i) + square);
		if ((int)y == y) {
			a = i; b = y;
			isTrue = true;
			break;
		}		
	}
	if (isTrue) {
		cout << "0 0" << endl;
		cout << -b << " " << a << endl;
		cout << a - b << " " << a + b << endl;
		cout << a << " " << b << endl;
	}
	else {
		cout << "Impossible";
	}
	//system("pause");
	return 0;
}