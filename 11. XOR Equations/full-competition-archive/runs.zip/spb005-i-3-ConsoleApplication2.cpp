﻿// ConsoleApplication2.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <vector>
#include<string>
#include<set>
#include<cmath>
#include<map>
#include<algorithm>
using namespace std;

int main() {
	vector<int> v;
	int n;
	int a = 0;
	int b = 0;
	cin >> n;

	for (int i = 0; i < n; i++) {
		if (i * i >= n) break;
		v.push_back(i * i);

	};

	vector<int>::iterator i = v.begin();
	i++;
	vector<int>::iterator j = v.end();
	j--;

	while (*j != *i) {
		if (*i + *j == n) {
			a = sqrt(*i);
			b = sqrt(*j);
			break;
		}
		if ((*i + *j) < n) {
			i++;
		}
		else if ((*i + *j) > n) {
			j--;
		}
	}

	if (*i + *i == n) {
		a = sqrt(*i);
		b = sqrt(*i);
	}

	if ((a || b) == 0) {
		cout << "Impossible" << endl;
	}
	else { 
		int x1 = 0;
		int y1 = 0;
		cout << x1 << " " << y1 << endl;
		cout << x1 - a << " " << y1 + b << endl;
		cout << x1 + b << " " << y1 + a << endl;
		cout << x1 + b - a << " " << y1 + a + b << endl;
	}
}
