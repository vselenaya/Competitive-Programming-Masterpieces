#include <bits/stdc++.h>
//#define FAST_ALLOCATOR_MEMORY 2e8
//#include "optimization.h"
using namespace std;

#define int long long
#define double long double
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
mt19937 rnd(chrono::high_resolution_clock::now().time_since_epoch().count());

signed main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    cout << fixed << setprecision(20);
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    int n;
    cin >> n;
    vector<int> a(n);
    for(auto& i : a) cin >> i;
    sort(all(a));

    int ans = 0;
    for(int i = 1; i < n; ++i) {
        ans = max(ans, a[i] - a[i - 1]);
    }
    for(int i = 2; i < n; ++i) {
        if(a[i] - a[i - 2] <= ans) {
            cout << 0;
            return 0;
        }
    }
    cout << ans;
}