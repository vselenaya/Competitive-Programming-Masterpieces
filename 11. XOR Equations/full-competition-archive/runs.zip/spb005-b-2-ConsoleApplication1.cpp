﻿#include <iostream>
#include <vector>
#include<string>
#include<set>
#include<cmath>
#include<map>
#include<algorithm>

using namespace std;

int main()
{
	int n, x, y = 1, z;
	cin >> n;
	int flag=0;
	while (true)
	{
		x = n ;
		z = x - y * y;
		double a;
		a = sqrt(z);
		if (a == (int)a)break;
		else y++;
		if (y > (x - 1)) { break; flag = 1; }
	}
	int a = y, b = sqrt(n  - y );
	if (flag) {
		cout << "Impossible";
	}
	if (a == 0 || b == 0)cout << "Impossible";
	else {
		int x1 = 0;
		int y1 = 0;
		cout << x1 << " " << y1<<endl;
		cout << x1 - a << " " << y1+b<<endl;
		cout << x1+b  << " " << y1+a<<endl;
		cout << x1 + b-a << " " << y1 + a +b<<endl;

	}

	//cout<<1+y<<" "<<
}

