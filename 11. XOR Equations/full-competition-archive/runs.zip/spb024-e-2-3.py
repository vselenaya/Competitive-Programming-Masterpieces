n, c = map(int, input().split())

l = []
for _ in range(n):
    l.append(list(map(int, input().split())))


def foo(cc, listAns):
    for i, e in enumerate(l):
        if ((e[2] == 0) and (e[0] != cc) and (i not in listAns)):
            listAns.append(i)
    for i, e in enumerate(l):
        if ((e[2] == 1) and (e[0] == cc) and (i not in listAns)):
            s = list(listAns)
            s.append(i)
            s = foo(e[1], s)
            if (type(s) != bool):
                return s
    
    if (len(listAns) == len(l)):
        return listAns
    else:
        return False
    
list_new = foo(c, list())
if (type(list_new) != bool):
    spc = ' ' 
    print('Yes')
    for i in range(len(list_new)):
        list_new[i] += 1
    print(spc.join(map(str, list_new)))
else:
    print('No')
