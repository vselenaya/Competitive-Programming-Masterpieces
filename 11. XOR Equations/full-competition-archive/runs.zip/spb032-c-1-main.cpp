#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;

mt19937 rnd(time(0));
#define rall(x) (x).rbegin(), (x).rend()
#define all(x) (x).begin(), (x).end()
#define pNN pair <Node *, Node *>
#define SZ(x) (int)(x).size()
#define pii pair <int, int>
#define pb push_back
#define eb emplace_back
#define rev reverse
#define ins insert
#define ers erase
#define S second
#define F first
#define int ll
const int N = 3100, INF = 1e9 + 10, M = 1e9 + 7;

bool my_swap(int i, int j) {
    cout << i << " " << j << endl;
    string s;
    cin >> s;
    if (s == "WIN") {
        exit(0);
    }
    return s == "SWAPPED";
}

void solve() {
    int n;
    cin >> n;
    int cnt = 0;
    while (true) {
        for (int i = 1; i <= n - 1; ++i) {
            bool b = my_swap(i, i + 1);
            ++cnt;
            if (cnt % (n * 2) == 0) {
                cnt = 0;
                break;
            }
            if (b) {
                int j = i;
                while (j > 1) {
                    bool b = my_swap(j - 1, j);
                    ++cnt;
                    if (b) {
                        --j;
                    } else {
                        break;
                    }
                    if (cnt % (n * 2) == 0) {
                        cnt = 0;
                        break;
                    }   
                }
                if (cnt % (n * 2) == 0) {
                    cnt = 0;
                    break;
                }
            }
        }
    }
}  

signed main () {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cout.precision(12);
    #ifdef fleek$
       // assert(freopen("input.txt", "r", stdin));
    #endif
    int t = 1;
    //cin >> t;
    while(t--) solve();
    return 0;
}