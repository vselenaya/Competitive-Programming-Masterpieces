#include <iostream>
#include <map>
using namespace std;

int main()
{

    int arr[17]  = {1995, 1998, 1999, 2001, 2002, 2003, 2004, 2005, 2009, 2010, 2011, 2012, 2014, 2015, 2016, 2017, 2019};
    int arr2[7]  = {1996, 1997, 2000, 2007, 2008, 2013, 2018};
    int arr3[1]  = {2006};
    int year;
    cin >> year;

    for(int i = 0; i < 7; i++){
        if(arr2[i] == year){
            cout<< "SPbSU";
        }
    }
    if(arr3[0] == year){
        cout<< "PetrSU, ITMO";
    }

    for(int i = 0; i< 17; i++){
        if(arr[i] == year){
            cout<< "ITMO";
        }
    }


    return 0;
}
