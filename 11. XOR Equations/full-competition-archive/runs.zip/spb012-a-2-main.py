

if __name__ == '__main__':
    a = int(input())
    x = int(input())
    b = int(input())
    y = int(input())
    T = int(input())
    ans1 = a + 21 * max(0, (T - 30) * x)
    ans2 = b + 21 * max(0, (T - 45) * y)

    print(f'{ans1} {ans2}')
