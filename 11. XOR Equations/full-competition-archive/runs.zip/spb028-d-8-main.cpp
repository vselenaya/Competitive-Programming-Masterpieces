#include <iostream>
#include <bits/stdc++.h>

using namespace std;

struct display
{
    char name;
    string pix[100];
    int usability[100];
};
display ch[111];
display ch1, ch2;
int MaxUs = 0;
int idx = -1;

int main()
{
    int n,w,h,s;
    cin>>n>>w>>h>>s;
    for ( int i = 1; i <= n; i++)
    {
        cin>>ch[i].name;
        for ( int j = 0; j < h; j++)
        {
            char last = '.';
            ch[i].usability[j] = 0;
            cin>>ch[i].pix[j];
            ch[i].pix[j] += '.';
            for ( int k = 0; k <= w; k++)
                if ( ch[i].pix[j][k] != last )
                {
                    ch[i].usability[j]++;
                    last = ch[i].pix[j][k];
                }
        }
    }
    for ( int i = 1; i <= n; i++ )
    {
        for ( int j = 0; j < h; j++ )
            if ( ch[i].usability[j] > MaxUs )
            {
                idx = i;
                MaxUs = ch[i].usability[j];
            }
    }
    int cnt = s / MaxUs;
    if ( cnt * MaxUs != s ) cnt++;
    string ans = "";
    for ( int i = 0; i < cnt; i++ ) ans += ch[idx].name;
    cout<<ans;
    return 0;
}
