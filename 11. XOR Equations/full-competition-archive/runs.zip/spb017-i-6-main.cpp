#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    double n,s,f;
    cin >> n;
    for (int i = 1; i < n ; i++)
    {
        if ((sqrt(n - i) - ceil(sqrt(n - i)) == 0) && ((sqrt(i) - ceil(sqrt(i)) == 0)))
        {
            s = sqrt(n - i);
            f = sqrt(i);
            cout << 0 << " " << 0 << endl;
            cout << s << " " << f << endl;
            cout << s-f << " " << s+f << endl;
            cout << -f << " " << -s ;
            return 0;
        }
    }
    cout << "Impossible";
    return 0;
}
