#include <iostream>
using namespace std;

struct Letter {
public:
	char** pixels;
	int width;
	int height;
	char symbol;

	int CalcMostSwitches() {
		int maxSwitches = 0;

		for (int i = 0; i < height; i++) {
			char tmp = '.';
			int switches = 0;
			for (int j = 0; j < width; j++) {
				if (tmp != pixels[i][j])
					switches++;
				tmp = pixels[i][j];
			}
			if (tmp != '.')
				switches++;

			if (switches > maxSwitches)
				maxSwitches = switches;
		}

		return maxSwitches;
	}
};

int main() {
	int symbolsNum;
	cin >> symbolsNum;
	int width;
	cin >> width;
	int height;
	cin >> height;
	int switchesToBreak;
	cin >> switchesToBreak;
	Letter* letters = new Letter[symbolsNum];

	int mostSwitches = 0;
	char bestSymbol;
	for (int i = 0; i < symbolsNum; i++) {
		cin >> letters[i].symbol;
		Letter sym = letters[i];

		sym.pixels = new char*[height];
		for (int a = 0; a < height; a++)
			sym.pixels[a] = new char[width];

		sym.height = height;
		sym.width = width;
		for (int j = 0; j < sym.height; j++)
			for (int k = 0; k < sym.width; k++)
				cin >> sym.pixels[j][k];

		int switches = sym.CalcMostSwitches();
		if (switches > mostSwitches) {
			mostSwitches = switches;
			bestSymbol = sym.symbol;
		}
	}

	string output;
	for (int i = 0; i < switchesToBreak; i += mostSwitches) {
		output.push_back(bestSymbol);
	}

	cout << output;
}