#include <iostream>
#include <cmath>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    uint16_t s;
    cin >> s;

    uint16_t sqrt = std::sqrt(s);

    if (sqrt * sqrt == s) {
        cout << 0 << " " << 0 << "\n";
        cout << 0 << " " << sqrt << "\n";
        cout << sqrt << " " << sqrt << "\n";
        cout << sqrt << " " << 0 << "\n";

        return 0;
    }

    for (uint16_t i = 1; i <= sqrt; i++) {
        for (uint16_t j = 1; j <= sqrt; j++) {

            if (i * i + j * j == s) {
                cout << 0 << " " << i << "\n";
                cout << j << " " << 0 << "\n";
                cout << j + i << " " << j << "\n";
                cout << i << " " << i + j << "\n";
                return 0;
            }
        }
    }

    cout << "Impossible";

    return 0;
}