﻿#include <map>
#include <iostream>
#include <cassert>

using namespace std;
int main()
{

  int a, x, b, y, T;
  int tmp = 0, days = 21, res = 0;
  cin >> a >> x >> b >> y >> T;
  tmp = T - 30;
  if (tmp < 0) {
    cout << a << " ";
  }
  else {
    cout << tmp * 21 * x + a << " ";
  }
  tmp = T - 45;
  if (tmp < 0) {
    cout << b;
  }
  else {
    cout << tmp * 21 * y + b;
  }
  return 0;

}