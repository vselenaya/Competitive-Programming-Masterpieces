#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
typedef long double ld;

#define pb push_back
#define forn(i, n) for (int i = 0; i < (int)(n); i++)
#define forrn(i, s, n) for (int i = (int)(s); i < (int)(n); i++)
#define PYMOD(a, m) ((((a) % (m)) + (m)) % (m))
#define all(v) v.begin(), v.end()
#define rall(v) v.rbegin(), v.rend()
#define mp make_pair
#define ff first
#define ss second

const int maxn = 3'000'179;
int trie[maxn][2];
int is_terminal[maxn];
int nv = 1;

void add_vertex(int v, int length, int j) {
    int cv = 0;
    forn(i, length) {
        int e = (v >> (length - i - 1)) & 1;
        if (trie[cv][e] == -1) {
            trie[cv][e] = nv++;
        }
        cv = trie[cv][e];
    }
    is_terminal[cv] = j;
}

int K;

const int maxk = 31;
ld prob_height[maxk + 1];
ld pow2[maxk + 1];

ld ans = 0;
vector<int> rs;
vector<int> dfs(int v, int h) {
    rs.pb(is_terminal[v]);
    vector<int> r = {1};
    forn(i, 2) {
        int u = trie[v][i];
        vector<int> q;
        if (u == -1) {
            q.resize(K - h - 1);
            if (K > h + 1) {
                q[0] = 1;
            }
            forrn(j, 1, q.size()) {
                q[j] = q[j - 1] * 2;
            }
        } else {
            q = dfs(u, h + 1);
        }
        int j = 1;
        for (int w : q) {
            if ((int)r.size() <= j)
                r.pb(0);
            r[j] += w;
            j++;
        }
    }
    if (is_terminal[v] > -1) {
        r[0] = 0;
        int c = -1;
        forn(i, rs.size()) {
            if (rs[i] != -1 && rs[i] < is_terminal[v]) {
                c = i;
            }
        }
        c = rs.size() - 1 - c;
        ld pans = ans;
        if (c == (int)rs.size()) {
            ans++;
        } else {
            ans += 1 - pow2[c - 1];
        }
        /* cout << v << " " << ans - pans << " "; */
        forrn(i, 1, r.size()) {
            ans += (prob_height[i] - pow2[i - 1] / (i + 1)) * r[i];
        }
        /* cout << ans - pans << endl; */
        r = {};
    }
    rs.pop_back();
    return r;
}

int main() {
    memset(trie, 0xff, sizeof(trie));
    memset(is_terminal, 0xff, sizeof(is_terminal));
    pow2[0] = 1;
    forrn(k, 1, maxk + 1) {
        pow2[k] = pow2[k - 1] * 0.5;
    }
    prob_height[0] = 1;
    for (int k = 1; k <= maxk; k++) {
        for (int t = 0; t < k - 1; t++) {
            prob_height[k] += pow2[t + 1] / (t + 2);
        }
        prob_height[k] += pow2[k - 1] / (k + 1);
    }
    /* forn(i, maxk) */
    /*     cout << i << " " << prob_height[i] << endl; */

    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cout.precision(20);
    // Code here:

    int k, n;
    cin >> k >> n;
    K = k;
    forn(i, n) {
        int s, m;
        cin >> s >> m;
        add_vertex(m - 1, k - s, i);
    }

    vector<int> r = dfs(0, 0);
    forn(i, r.size()) {
        ans += prob_height[i] * r[i];
    }

    cout << fixed << ans << endl;

    return 0;
}
