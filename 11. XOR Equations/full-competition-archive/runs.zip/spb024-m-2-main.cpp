#include <iostream>
#include <string>
#include <vector>
#include <functional>
#include <algorithm>
#include <map>


int main(int, char* []) {
  int n = 0;
  std::cin >> n;
  std::vector<int> vec(n + 1);
  vec[0] = 0;
  int e = 0;
  for (int i = 1; i <= n; ++i) {
    std::cin >> e;
    vec[i] = e;
  }

  std::sort(vec.begin(), vec.end());

  int gap = 0;
  int minDiff = std::numeric_limits<int>::max();
  for (int i = 1; i < n; ++i) {
    int cur = vec[i] - vec[i - 1];
    if (cur > gap) {
      gap = cur;
    }
    int diff = vec[i + 1] - vec[i - 1];
    if (diff < minDiff) {
      minDiff = diff;
    }
  }

  int lastGap = vec[n] - vec[n - 1];
  if (lastGap > gap) {
    gap = lastGap;
  }

  if (gap < minDiff) {
    std::cout << gap << std::endl;
  } else {
    std::cout << 0 << std::endl;
  }
  return 0;
}
