﻿#include <stdio.h>
#include <stdlib.h>
#include <iostream>


using namespace std;
void quickSort(long long* arr, int left, int right)
{
  long long pivot;
  int l_hold = left;
  int r_hold = right; 
  pivot = arr[left];
  while (left < right) 
  {
    while ((arr[right] >= pivot) && (left < right))
      right--; 
    if (left != right) 
    {
      arr[left] = arr[right]; 
      left++; 
    }
    while ((arr[left] <= pivot) && (left < right))
      left++; 
    if (left != right) 
    {
      arr[right] = arr[left];
      right--; 
    }
  }
  arr[left] = pivot;
  pivot = left;
  left = l_hold;
  right = r_hold;
  if (left < pivot) 
    quickSort(arr, left, pivot - 1);
  if (right > pivot)
    quickSort(arr, pivot + 1, right);
}

int main()
{
  int n;
  long long d, tmp = 0, check = 0;
  cin >> n;
  long long* arr = new long long[n];
  for (int i = 0; i < n; i++) {
    cin >> arr[i];
  }
  quickSort(arr, 0, n - 1);
  long long temp = 0;
  for (int i = 0; i < n; i++) {
    tmp = arr[i] - temp;
    if (check < tmp) {
      check = tmp;
    }
    temp = arr[i];
  }
  temp = 0;
  for (int i = 0; i < n - 2; i++) {
    long long che1 = arr[i];
    long long che2 = arr[i + 1];
    long long che3 = arr[i + 2];
    if (i == n - 2) {
      if (che2 - check <= che1) {
        cout << 0;
        return 0;
      }
    }
    else if ((che3 - check <= che1) && (che2 - check <= che1)) {
      cout << 0;
      return 0;
    }
  }
  cout << check;
  return 0;

}
