#include <bits/stdc++.h>

using namespace std;

int d, pos, neg;
long double P, D, A;
int c[3001];

int main() {

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    cin >> d >> P;
    for (int i = 0; i < d; i++) cin >> c[i];
    for (int k = 3; k <= d; k++) {
        for (int i = 0; i <= d - k; i++) {
            A = double(c[k + i - 1] - c[i]) / (k - 1);
            for (int j = 1; j < k; j++) {
                D += (c[i + j] - c[i + j - 1] - A) * (c[i + j] - c[i + j - 1] - A);
            }
            D = sqrt(D / (k - 1));
            if (D == 0) {
                if (A > 0) pos++;
                if (A < 0) neg++;
            } else {
                if (A >= P * D) pos++;
                if (A <= -P * D) neg++;
            }
        }
    }
    cout << pos << ' ' << neg;
}
