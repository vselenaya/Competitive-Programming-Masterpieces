#include<iostream>
using namespace std;

int main(){
	//ios_base::sync_with_stdio(false);
	//cin.tie(NULL);
	int a = 0, x = 0, b = 0, y = 0, T=0;
	long first = 0, second = 0;
	cin >> a >> x >> b >> y >> T;
	if (T > 30) {
		first = (T - 30) * x * 21 + a;
	}
	else {
		first = a;
	}
	if (T > 45) {
		second = (T - 45) * y * 21 + b;
	}
	else {
		second = b;
	}
	cout << first << ' ' << second;
	return 0;
}