#include <iostream>
using namespace std;
int main() {
	int n; bool f=false;
	int a[] = { 1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144, 169, 196, 225, 256, 289, 324, 361, 400, 441, 484, 529, 576, 625, 676, 729, 784, 841, 900, 961 };
	cin >> n;
	int i = 30, j=0;
	while (a[i] > n) i--;
	for (; i >= 0; i--) {
		for (j = 0; j <= i; j++) {
			if (a[i] + a[j] > n) {
				break;
			}
			if (a[i] + a[j] == n) {
				f = 1;
				break;
			}
		}
		if (f) break;
	}
	if (f) {
		cout << 0 << ' ' << i+1 << endl;
		cout << j+1 << ' ' << 0 << endl;
		cout << i + j+2 << ' ' << j+1 << endl;
		cout << i+1 << ' ' << i + j+2 << endl;
	}
	else cout << "Impossible";
	return 0;
}