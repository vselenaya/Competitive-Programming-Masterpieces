#ifdef DEBUG_MODE
#define _GLIBCXX_DEBUG 1
#endif
#pragma comment(linker, "/stack:200000000")
#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx")

#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

using namespace std;

void solve() {
    int n;
    cin >> n;
    vector<int> vals(n);
    for (int i = 0; i < n; ++i) {
        cin >> vals[i];
    }
    vals.push_back(0);
    sort(vals.begin(), vals.end());
    int mindiff = 1000000009;
    int maxdiff = 0;
    int min2diff = 1000000009;
    for (int i = 0; i + 1 < vals.size(); ++i) {
        mindiff = min(mindiff, vals[i + 1] - vals[i]);
        maxdiff = max(maxdiff, vals[i + 1] - vals[i]);
    }
    for (int i = 0; i + 2 < vals.size(); ++i) {
        min2diff = min(min2diff, vals[i + 2] - vals[i]);
    }

    // >= maxdiff

    int d = maxdiff;

    for (int i = 0; i + 2 < vals.size(); ++i) {
        if(vals[i] + d >= vals[i + 2]) {
            cout << 0;
            return;
        }
    }
    cout << d;
    return;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);

#ifdef DEBUG_MODE
    freopen("input.txt", "r", stdin);
#endif

    solve();

    return 0;
}