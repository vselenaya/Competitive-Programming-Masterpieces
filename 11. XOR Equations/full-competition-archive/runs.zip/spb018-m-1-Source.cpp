#include <iostream>
#include <vector>
#include<algorithm>
using namespace std;
int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	int n;
	cin >> n;
	vector <int> a(n);

	for (int i = 0; i < n; i++) {
		cin >> a[i];
	}
	sort(a.begin(), a.end());
	int min = a[1],  max =a[0];
	if (a[1] - a[0] > max) max = a[1] - a[0];
	for (int i = 2; i < n; i++) {
		if (a[i] - a[i - 2] < min) min = a[i] - a[i - 2];
		if (a[i] - a[i - 1] > max) max = a[i] - a[i - 1];
	}
	if (max >= min) cout << 0;
	else cout << max;
	return 0;
}