a = int(input())
x = int(input())
b = int(input())
y = int(input())
T = int(input())
if (T<=30):
    S1 = a
else:
    S1 = 21*(x*(T-30)) + a
if (T<=45):
    S2 = b
else:
    S2 = 21*(y*(T-45)) + b
print(S1,"",S2)