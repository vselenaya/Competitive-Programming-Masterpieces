n = int(input())

s = ''

while s != 'WIN':
    for i in range(1, n):
        print(i, i + 1)
        s = input()
        if s == 'WIN':
            break
