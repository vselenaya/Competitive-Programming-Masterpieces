#include <iostream>
#include <string>
#include <cstdlib>
#include <math.h>
using namespace std;
long long C(int n, int m)
{
    long long T=m;
    if(n==0)return 1;
    if(n==m)return 1;
    n=max(n,m-n);
    for(int i=1;i<n;i++)
    {
        T*=(m-i);
        T/=1+i;
    }
    T/=2;
    if(m%2==0&&n%2!=0)T=T;
    else T++;
    return T;
}
int main()
{
 long long N=0;
 long long n,k;
 cin>>n>>k;
 int t1,t2;
 if(k>n)
 {
     t1=n;
     t2=k-n;
 }
 else
 {
     t1=k;
     t2=0;
 }
int t3=(t1+t2)/2+(t1+t2)%2;
for(;t1>=t3;t1--,t2++)
N+=C(t1,n)+C(t2,n);
cout<<N;
}
