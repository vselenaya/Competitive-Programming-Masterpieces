#ifdef DEBUG_MODE
#define _GLIBCXX_DEBUG 1
#endif
#pragma comment(linker, "/stack:200000000")
#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx")

#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

ll n;
ll cur = 0;

bool ask(ll a, ll b) {
    cout << min(a, b) + 1 << " " << max(a, b) + 1 << "\n";
    cout.flush();
    string s;
    cin >> s;

    cur++;

    if (s == "WIN") {
        exit(0);
    } else if (s == "SWAPPED") {
        return true;
    } else {
        return false;
    }
}

void step_until_swap() {
    while (cur % (2 * n) != 0) {
        ask(0, 1);
    }
}

void localize(ll pos) {
    for (ll i = pos + 1; i < n; ++i) {
        ask(pos, i);
    }
}

void solve() {
    cin >> n;
    for (ll curpos = 0; curpos < n; ++curpos) {
        localize(curpos);
        step_until_swap();
        // fix broken
        ll broken = -1;
        for (ll i = 0; i + 1 <= curpos; ++i) {
            if (ask(i, i + 1)) {
                broken = i;
                break;
            }
        }
        if(broken == -1) {
            localize(curpos);
        } else {
            for (ll i = curpos + 1; i < n; ++i) {
                if(ask(broken, i)) {
                    ask(i, broken + 1);
                    break;
                }
            }
        }
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);

#ifdef DEBUG_MODE
    //freopen("input.txt", "r", stdin);
#endif

    solve();

    return 0;
}