#include <bits/stdc++.h>

using namespace std;

// #ifdef DEBUG
// ifstream in("input");
// #define cin in
// #endif

#define EPS 0.000000001

void fast_io() {
  ios_base::sync_with_stdio(0);
  // cin.tie(0);
  // cout.tie(0);
  cout.setf(ios::fixed);
  cout.precision(20);
}

int n;
int t;

int last_good_i = 0;

string ans;

void my_swap(int i, int j) {
  cout << i + 1 << ' ' << j + 1 << endl;
  ++t;
  cin >> ans;
}

bool not_first_cycle = false;

void restore(int ind) {
  for (int i = last_good_i + 1; i < n; ++i) {
    my_swap(ind, i);
  }
}

void restore_order() {
  for (int i = 0; i < last_good_i; ++i) {
    my_swap(i, i + 1);
    if (ans == "SWAPPED") {
      restore(i + 1);
      my_swap(i, i + 1);
    }
  }
}

void solve() {
// amin'
once_again:
  t = 0;
  if (not_first_cycle)
    restore_order();

  for (int i = last_good_i; i < n; last_good_i = ++i) {
    for (int j = i + 1; j < n; ++j) {
      my_swap(i, j);
      if (ans == "WIN") {
        return;
      }
      if (t == 2 * n) {
        not_first_cycle = true;
        goto once_again;
      }
    }
  }
}

int main() {
  fast_io();
  cin >> n;
  solve();
  return 0;
}