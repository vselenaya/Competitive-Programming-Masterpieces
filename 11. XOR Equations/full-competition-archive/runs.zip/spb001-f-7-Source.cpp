#include <climits>
#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int d;
    long double P;
    cin >> d >> P;
    vector<int> c(d);
    for (int i = 0; i < d; i++) {
	cin >> c[i];
    }
    int count_neg = 0, count_pos = 0;
    for (int i = 3; i <= d; i++) {
	for (int k = 0; k <= d - i; k++) {
	    double A = (c[k + i - 1] - c[k]) / (double)(i - 1);
	    double D = 0;
	    for (int j = k; j < k + i - 1; j++) {
		D += (c[j + 1] - c[j] - A) * (c[j + 1] - c[j] - A);
	    }
	    D /= (double)(i - 1);
	   // D = sqrt(D);
	    if (A > 0 && D == 0) {
		count_pos++;
	    } else if (A < 0 && D == 0) {
		count_neg++;
	    } else if (A != 0) {
		double AD = A * A / D;
		if (AD >= P * P) {
		    if (A > 0) {
			count_pos++;
		    } else {
			count_neg++;
		    }
		}
		
	    }
	}
    }
    
    cout << count_pos << " " << count_neg;
    return 0;
}