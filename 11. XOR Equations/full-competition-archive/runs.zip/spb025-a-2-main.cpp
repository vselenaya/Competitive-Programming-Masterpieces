#include <iostream>

using namespace std;

int main(void)
{
	int a = 0, b = 0, x = 0, y = 0, T = 0;

	cin >> a;
	cin >> x;
	cin >> b;
	cin >> y;
	cin >> T;
	
	if (T > 30)
	{
		cout << (T - 30) * x * 21 + a << " ";
	}
	else
	{
		cout << a << " ";
	}
	if (T > 45)
	{
		cout << (T - 45) * y * 21 + b;
	}
	else
	{
		cout << b;
	}
	

	return 0;
}