#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
typedef long double ld;
 
mt19937 rnd(time(0));
#define rall(x) (x).rbegin(), (x).rend()
#define all(x) (x).begin(), (x).end()
#define pNN pair <Node *, Node *>
#define SZ(x) (int)(x).size()
#define pii pair <int, int>
#define pb push_back
#define eb emplace_back
#define rev reverse
#define ins insert
#define ers erase
#define S second
#define F first
#define int ll
const int N = 1e5 + 10, INF = 1e9 + 10, M = 1e9 + 7;

int n;
int a[N];

int f(int d, int n) {
    int res = 0;
    for (int i = 0; i < n; ++i) {
        if (a[i] <= res + d) {
            if (i + 1 < n && a[i + 1] <= res + d) {
                return 1;
            }
        } else {
            return -1;
        }
        res = a[i];
    }
    return 0;
}

void solve() {
    cin >> n;
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    } 
    sort(a, a + n);
    int l = 1, r = INF;
    while (r - l > 1) {
        int m = (r + l) / 2;
        int x = f(m, n);
        if (x == 0) {
            cout << m << endl;
            exit(0);
        }
        if (x == -1) {
            l = m;
        } else {
            r = m;
        }
    }
    if (f(l, n) == 0) {
        cout << l << endl;
        exit(0);
    }
    if (f(r, n) == 0) {
        cout << r << endl;
        exit(0);
    }
    cout << 0 << endl;
}

signed main () {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cout.precision(12);
    #ifdef fleek$
        assert(freopen("input.txt", "r", stdin));
    #endif
    int t = 1;
    //cin >> t;
    while(t--) solve();
    return 0;
}