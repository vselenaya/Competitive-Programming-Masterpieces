#include "iostream"
#include "string"
#include "vector"
#include "cmath"

int max_switches;

struct letter_line
{
public:
    letter_line()
    {
    }

    letter_line(std::string _line)
    {
        switches = 0;
        start = _line[0] == '#';
        end = _line[_line.length() - 1] == '#';
        for (int i = 0; i < _line.length() - 1; i++)
        {
            if (_line[i] != _line[i + 1])
            {
                switches++;
            }
        }
        max_switches = std::max(max_switches, switches);
    }

    bool start, end;
    int switches;
};

struct letter
{
public:
    char symbol;
    std::vector<letter_line> lines;

    letter()
    {
    }

    letter(char _symbol, std::vector<std::string> _lines)
    {
        symbol = _symbol;
        for (int i = 0; i < _lines.size(); i++)
        {
            lines.push_back(letter_line(_lines[i]));
        }
    }
};

int main()
{
    int n, w, h, s;
    std::cin >> n >> w >> h >> s;
    std::vector<letter> letters(n);

    for (int i = 0; i < n; i++)
    {
        char letter_symbol;
        std::cin >> letter_symbol;
        std::vector<std::string> letter_lines(h);
        for (int j = 0; j < h; j++)
        {
            std::string line;
            std::cin >> line;
            letter_lines[j] = line;
        }
        letters[i] = letter(letter_symbol, letter_lines);
    }

    std::vector<std::pair<int, int>> max_lines;
    std::vector<std::pair<int, int>> sub_max_lines;

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < h; j++)
        {
            if (letters[i].lines[j].switches == max_switches)
            {
                max_lines.push_back(std::make_pair(i, j));
            }
            else if (letters[i].lines[j].switches == max_switches)
            {
                sub_max_lines.push_back(std::make_pair(i, j));
            }
        }
    }

    int o1, o2;
    bool found_o = false;
    for (int i = 0; i < max_lines.size(); i++)
    {
        auto max_line_i = max_lines[i];
        for (int j = i; j < max_lines.size(); j++)
        {
            auto max_line_j = max_lines[i];
            if (max_line_i.second == max_line_j.second)
            {
                if (letters[max_line_i.first].lines[max_line_i.second].start != letters[max_line_j.first].lines[max_line_j.second].end)
                {
                    o1 = max_line_i.first;
                    o2 = max_line_j.first;
                    found_o = true;
                    break;
                }
            }
        }
        if (found_o)
        {
            break;
        }
    }

    if (!found_o)
    {
        o1 = o2 = max_lines[0].first;
    }

    for (int i = 0; i < std::ceil(1.0 * s / (max_switches + found_o)); i++)
    {
        if (i % 2)
        {
            std::cout << letters[o1].symbol;
        }
        else
        {
            std::cout << letters[o2].symbol;
        }
    }
    return 0;
}