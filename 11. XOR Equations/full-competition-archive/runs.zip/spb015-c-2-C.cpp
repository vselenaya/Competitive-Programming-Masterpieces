﻿#include <iostream>
#include <vector>
#include <random>
#include <numeric>
#include <iostream>
#include <ctime>
using namespace std;

int main()
{
  unsigned short int cards = 0;
  cin >> cards;
  unsigned short int step = 1;

  vector<unsigned short int> vec;
  for (unsigned short int i = 1; i <= cards; i++)
  {
    vec.push_back(i);
  }
  shuffle(vec.begin(), vec.end(), default_random_engine(random_device()()));

  while (true)
  {
    srand(time(0));
    unsigned short int i = rand() % cards + 1;
    unsigned short int j = rand() % cards + 1;

    do {
      j = rand() % cards + 1;
    } while (j <= i);

    cout << i << " " << j << endl;
    cout.flush();

    string input;
    cin >> input;

    if (input == "WIN")
    {
      return 0;
    }

    else if (input == "SWAPPED")
    {
      unsigned short int tmp = vec[i-1];
      vec[i-1] = vec[j-1];
      vec[j-1] = tmp;
    }

    else if (input == "STAYED")
    {
    }
    
    if (step % 2 == 0) 
    {
      srand(time(0));
      unsigned short int randI = rand() % cards + 1;
      unsigned short int randJ = rand() % cards + 1;

      do {
        randJ = rand() % cards + 1;
      } while (randJ <= randI);

      unsigned short int tmp = vec[randI-1];
      vec[randI-1] = vec[randJ-1];
      vec[randJ-1] = tmp;
    }
    step++;
  }
}
