﻿#define _CRT_SECURE_NO_WARNINGS

#include <algorithm>
#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <cmath>
#include <queue>
#include <map>
#include <set>

using namespace std;

#pragma GCC optimize ("-O3")

#define wt int t; cin>>t; while(t--)
#define all(v) v.begin(),v.end()
#define max(a,b) (a>b?a:b)
#define min(a,b) (a<b?a:b)
#define max3(a,b,c) max(max(a,b),max(a,c))
#define min3(a,b,c) min(min(a,b),min(a,c))
#define pi 3.141592653
#define ll long long
#define ull unsignate long long

struct ch
{
    char cha;
    vector<int> map;
};
int main()
{
    freopen("a.in", "r", stdin);
    //freopen("a.out", "w", stdout);

    int n = 0, w = 0, h = 0, s = 0;
    cin >> n >> w >> h >> s;

    vector<ch> vec(n);

    char in;
    char wmask;

    for (int j = 0; j < n; j++)
    {
        cin >> vec[j].cha;

        for (int wi = 0; wi < w; wi++)
        {
            vec[j].map.emplace_back();
        
            wmask = '.';                    // 1

            for (int hi = 0; hi < h; hi++)  // 2
            {
                cin >> in;
                if (in != wmask)
                {
                    vec[j].map[wi] += 1;
                    wmask = in;
                }
            }
                  
            if (in != '.') // 3
                vec[j].map[wi] += 1;
        }
    }

    int max = 0;
    char maxChar;
    for (int j = 0; j < n; j++)
    {
        for (int wi = 0; wi < w; wi++)
        {
            if (vec[j].map[wi] > max)
            {
                max = vec[j].map[wi];
                maxChar = vec[j].cha;
            }
        }
    }

    while (s>0)
    {
        s -= max;
        cout << maxChar;
    }

    return 0;
}