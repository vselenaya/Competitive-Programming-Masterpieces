#include <iostream>
#include <algorithm>
#include <vector>
#include <cmath>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    size_t n;
    cin >> n;
    vector<int> arr;
    arr.reserve(n);

    for (int i = 0; i < n; i++) {
        int a;
        cin >> a;
        arr.push_back(a);
    }
    sort(arr.begin(), arr.end());

    size_t maxDelta = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] - arr[i-1] > maxDelta)
            maxDelta = arr[i] - arr[i-1];
    }
    if (arr[1] <= maxDelta) {
        cout << 0;
        return 0;
    }

    for (int i = 1; i < n - 1; i++) {
        if (arr[i] - arr[i-1] <= maxDelta && arr[i+1] - arr[i-1] > maxDelta)
            continue;
        else {
            maxDelta = 0;
            break;
        }
    }
    cout <<  maxDelta;
    return 0;
}