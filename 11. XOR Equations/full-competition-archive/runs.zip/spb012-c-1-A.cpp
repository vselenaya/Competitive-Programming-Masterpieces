#include <algorithm>
#include <bitset>
#include <cstdlib>
#include <iostream>
#include <random>
#include <set>
#include <vector>

// #define FAST_ALLOCATOR_MEMORY 256000000
// #include "optimization.h"
#include <bits/stdc++.h>

using namespace std;

// #define USE_INT128
// #define int int64_t

// #undef _DEBUG

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()

#ifdef USE_INT128
#define lint __int128
#define ulint __int128
#else
#define lint int64_t
#define ulint int64_t
#endif

typedef long double ld;
#define f first
#define s second
typedef pair<int, int> pint;

const int inf = 1 << 30;

template <class T>
T mineq(T& a, const T& b) {
    return a = min(a, b);
}

template <class T>
T maxeq(T& a, const T& b) {
    return a = max(a, b);
}

mt19937 rd(533);
// end of default file

// const int N = 50;
// int arr[N];

// void init() {
//     for (int i = 0; i < N; i++) {
//         arr[i] = i;
//     }
//     shuffle(arr, arr + N, rd);
// }
// int moves = 0;

// bool make_swap(int i, int j) {
//     moves++;
//     i--;
//     j--;
//     if (i > j) swap(i, j);

//     if (arr[i] > arr[j]) {
//         swap(arr[i], arr[j]);
//     }

//     bool sorted = true;
//     for (int i = 0; i < N; i++) {
//         sorted = sorted && (arr[i] == i);
//     }
//     if (sorted) {
//         cerr << "WIN IN " << moves;
//         exit(0);
//     }

//     if (moves % (2 * N) == 0) {
//         int i = rd() % N;
//         int j = rd() % (N - 1);
//         if (j >= i) j++;

//         swap(arr[i], arr[j]);
//     }
// }

bool make_swap(int i, int j) {
    cout << i << ' ' << j << endl;
    string ans;
    cin >> ans;
    if (ans == "WIN") {
        exit(0);
    }
    return ans == "SWAPPED";
}

int32_t main() {
    // srand(5332017);
    ios::sync_with_stdio(false);
    cin.tie();
    cout.tie();
    cout << fixed;
    cout.precision(4); // !!

#ifdef _DEBUG
    // // init();
    // freopen("input.txt", "r", stdin);
    // int seed;
    // cin >> seed;
    // rd = mt19937(seed);
    // // freopen("output.txt", "w", stdout);
#else
    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
#endif

    int n;
    cin >> n;

    while (true) {
        for (int i = 1; i + 1 <= n; i++) {
            make_swap(i, i + 1);
        }
        for (int i = n-1; i > 0; i--) {
            make_swap(i, i + 1);
        }
    }

    return 0;
}
