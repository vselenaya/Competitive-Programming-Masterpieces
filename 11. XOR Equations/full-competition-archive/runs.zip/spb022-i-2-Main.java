package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        int x1=0,x2=0,x3,x4,y1=0,y2=0,y3,y4;
        Scanner scan = new Scanner(System.in);
        int s = scan.nextInt();
        double s1 = s;
        if ((int)Math.sqrt(s) == Math.sqrt(s1))
            System.out.print("0 0\n" + (int) Math.sqrt(s) + " 0\n" + "0 " + (int) Math.sqrt(s) + "\n" + (int) Math.sqrt(s) + " " + (int) Math.sqrt(s));
        else {
            int sideBigger = (int) Math.ceil(Math.sqrt(s));
            for(int i = 1;i<=sideBigger-1;i++) {
                if(Math.sqrt(Math.pow(sideBigger-1,2)+Math.pow(i,2))==Math.sqrt(s)){
                    y2=i;
                    x2=sideBigger-1;
                    break;
                }
            }
            if(x2==0)System.out.print("Impossible");
            else{
                x3 = x2-y2;
                y3 = y2 + x2;
                y4 = x2;
                x4 = -y2;
                System.out.print(x1+" "+y1+"\n"+x2+" "+ y2+"\n"+x3+" "+y3+"\n"+x4+ " "+y4);
            }
        }
    }
}
