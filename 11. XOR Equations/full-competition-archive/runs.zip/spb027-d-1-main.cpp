#include <iostream>
#include <string>
#include <unordered_map>
using namespace std;
int main()
{
  char c, maxc, prev, cur;
  int n,w,h,s,max_ones=0, cnt;
  cin >> n >> w >> h >> s;
  for(int i = 0; i<n; i++)
  {
    cin >> c;
    for(int j = 0; j<h; j++)
    {
      prev = '.';
      cnt = 0;
      for(int k = 0; k<w; k++)
      {
        cin >> cur;
        if(prev=='.' && cur == '#')
        {
          cnt++;
        }
        prev = cur;
      }
      if(cnt>max_ones)
      {
        maxc = c;
        max_ones = cnt;
      }
    }
  }
  int ans = s/(2*max_ones);
  if(s%(2*max_ones)!=0)
    ans++;
  //cout << ans << endl;
  for(int i = 0; i<ans; i++)
  {
    cout << maxc;
  }
}
