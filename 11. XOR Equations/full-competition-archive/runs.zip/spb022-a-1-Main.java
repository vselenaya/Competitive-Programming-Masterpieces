package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
    String []arr = new String[25];
    arr[0] = "ITMO";
        arr[1] = "SPbSU";
        arr[2] = "SPbSU";
        arr[3] = "ITMO";
        arr[4] = "ITMO";
        arr[5] = "SPbSU";
        arr[6] = "ITMO";
        arr[7] = "ITMO";
        arr[8] = "ITMO";
        arr[9] = "ITMO";
        arr[10]= "ITMO";
        arr[11] = "PetrSu, ITMO";
        arr[12] = "SPbSU";
        arr[13] = "SPbSU";
        arr[14] = "ITMO";
        arr[15] = "ITMO";
        arr[16]= "ITMO";
        arr[17] = "ITMO";
        arr[18] = "SPbSU";
        arr[19] = "ITMO";
        arr[20] = "ITMO";
        arr[21] = "ITMO";
        arr[22] = "ITMO";
        arr[23] = "1995";
        arr[24] = "ITMO";
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        if(n>1995 && n<2019) System.out.print(arr[n-1995]);

    }
}
