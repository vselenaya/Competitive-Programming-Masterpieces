#include <iostream>
#include <string>
#include <unordered_map>
using namespace std;
int main()
{
    //freopen("input.txt", "r", stdin);
    int a,x,b,y,t;
    cin >> a >> x >> b >> y >> t;
    int ans1 = a, ans2 = b;
    if(t>30)ans1+=x*(t-30)*21;
    if(t>45)ans2+=y*(t-45)*21;
    cout << ans1 << ' ' << ans2;
}
