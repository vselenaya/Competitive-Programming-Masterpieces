#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> pii;
typedef pair<long long, long long> pll;
typedef long long ll;
typedef unsigned int ui;
typedef unsigned long long ull;
typedef long double ld;

const int inf = 1e9;
const ll inf64 = 1e18;

int priority(string op) {
    if (op == "not")
        return 2;
    else if (op == "and")
        return 1;
    else if (op == "or")
        return 0;
    else
        return -1;
}

int parse(string s, int mask) {
    vector<int> st;
    vector<string> op;
    auto process = [&](string operation) {
        if (operation == "not") {
            st.back() ^= 1;
            return;
        }
        int r = st.back();
        st.pop_back();
        int l = st.back();
        st.pop_back();
        int x = operation == "and" ? (l & r) : (l | r);
        st.push_back(x);
    };
    for (int i = 0; i < (int) s.size(); i++) {
        if (s[i] == ' ')
            continue;
        if (s[i] == '(') {
            op.emplace_back("(");
        } else if (s[i] == ')') {
            while (op.back() != "(")
                process(op.back()), op.pop_back();
            op.pop_back();
        } else if (s.substr(i, 3) == "and" || s.substr(i, 2) == "or" || s.substr(i, 3) == "not") {
            string operation = s[i] == 'a' ? "and" : s[i] == 'o' ? "or" : "not";
            int cur_prior = priority(operation);
            while (!op.empty() && priority(op.back()) >= cur_prior)
                process(op.back()), op.pop_back();
            op.push_back(operation);
            i = i + (int) operation.size() - 1;
        } else if ('a' <= s[i] && s[i] <= 'h') {
            int x = (mask >> (s[i] - 'a')) & 1;
            st.push_back(x);
        }
    }
    while (!op.empty())
        process(op.back()), op.pop_back();
    return st.back();
}

int main() {

#ifdef DEBUG
    freopen("input.txt", "r", stdin);
#endif

    ios_base::sync_with_stdio(0);
    cin.tie(0);

    string s;
    getline(cin, s);

    const int N = 8;
    vector<int> f(1 << N);
    for (int mask = 0; mask < (1 << N); mask++) {
        f[mask] = parse(s, mask);
    }

//    mt19937 rnd(time(NULL));
//    for (int mask = 1; mask < (1 << N) - 1; mask++) {
//        f[mask] = rnd() % 2;
//    }
//    for (int mask = 1; mask < (1 << N); mask++) {
//        for (int i = 0; i < N; i++) {
//            if ((1 << i) & mask) {
//                f[mask] |= f[mask ^ (1 << i)];
//            }
//        }
//    }

    for (int mask = 1; mask < (1 << N); mask++) {
        for (int i = 0; i < N; i++) {
            if ((1 << i) & mask) {
                int sub_mask = mask ^ (1 << i);
                if (f[sub_mask] > f[mask]) {
                    cout << "IMPOSSIBLE\n";
                    return 0;
                }
            }
        }
    }

    vector<int> min_masks;

    for (int mask = 0; mask < (1 << N); mask++) {
        if (!f[mask])
            continue;
        int ok = 1;
        for (int i = 0; i < N; i++) {
            if ((1 << i) & mask) {
                int sub_mask = mask ^ (1 << i);
                if (f[sub_mask]) {
                    ok = 0;
                    break;
                }
            }
        }
        if (ok) {
            min_masks.push_back(mask);
//            for (int i = 0; i < N; i++) {
//                if ((1 << i) & mask)
//                    cout << char('a' + i);
//            }
//            cout << "\n";
        }
    }

    if (f[(1 << N) - 1] == 0) {
        cout << "+-+\n";
        return 0;
    }

    if (f[0] == 1) {
        cout << "+ +\n";
        return 0;
    }

    assert(!min_masks.empty());

//    cout << min_masks.size() << "\n";
//    return 0;

    const int W = 50;
    const int H = 50;

    vector<string> mat(H, string(W, ' '));

    mat[0][0] = '*';

    int down = 1, r = 0, c = 0;
    for (int it = 0; it < (int) min_masks.size(); it++) {
        if (down && r + 1 >= H - 1) {
            for (int j = 0; j < N; j++)
                mat[r][c + j] = '*';
            for (int i = r; i < H; i++)
                mat[i][c] = '*';
            for (int j = c; j <= c + N + 1; j++)
                mat[H - 1][j] = '*';
            r = H - 1, c = c + N + 1;
            down = 0;
        }
        if (!down && r - 1 < 1) {
            for (int j = 0; j < N; j++)
                mat[r][c + j] = '*';
            for (int i = r; i >= 0; i--)
                mat[i][c] = '*';
            for (int j = c; j <= c + N + 1; j++)
                mat[0][j] = '*';
            r = 0, c = c + N + 1;
            down = 1;
        }
//        cout << "(" << r << ", " << c << ")\n";
        int mask = min_masks[it];
        if (down) {
            assert(r + 1 < H && c + N - 1 < W);
            for (int j = 0; j < N; j++)
                mat[r][c + j] = '*';
            for (int j = 0; j < N; j++) {
                if ((1 << j) & mask)
                    mat[r + 1][c + j] = char(j + 'a');
            }
            r += 2;
        } else {
            assert(r - 1 >= 0 && c + N - 1 < W);
            for (int j = 0; j < N; j++)
                mat[r][c + j] = '*';
            for (int j = 0; j < N; j++)
                if ((1 << j) & mask)
                    mat[r - 1][c + j] = char(j + 'a');
            r -= 2;
        }
    }

    mat[r][c] = '*';
    while (c + 1 < W)
        mat[r][++c] = '*';
    while (r > 0)
        mat[--r][c] = '*';

    vector<vector<int>> to_del(H, vector<int>(W));

    mat[0][0] = mat[0][W - 1] = '+';
    while (1) {
        int any = 0;
        for (int i = 0; i < (int) mat.size(); i++) {
            for (int j = 0; j < (int) mat[i].size(); j++) {
                if (mat[i][j] == '*') {
                    int hor = int(j > 0 && mat[i][j - 1] != ' ') + int(j + 1 < W && mat[i][j + 1] != ' ');
                    int ver = int(i > 0 && mat[i - 1][j] != ' ') + int(i + 1 < H && mat[i + 1][j] != ' ');
                    if (hor + ver <= 1) {
                        any = 1;
                        to_del[i][j] = 1;
                    }
                }
            }
        }
        for (int i = 0; i < H; i++)
            for (int j = 0; j < W; j++)
                if (to_del[i][j])
                    mat[i][j] = ' ';
        if (!any)
            break;
    }

    mat[0][0] = mat[0][W - 1] = '+';
    for (int i = 0; i < (int) mat.size(); i++) {
        for (int j = 0; j < (int) mat[i].size(); j++) {
            if (mat[i][j] == '*') {
                int hor = (j > 0 && mat[i][j - 1] != ' ') || (j + 1 < W && mat[i][j + 1] != ' ');
                int ver = (i > 0 && mat[i - 1][j] != ' ') || (i + 1 < H && mat[i + 1][j] != ' ');
                if (hor && ver)
                    mat[i][j] = '+';
                else if (hor)
                    mat[i][j] = '-';
                else if (ver)
                    mat[i][j] = '|';
                else
                    assert(false);
            }
        }
    }

    for (auto row : mat)
        cout << row << "\n";

    return 0;
}
