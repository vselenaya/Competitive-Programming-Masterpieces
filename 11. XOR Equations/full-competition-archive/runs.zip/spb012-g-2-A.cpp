#include <algorithm>
#include <bitset>
#include <cstdlib>
#include <iostream>
#include <random>
#include <set>
#include <vector>

// #define FAST_ALLOCATOR_MEMORY 256000000
// #include "optimization.h"
#include <bits/stdc++.h>

using namespace std;

// #define USE_INT128
// #define int int64_t

// #undef _DEBUG

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()

#ifdef USE_INT128
#define lint __int128
#define ulint __int128
#else
#define lint int64_t
#define ulint int64_t
#endif

typedef long double ld;
// #define f first
// #define s second
typedef pair<int, int> pint;

const int inf = (1 << 30) - 1;

template <class T>
T mineq(T& a, const T& b) {
    return a = min(a, b);
}

template <class T>
T maxeq(T& a, const T& b) {
    return a = max(a, b);
}

mt19937 rd(533);
// end of default file

// typedef __int128_t len_t;

const uint64_t MAX_D = UINT64_MAX / 32;

struct len_t {
    len_t(int64_t v) {
        d0 = v % MAX_D;
        d1 = v / MAX_D;
    }
    len_t(int64_t d0, int64_t d1)
        : d0(d0)
        , d1(d1) {
        d1 += d0 / MAX_D;
        d0 = d0 % MAX_D;
    }

    len_t operator+(const len_t& other) const {
        uint64_t d1_res = d1 + other.d1;
        uint64_t d0_res = d0 + other.d0;
        if (d0_res >= MAX_D) {
            d0_res -= MAX_D;
            d1_res++;
        }
        return len_t(d0_res, d1_res);
    }

    bool operator<(const len_t& oth) const {
        if (d1 < oth.d1)
            return true;
        return d0 < oth.d0;
    }

    bool operator==(const len_t& oth) const {
        return (d1 == oth.d1 && d0 == oth.d0);
    }

    uint64_t d0, d1;
};
const len_t LINF(0, 0);

ostream& operator<<(ostream& out, len_t x) {
    if (x == len_t(0)) {
        out << 0;
        return out;
    }

    vector<int> digits;
    while (x.d0 != 0 || x.d1 != 0) {
        int d0_r = x.d0 % 10;
        x.d0 /= 10;
    
        int64_t d1_r10 = x.d1 % 10;
        int64_t d1_m10 = x.d1 / 10;

        int d1_r = (d1_r10 * MAX_D) % 10;

        x.d1 = d1_m10;
        x = x + len_t(d1_r10 * MAX_D);

        digits.push_back((d0_r + d1_r) % 10);
    }

    for (int i = digits.size() - 1; i >= 0; i--) {
        cout << digits[i];
    }

    return out;
}

// ostream& operator<<(ostream& out, __int128_t x) {
//     bool neg = (x < 0);
//     if (neg) x = -x;
//     if (x == 0) {
//         out << 0;
//         return out;
//     }

//     vector<int> digits;
//     while (x > 0) {
//         digits.push_back(x % 10);
//         x /= 10;
//     }
    
//     if (neg) {
//         out << '-';
//     }
//     for (int i = digits.size() - 1; i >= 0; i--) {
//         out << digits[i];
//     }

//     return out;
// }

struct red {
    int8_t from;
    int8_t t1;
    int8_t t2;
};

struct red_term {
    int8_t from;
    int8_t to;
};

struct mat {
    mat(int n)
        : lens(n, vector<len_t>(n, LINF)) {}

    vector<vector<len_t>> lens;

    len_t& len(int u, int v) {
        return lens[u][v];
    }
};

int32_t main() {
    // srand(5332017);
    ios::sync_with_stdio(false);
    cin.tie();
    cout.tie();
    cout << fixed;
    cout.precision(4); // !!

#ifdef _DEBUG
    // // init();
    freopen("input.txt", "r", stdin);
    // int seed;
    // cin >> seed;
    // rd = mt19937(seed);
    // // freopen("output.txt", "w", stdout);
#else
    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
#endif

    int p;
    cin >> p;

    vector<red> reds;
    vector<red_term> redt;

    for (int i = 0; i < p; i++) {
        char fr;
        string trash, to;
        cin >> fr >> trash >> to;
        if (to.size() == 2) {
            red r;
            r.from = fr - 'A';
            r.t1 = to[0] - 'A';
            r.t2 = to[1] - 'A';
            reds.push_back(r);
        } else {
            red_term r;
            r.from = fr - 'A';
            r.to = to[0] - 'a';
            redt.push_back(r);
        }
    }

    int n, m, s, t;
    cin >> n >> m >> s >> t;
    s--, t--;
    vector<vector<pair<int, int>>> char_e(26);

    for (int i = 0; i < m; i++) {
        int u, v;
        char c;
        cin >> u >> v >> c;
        u--, v--;
        char_e[c - 'a'].push_back({ u, v });
    }

    vector<mat> path('Z' - 'A', mat(n));

    for (auto red : redt) {
        for (const auto &uv : char_e[red.to]) {
            path[red.from].len(uv.first, uv.second) = len_t(1);
        }
    }

    for (int iter = 0; iter < 300; iter++) {
        for (auto rule : reds) {
            for (int i = 0; i < n; i++) {
                for (int k = 0; k < n; k++) {
                    for (int j = 0; j < n; j++) {
                        const len_t try_len = path[rule.t1].len(i, k) + path[rule.t2].len(k, j);
                        if (try_len < path[rule.from].len(i, j)) {
#ifdef _DEBUG
                            cerr << (char)(rule.from + 'A') << ' ' << i << ' ' << j << endl;
#endif
                            path[rule.from].len(i, j) = try_len;
                        }
                            // mineq(
                            //     path[rule.from].len(i, j),
                            //     path[rule.t1].len(i, k) + path[rule.t2].len(k, j));
                    }
                }
            }
        }
    }

    len_t len_st = path['S' - 'A'].len(s, t);
    if (LINF < len_st || LINF == len_st) {
        cout << "NO\n";
    } else {
        cout << len_st << '\n';
    }

asdasd
    // cerr << (len_t(1));

    return 0;
}
