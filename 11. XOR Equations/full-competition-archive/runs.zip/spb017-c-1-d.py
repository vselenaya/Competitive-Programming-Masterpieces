import math

"""
n, p = list(map(float, input().split(' ')))
n = int(n)
c = list(map(int, input().split(' ')))

pos_count = 0
neg_count = 0

k0 = 0
k1 = k0 + 3

arr = c[k0:k1]

def toFixed(numObj, digits=0):
    return float(f"{numObj:.{digits}f}")


while not (k0 == len(c)-2):

    print(arr)

    sum_a = 0
    for i in range(1, len(arr)):
        sum_a += (arr[i] - arr[i-1])

    a = (1/n)*(sum_a)
    a = sum(arr)/n
    sum_d = 0
    for i in range(len(arr)):
        #sum_d += ((arr[i] - arr[i-1] - a)*(arr[i] - arr[i-1] - a))
        sum_d += (arr[i] - sum(arr)/n)**2

    d = math.sqrt((1/(n))*(sum_d))
    if a == 0:
        pass
    else:
        if d == 0:
            if a > 0:
                pos_count += 1
            if a < 0:
                neg_count += 1
        else:
            print(a, d)
            print(a / d, p)
            if a/d >= p:

                pos_count += 1

            elif a/d <= (-1)*p:
                neg_count += 1

    k1 += 1
    if k1 > len(c):
        k0 += 1
        k1 = k0 + 3
        if k1 > len(c):
            break

    arr = c[k0:k1]

print(pos_count, neg_count)




"""

def f(n):

    for i in range(n):
        print(i, i + 1)
        a = input()
        if (a == "WIN"):
            return True

    for i in range(n, 2, -1):
        print( i - 1, i )
        b = input()
        if (b == "WIN"):
            return True

    for i in range(2):
        print(n - 1, n)
        c = input()
        if (c == "WIN"):
            return True

    return False



k = int(input())

while (not f(k)):
    pass



