_, P = [float(x) for x in input().split()]
arr = [int(x) for x in input().split()]
def A(sub):
    s = 0
    for i in range(1,len(sub)):
        s += sub[i]-sub[i-1]
    return s/(len(sub)-1)

def D(sub, a):
    s = 0
    for i in range(1,len(sub)):
        s += (sub[i] - sub[i-1] - a) ** 2
    return (s/(len(sub)-1))**0.5

pn = [0, 0]
for i in range(len(arr)-1):
    for j in range(i+3,len(arr)+1):
        sub = arr[i:j]
        a = A(sub)
        d = D(sub, a)
        if a == 0:
            continue
        if a > 0 and d == 0:
            pn[0] += 1
        elif a < 0 and d == 0:
            pn[1] += 1
        elif a/d >= P:
            pn[0] += 1
        elif a/d <= -P:
            pn[1] += 1
print(pn[0], pn[1])