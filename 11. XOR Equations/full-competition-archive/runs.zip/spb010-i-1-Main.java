package com.company;

import java.util.Scanner;

public class Main {
    public static int a = -1;
    public static int b = -1;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int s = sc.nextInt();
        int x1 = 0, x2 = 0 , x3 = 0 , x4 = 0, y1 = 0, y2 = 0 , y3 = 0 , y4 = 0;
        boolean flag = false;
        double sqrtS = Math.sqrt(s);
        if (sqrtS == Math.floor(sqrtS)) {
            flag = true;
            int intSqrtS = (int) sqrtS;
            x1 = 0;
            y1 = 0;
            x2 = 0;
            y2 = intSqrtS;
            x3 = intSqrtS;
            y3 = 0;
            x4 = intSqrtS;
            y4 = intSqrtS;

        } else if (canSqr(s)) {
            flag = true;
            x1 = 0; y1 = b; x2 = a; y2 = 0; x3 = b; y3 = b+a; x4 = b+a; y4 = a;
        }
        if(flag == true){
            System.out.println(x1 + " " + y1);
            System.out.println(x2 + " " + y2);
            System.out.println(x3 + " " + y3);
            System.out.println(x4 + " " + y4);

        }
        else
            System.out.println("Impossible");
    }

    static boolean canSqr(int s) {
        int sqrtS = (int) Math.sqrt(s);
        for (int i = 0; i <= sqrtS; i++)
            for (int j = i; j <= sqrtS; j++) {
                if (i * i + j * j == s) {
                    a = j;
                    b = i;
                    return true;
                }
            }
        return false;
    }
}