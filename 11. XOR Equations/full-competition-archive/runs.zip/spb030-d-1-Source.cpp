#include <iostream>
#include <vector>
#include <algorithm>
#include <map>

using namespace std;
#define ll long long
#define FOR(i,a,b) for(int i=a;i<b;i++)
int main()
{
	ll n, w, h, r;
	char ch;
	cin >> n >> w >> h >> r;
	map<char, ll> MAP;
	char MaxChar = '$';
	ll MaxVal = -1;


	FOR(i, 0, n)
	{
		cin >> ch;
		MAP[ch] = 0;
		FOR(j, 0, h)
		{
			bool bInResh = false;
			ll exVal = 0;
			FOR(k, 0, w)
			{
				char buf;
				cin >> buf;
				if (buf == '#' && !bInResh)
				{
					exVal += 2;
					bInResh = true;
				}
				if(buf != '#')
					bInResh = false;
			}
			if (exVal > MAP[ch])
				MAP[ch] = exVal;
		}
		if (MaxVal == -1 || MaxVal < MAP[ch])
		{
			MaxVal = MAP[ch];
			MaxChar = ch;
		}
	}

	ll kol = r / MaxVal;
	if (r%MaxVal != 0)
		kol++;
	FOR(i, 0, kol)
	{
		cout << MaxChar;
	}
	cout << "\n";

	//system("pause");
	return 0;
}