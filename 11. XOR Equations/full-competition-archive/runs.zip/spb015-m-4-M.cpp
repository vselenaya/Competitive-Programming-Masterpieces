#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>

using namespace std;

int main() {
	int count = 0;

	cin >> count;
	vector<int> arr = vector<int>(count + 1);
	arr[0] = 0;

	for (int i = 1; i < count + 1; i++)
	{
		cin >> arr[i];
	}

	std::sort(arr.begin(), arr.end());

	int diff = 0;
	for (int i = 0; i < arr.size() - 1; i++) {

		int mod = abs(arr[i] - arr[i + 1]);
		if (mod > diff)
			diff = mod;
	}

	for (int i = 0; i < arr.size() - 2; i++) {
		int mod2 = abs(arr[i] - arr[i + 2]);
		if (mod2 <= diff) {
			diff = 0;
			break;
		}
	}

	cout << diff;
}