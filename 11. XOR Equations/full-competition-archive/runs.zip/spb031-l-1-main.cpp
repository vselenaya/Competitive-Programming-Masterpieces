#ifdef DEBUG_MODE
#define _GLIBCXX_DEBUG 1
#endif
#pragma comment(linker, "/stack:200000000")
#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx")

#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

ll t;

vector<int> ask(const vector<int> &v) {
    cout << "? ";
    for (auto i : v) {
        cout << i + 1 << " ";
    }
    cout << "\n";
    cout.flush();
    vector<int> ans(v.size());
    for (int i = 0; i < v.size(); ++i) {
        cin >> ans[i];
    }
    return ans;
}

vector<int> solve1() {
    ll n;
    cin >> n;
    vector<int> next(n);

    vector<int> f1(n);
    for (int i = 0; i < n; ++i) {
        f1[i] = (i + 1) % n;
    }

    vector<int> f2(n);
    for (int i = 0; i < n; ++i) {
        f2[i] = i;
    }
    // 0 and 1 swap
    f2[0] = 1;
    f2[1] = 0;

    int a = 0;
    for (auto toval : ask(f1)) {
        next[a] = toval;
        ++a;
    }

    // swap 0 1
    vector<int> changed;

    a = 0;
    for (auto toval : ask(f2)) {
        if (toval != a) {
            changed.push_back(a);
        }
        ++a;
    }
    if (changed.size() != 2) {
        exit(1);
    }

    ll first = -1;
    if (next[changed[0]] == changed[1]) {
        first = changed[0];
    } else if (next[changed[1]] == changed[0]) {
        first = changed[1];
    } else {
        exit(1);
    }

    vector<int> ans(n);
    for (int i = 0; i < n; ++i) {
        ans[i] = first;
        first = next[first];
    }

    return ans;
}

void solve() {
    cin >> t;
    while (t--) {
        vector<int> ans = solve1();
        cout << "! ";
        for (auto i : ans) {
            cout << i << " ";
        }
        cout << "\n";
        cout.flush();
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);

#ifdef DEBUG_MODE
    //freopen("input.txt", "r", stdin);
#endif

    solve();

    return 0;
}