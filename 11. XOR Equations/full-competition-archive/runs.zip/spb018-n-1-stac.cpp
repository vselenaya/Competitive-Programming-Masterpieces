﻿#include <iostream>
#include <vector>

using namespace std;

typedef long long Qwe;

#define forn(i,n) for (Qwe i = 0;i < Qwe(n);i++)
#define ford(i,n) for (Qwe i = Qwe(n)-1;i >=0;i--)
#define fore(i,l,r) for (Qwe i = Qwe(l);i < Qwe(r);i++)
#define forv(v,arr) for (auto& v : (arr))
#define correct(x,n) (((x) >= 0) && ((x) < n))
#define all(a) (a).begin(),(a).end()
#define rnd() (rand() + (RAND_MAX+1)*rand())



using vi = vector<Qwe>;

using vvi = vector < vector < Qwe>>;


int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);

	vvi _c(51, vi(51, 0));
	fore(i, 0, 51) fore(j, 0, 51)
	{
		if (i < j)
		{
			_c[i][j] = 0;
			continue;
		}
		if (i == j || j == 0)
		{
			_c[i][j] = 1;
			continue;
		}
		_c[i][j] = _c[i - 1][j - 1] + _c[i - 1][j];
	}

	auto c = [&](Qwe n1, Qwe k1)
	{
		if (n1 < k1)
			return 0LL;
		return _c[n1][k1];
	};

	Qwe n, k;
	cin >> n >> k;
	Qwe res = 0;
	fore(i, max(0ll, k - n), k + 1)
	{
		Qwe d = c(n, i);
		if (n % 2)
			d += c(n / 2, i / 2);
		else
			d += c(n / 2, i / 2) * (i % 2 == 0);
		d /= 2;
		res += d;
		if (i * 2 == k)
			res += d;
	};
	cout <<  res << endl;
}