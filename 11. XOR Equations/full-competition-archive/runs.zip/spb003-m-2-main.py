n = int(input())
cards = input().split(' ')
cards = [int(item) for item in cards]
cards.sort()
cards.insert(0, 0)
razn = list()
razn_2 = list()
for i in range(1, n):
    razn.append(cards[i+1] - cards[i])
for i in range(1, n-1):
    razn_2.append(cards[i+2] - cards[i])
max_razn = max(razn)
min_razn_2 = max(razn_2)
if max_razn < min_razn_2:
    print(max_razn)
else:
    print(0)



