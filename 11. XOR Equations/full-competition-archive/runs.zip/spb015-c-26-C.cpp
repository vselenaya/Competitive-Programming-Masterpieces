﻿#include <random>
#include <numeric>
#include <iostream>
#include <ctime>
#include <algorithm>
using namespace std;

int main()
{
  int cards = 0;
  cin >> cards;
 /* int step = 1;*/

  int* arr = new int[cards];
  for (int i = 0; i < cards; i++)
  {
    arr[i] = i+1;
  }

  unsigned seed = 0;
  shuffle(arr, arr + cards,
    default_random_engine(seed));


  while (true)
  {
    srand(time(0));
    int c = cards - 1;
    int i = rand() % c;
    int j = rand() % c + i;

    cout << i+1 << " " << j+1 << endl;
    cout.flush();

    string input;
    cin >> input;

    if (input == "WIN")
    {
      return 0;
    }

    if (input == "SWAPPED")
    {
      int tmp = arr[i];
      arr[i] = arr[j];
      arr[j] = tmp;
     /* step++;*/
    }

    if (input == "STAYED")
    {
     /* step++;*/
    }

    /*
    if (step % 2 == 0) 
    {
      int m = rand() % c;
      int n = rand() % c + m;
      int tmp = arr[m];
      arr[m] = arr[n];
      arr[n] = tmp;
    }*/
  }
}
