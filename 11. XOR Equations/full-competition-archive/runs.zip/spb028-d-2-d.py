n, w, h, s = [int(x) for x in input().split()]
ch = []
pr=''
a = []
for p in range(n):
    ch.append(input())
    x = 0
    for i in range(h):
        x=0
        pr = input()
        if pr[0]=="#": x += 1
        if pr[w-1]=="#": x += 1
        x = x + pr.count(".#") + pr.count("#.")
        a.append(x)
print(ch)
print(a)
ma = max(a)
m = list(a).index(ma) + 1
print(m)
op = 0
cnt = s//ma
if ma*cnt < s:
    cnt += 1
for i in range(n):
    if (m<(h*(i+1)-1)) and (m>(h*i)): op = i
print(ch[op]*(cnt))