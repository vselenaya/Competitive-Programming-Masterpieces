# D
from math import ceil

n, w, h, s = map(int, input().split())
d = {}

for i in range(n):
    sym = input()
    maxk = 0

    for _ in range(h):
        k = 0
        ss = '.' + input() + '.'
        for j in range(len(ss) - 1):
            if (ss[j] != ss[j+1]):
                k += 1
        maxk = max(k, maxk)
    d[sym] = maxk

lMax = ("a", 0)
for i in d:
    print(i, d[i])
    if (d[i] > lMax[1]):
        lMax = (i, d[i])
print(lMax[0]*ceil(s / lMax[1]))
