#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <queue>
#include <deque>
#include <stack>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <cassert>
#include <cstddef>
#include <cstring>
#include <bitset>
#include <random>
#include <memory>
#include <iomanip>

typedef long long ll;
typedef long double ld;

using namespace std;

int p, n, m, s, t;
const int MX = 26;
vector<pair<int, int>> gram[MX];
vector<int> term[MX];
vector<pair<int, int>> g[MX];
int matr[MX][MX];

void read() {
    for (int i = 0; i < MX; i++) {
        for (int j = 0; j < MX; j++) {
            matr[i][j] = -1;
        }
    }

    cin >> p;
    string str;
    getline(cin, str);
    for (int i = 0; i < p; i++) {
        getline(cin, str);
        if (str.length() == 6) {
            term[str[0] - 'A'].push_back(str[5] - 'a');
        } else {
            gram[str[0] - 'A'].push_back({str[5] - 'A', str[6] - 'A'});
        }
    }
    cin >> n >> m >> s >> t;
    s--, t--;
    for (int i = 0; i < m; i++) {
        int a, b;
        char c;
        cin >> a >> b >> c;
        a--, b--;
        g[a].push_back({b, c - 'a'});
        matr[a][b] = c - 'a';
    }

}



struct vert {
    int a, b, l;

    bool operator <(const vert& o) const {
        if (a != o.a) return a < o.a;
        if (b != o.b) return b < o.b;
        return l < o.l;
    }
};

int bit = 60;
ll VAL = 1ll << bit;
const ll MASK = (1ll << bit) - 1;
ll INF = MASK;

struct my_long {
    vector<ll> a;
    int sign = 1;

    friend my_long operator+(const my_long& a, const my_long& b) {
        vector<ll> c(max(a.a.size(), b.a.size()));
        for (int i = 0; i < (int)a.a.size(); i++) c[i] += a.a[i];
        for (int i = 0; i < (int)b.a.size(); i++) c[i] += b.a[i];

        for (int i = 0; i + 1 < (int)c.size(); i++) {
            if (c[i] >= VAL) {
                c[i + 1] += c[i] >> bit;
                c[i] -= VAL;
            }
        }
        ll d = c.back();
        if (d >= VAL) {
            c.back() -= VAL;
            c.push_back(d >> bit);
        }
        return {c, 1};
    }

    my_long operator-() {
        return my_long({a, -sign});
    }

    bool operator<(const my_long& o) const {
        if (a.size() != o.a.size()) {
            return (a.size() < o.a.size()) ^ (sign == -1);
        }

        for (int i = (int)a.size() - 1; i >= 0; i--) {
            if (a[i] != o.a[i]) {
                return (a[i] < o.a[i]) ^ (sign == -1);
            }
        }
        return false;
    }


    bool operator!=(const my_long& o) {
        if (a.size() != o.a.size()) return 1;

        for (int i = 0; i < (int)a.size(); i++)
            if (a[i] != o.a[i]) return 1;

        return false;
    }
};

void print(const my_long& a) {
    vector<int> pw(a.a.size() * 64);
    vector<int> ans(a.a.size() * 64);
    pw[0] = 1;
    for (int k = 0; k < (int)a.a.size(); k++) {
        for (int i = 0; i < bit; i++) {
            if (a.a[k] & (1ll << i)) {
                for (int j = 0; j < (int)pw.size(); j++) {
                    ans[j] += pw[j];
                    if (ans[j] >= 10) {
                        ans[j + 1] += 1;
                        ans[j] -= 10;
                    }
                }
            }

            for (int j = 0; j < (int)pw.size(); j++) {
                pw[j] *= 2;
            }
            for (int j = 0; j < (int)pw.size(); j++) {
                if (pw[j] >= 10) {
                    pw[j + 1] += 1;
                    pw[j] -= 10;
                }
            }
        }
    }

    while (ans.size() >= 1 && ans.back() == 0) {
        ans.pop_back();
    }

    for (int i = (int)ans.size() - 1; i >= 0; i--) {
        cout << ans[i];
    }
    cout << '\n';
}

my_long d[MX][MX][MX];

my_long get_d(const vert& q) {
    return d[q.a][q.b][q.l];
}


my_long make_inf() {
    return {vector<ll>(20, INF), 1};
}

void solve() {
    for (int i = 0; i < MX; i++) {
        for (int j = 0; j < MX; j++) {
            for (int k = 0; k < MX; k++)  {
                d[i][j][k] = make_inf();
            }
        }
    }

    priority_queue<pair<my_long, vert>> q;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < MX; k++) {
                for (int c : term[k]) {
                    if (matr[i][j] == c) {
                        d[i][j][k] = {{1}, 1};
                        q.push({-d[i][j][k], {i, j, k}});
                    }
                }
            }
        }
    }


    while (!q.empty()) {
        pair<my_long, vert> v = q.top();
        q.pop();

        if (-v.first != get_d(v.second)) continue;

        for (int tp = 0; tp < MX; tp++) {
            for (const pair<int, int>& t: gram[tp]) {
                if (t.first == v.second.l) {
                    for (int to = 0; to < n; to++) {
                        if (my_long dist = d[v.second.a][v.second.b][t.first] + d[v.second.b][to][t.second]; dist < d[v.second.a][to][tp]) {
                            d[v.second.a][to][tp] = dist;
                            q.push({-dist, {v.second.a, to, tp}});
                        }
                    }
                }
                if (t.second == v.second.l) {
                    for (int to = 0; to < n; to++) {
                        if (my_long dist = d[to][v.second.a][t.first] + d[v.second.a][v.second.b][t.second]; dist < d[to][v.second.b][tp]) {
                            d[to][v.second.b][tp] = dist;
                            q.push({-dist, {to, v.second.b, tp}});
                        }
                    }
                }
            }
        }

    }

    if (d[s][t]['S' - 'A'] != make_inf()) {
        my_long ans = d[s][t]['S' - 'A'];
        print(ans);
    } else {
        cout << "NO\n";
    }

}

int main() {

#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    ios_base::sync_with_stdio(0);


    read();
    solve();

    return 0;
}
