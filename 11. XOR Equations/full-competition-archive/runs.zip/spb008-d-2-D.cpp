#include "iostream"
#include "string"
#include "vector"
#include "cmath"

int main()
{
    int n, w, h, s;
    std::cin >> n >> w >> h >> s;
    int max_s = 0;
    char max_s_c;
    for (int i = 0; i < n; i++)
    {
        char c;
        std::cin >> c;
        for (int j = 0; j < h; j++)
        {
            int curr_s = 0;
            char p;
            std::cin >> p;
            if (p == '#')
                curr_s++;
            for (int h = 1; h < w; h++)
            {
                char t;
                std::cin >> t;
                if (p != t)
                {
                    curr_s++;
                }
                p = t;
            }
            if (p == '#')
                curr_s++;
            if (curr_s > max_s)
            {
                max_s = curr_s;
                max_s_c = c;
            }
        }
    }

    std::cout << max_s << std::endl;

    for (int i = 0; i < std::ceil(1.0 * s / max_s); i++)
    {
        std::cout << max_s_c;
    }
    return 0;
}