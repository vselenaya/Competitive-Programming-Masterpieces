﻿#include <map>
#include <iostream>
#include <cassert>

using namespace std;

int main()
{
    long long count;
    cin >> count;
    long long* array = new long long[count];
    for (int i = 0; i < count; i++)
        cin >> array[i];
    int temp, current = 0, min = 0;

    for (int i = 0; i < count - 1; ++i) 
    {
        for (int j = 0; j < count - 1; ++j)
        {
            if (array[j + 1] < array[j])
            {
                temp = array[j + 1];
                array[j + 1] = array[j];
                array[j] = temp;
            }
        }
    }
    min = array[0];
    int tempgap,gap = min;

    for (int i = 0; i < count - 1; i++) {
        tempgap = array[i + 1] - array[i];
        if (tempgap > gap)
            gap = tempgap;
    }

    if (gap > array[1] || gap < min)
        cout << "0";
    else
        cout << gap;

    return 0;
}

