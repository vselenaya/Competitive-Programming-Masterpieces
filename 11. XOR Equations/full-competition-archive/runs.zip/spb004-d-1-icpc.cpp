﻿#define _CRT_SECURE_NO_WARNINGS

#include <algorithm>
#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <cmath>
#include <queue>
#include <map>
#include <set>

using namespace std;

#pragma GCC optimize ("-O3")

#define wt int t; cin>>t; while(t--)
#define all(v) v.begin(),v.end()
#define max(a,b) (a>b?a:b)
#define min(a,b) (a<b?a:b)
#define max3(a,b,c) max(max(a,b),max(a,c))
#define min3(a,b,c) min(min(a,b),min(a,c))
#define pi 3.141592653
#define ll long long
#define ull unsignate long long

struct ch
{
    char cha;
    vector<vector<bool>> map;
};
int main()
{
    freopen("a.in", "r", stdin);
    freopen("a.out", "w", stdout);

    int n = 0, w = 0, h = 0, s = 0;
    cin >> n >> w >> h >> s;
    int size = w * h;

    vector<ch> vec;

    int j = 0;
    char ochar;

    while (cin >> ochar)
    {
        vec.emplace_back();
        vec[j].cha = ochar;

        for (int i = 0; i < size; i++)
        {
            cin >> ochar;
            vec[j].map.emplace_back(ochar == '#');
        }
        j++;
    }

    bool flag = false;
    for (int vi = 0; vi < vec.size(); vi++)
        for (int vj = vi; vj < vec.size(); vj++)
            for (int i = 0; i < size; i++)
            {
                if (vec[vi].map[i] != vec[vj].map[i])
                {
                    while (s--)
                        if (flag)
                        {
                            cout << vec[vi].cha;
                            flag = false;
                        }
                        else
                        {
                            cout << vec[vj].cha;
                            flag = true;
                        }
                    return 0;
                }
            }

    return 0;
}