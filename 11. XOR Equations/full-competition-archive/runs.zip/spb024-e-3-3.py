n, c = map(int, input().split())

l = []
for _ in range(n):
    l.append(list(map(int, input().split())))


def foo(cc, ans):
    for i, e in enumerate(l):
        if ((e[2] == 0) and (e[0] != cc) and (str(i) not in ans)):
            ans += str(i) + ' '
    for i, e in enumerate(l):
        if ((e[2] == 1) and (e[0] == cc) and (str(i) not in ans)):
            s = foo(e[1], str(ans) + str(i) + ' ')
            if (type(s) != bool):
                return s
    
    if (len(ans) == 2 * n):
        return ans
    else:
        return False

list_new = foo(c, '')
if (type(list_new) != bool):
    spc = ' ' 
    print('Yes')
    print(' '.join(map(str,list(map(lambda x: x + 1, map(int, list_new.split()))))))
else:
    print('No')
