#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <queue>
#include <deque>
#include <stack>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <cassert>
#include <cstddef>
#include <cstring>
#include <bitset>
#include <random>
#include <memory>
#include <iomanip>

typedef long long ll;
typedef long double ld;

using namespace std;

int p, n, m, s, t;
const int MX = 26;
vector<pair<int, int>> gram[MX];
vector<int> term[MX];
vector<pair<int, int>> g[MX];
int matr[MX][MX];

void read() {
    for (int i = 0; i < MX; i++) {
        for (int j = 0; j < MX; j++) {
            matr[i][j] = -1;
        }
    }

    cin >> p;
    string str;
    getline(cin, str);
    for (int i = 0; i < p; i++) {
        getline(cin, str);
        if (str.length() == 6) {
            term[str[0] - 'A'].push_back(str[5] - 'a');
        } else {
            gram[str[0] - 'A'].push_back({str[5] - 'A', str[6] - 'A'});
        }
    }
    cin >> n >> m >> s >> t;
    s--, t--;
    for (int i = 0; i < m; i++) {
        int a, b;
        char c;
        cin >> a >> b >> c;
        a--, b--;
        g[a].push_back({b, c - 'a'});
        matr[a][b] = c - 'a';
    }

}

struct vert {
    int a, b, l;

    bool operator <(const vert& o) const {
        if (a != o.a) return a < o.a;
        if (b != o.b) return b < o.b;
        return l < o.l;
    }
};

const ll MASK = (1ll << 60) - 1;
const ll INF = MASK;

struct my_long {
    vector<int> a = {0};

    void print() {
        for (int i = (int) a.size() - 1; i >= 0; i--)
            cout << a[i];
        cout << "\n";
    }

    bool is_inf() const {
        return (int) a.size() == 1 && a[0] == -1;
    }

    my_long operator + (const my_long& o) const {
        vector<int> c(max(a.size(), o.a.size()));
        for (int i = 0; i < (int) a.size(); i++)
            c[i] += a[i];
        for (int i = 0; i < (int) o.a.size(); i++)
            c[i] += o.a[i];
        for (int i = 0; i < (int) c.size(); i++) {
            if (c[i] >= 10) {
                if (i + 1 == (int) c.size())
                    c.push_back(0);
                c[i + 1] += c[i] / 10;
                c[i] %= 10;
            }
        }
        return {c};
    }

    bool operator < (const my_long& o) const {
        if (is_inf())
            return false;
        if (o.is_inf())
            return true;
        if ((int) a.size() < (int) o.a.size())
            return true;
        if ((int) a.size() > (int) o.a.size())
            return false;
        for (int i = (int) a.size() - 1; i >= 0; i--) {
            if (a[i] != o.a[i])
                return (a[i] < o.a[i]);
        }
        return false;
    }
};

void solve() {
    vector<vector<vector<my_long>>> d(MX, vector<vector<my_long>>(MX, vector<my_long>(MX, my_long{{-1}})));

//    priority_queue<pair<my_long, vert>> q;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < MX; k++) {
                for (int c : term[k]) {
                    if (matr[i][j] == c) {
                        d[i][j][k].a = {1};
//                        q.push({-d[i][j][k], {i, j, k}});
                    }
                }
            }
        }
    }

    for (int any = 1; any;) {
        any = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    for (int T = 0; T < MX; T++) {
                        for (const pair<int, int>& item : gram[T]) {
                            if (d[i][k][item.first].is_inf() || d[k][j][item.second].is_inf())
                                continue;
                            my_long tmp = d[i][k][item.first] + d[k][j][item.second];
                            if (tmp < d[i][j][T]) {
                                d[i][j][T] = tmp;
                                any = 1;
                            }
                        }
                    }
                }
            }
        }
    }

    if (!d[s][t]['S' - 'A'].is_inf()) {
        d[s][t]['S' - 'A'].print();
    } else {
        cout << "NO\n";
    }

}

int main() {

#ifdef DEBUG
    freopen("input.txt", "r", stdin);
#endif
    ios_base::sync_with_stdio(0);


    read();
    solve();

    return 0;
}
