#include<iostream>
#include<vector>
#include<algorithm>
#include<map>
#include<set>
#include<cassert>

using namespace std;

const int maxN = 1e5 + 100;
vector<pair<int, int>> g[maxN];
map<pair<int, int>, vector<int>> edge;
int indeg[maxN], outdeg[maxN];
bool visited[maxN];

void dfs(int v) {
  visited[v] = true;
  for (int i = 0; i < g[v].size(); i++) {
    int u = g[v][i].first;
    if (!visited[u]) {
      dfs(u);
    }
  }
}

bool checkeuler(int v) {
  int start = -1;
  int end = -1;
  for (int i = 0; i < maxN; i++) {
    if (abs(indeg[i] - outdeg[i]) > 1)
      return false;
    if(indeg[i] - outdeg[i] == 1) {
      if (end == -1) {
        end = i;
      } else {
        return false;
      }
    }
    if(indeg[i] - outdeg[i] == -1) {
      if (start == -1) {
        start = i;
      } else {
        return false;
      }
    }
  }

  dfs(v);
  for (int i = 0; i < maxN; i++) {
    if (g[i].size() > 0 && visited[i] == false) {
      return false;
    }
  }


  if (start == -1 && end == -1) {
    return true;
  }
  if (start != v) {
    return false;
  }
  if (start == v && end == -1) {
    return false;
  }
  return true;
}

vector<int> findpath(int v) {
  if (g[v].size() % 2 == 1) {
    for (int u = 0; u < maxN; u++) {
      if (u != v && indeg[u] - outdeg[u] == 1) {
        g[u].push_back(make_pair(v, -1));
        if (edge.count(make_pair(u, v)) == 0) {
          edge[make_pair(u, v)] = vector<int>();
        }
        edge[make_pair(u, v)].push_back(-1);
        break;
      }
    }
  }
  //cerr << "added\n";

  vector<int> s;
  vector<int> path;
  s.push_back(v);
  while (!s.empty()) {
    int w = s.back();
    if (g[w].size() > 0) {
      s.push_back(g[w].back().first);
      g[w].pop_back();
    } else {
      s.pop_back();
      path.push_back(w);
    }
  }

  //cerr << "cycle end\n";
  reverse(path.begin(), path.end());
  vector<int> e;
  for(int i = 0; i + 1 < path.size(); i++) {
    //cerr << path[i] + 1 << " " << path[i + 1] + 1 << endl;
    e.push_back(edge[make_pair(path[i], path[i + 1])].back());
    edge[make_pair(path[i], path[i + 1])].pop_back();
  }
  //cerr << "converted\n";
  bool flag = false;
  vector<int> until, after;
  for(int i = 0; i < e.size(); i++) {
    if (e[i] == -1) {
      flag = true;
      continue;
    }
    if (flag == false) {
      until.push_back(e[i]);
    } else {
      after.push_back(e[i]);
    }
  }
  after.insert(after.end(), until.begin(), until.end());
  for (auto k : after) {
    //cerr << k + 1 << " ";
  }
  //cerr << endl;
  return after;
}


int get_i(int e, vector<int> &all) {
  return lower_bound(all.begin(), all.end(), e) - all.begin();
}

int main() {
  int n, v;
  ios::sync_with_stdio(0);
  cin.tie();
  cin >> n >> v;
  vector<pair<pair<int, int>, int>> bad, good;
  vector<int> all;
  all.push_back(v);
  for (int i = 0; i < n; i++) {
    int a, b, w;
    cin >> a >> b >> w;
    if (w == 0) {
      bad.push_back(make_pair(make_pair(a, b), i));
    } else {
      good.push_back(make_pair(make_pair(a, b), i));
    }
    all.push_back(a);
    all.push_back(b);
  }

  sort(all.begin(), all.end());
  all.resize(unique(all.begin(), all.end()) - all.begin());

  for (int i = 0; i < bad.size(); i++) {
    int a = bad[i].first.first;
    int b = bad[i].first.second;
    bad[i].first.first = get_i(a, all);
    bad[i].first.second = get_i(b, all);
  }

  for (int i = 0; i < good.size(); i++) {
    int a = good[i].first.first;
    int b = good[i].first.second;
    good[i].first.first = get_i(a, all);
    good[i].first.second = get_i(b, all);
  }

  v = get_i(v, all);

  vector<pair<int, int>> by_id(n);
  for (int i = 0; i < good.size(); i++) {
    int a = good[i].first.first;
    int b = good[i].first.second;
    int id = good[i].second;
    g[a].push_back(make_pair(b, id));
    outdeg[a]++;
    indeg[b]++;
    if (edge.count(make_pair(a, b)) == 0) {
      edge[make_pair(a, b)] = vector<int>();
    }
    edge[make_pair(a, b)].push_back(id);
    by_id[id] = make_pair(a, b);
  }

  for (int i = 0; i < bad.size(); i++) {
    int a = bad[i].first.first;
    int b = bad[i].first.second;
    int id = bad[i].second;
  }

  if (!checkeuler(v)) {
    cout << "No\n";
    return 0;
  }

 // cerr << "checked\n";
  auto es = findpath(v);
  //cerr << "found\n";
  vector<int> ans;
  vector<bool> used_bad(bad.size(), false);
  bool second_time = false;
  for (int i = 0; i < bad.size(); i++) {
    if(bad[i].first.first != v) {
      used_bad[i] = true;
      ans.push_back(bad[i].second);
    }
  }

  for (int i = 0; i < es.size(); i++) {
    int a = by_id[es[i]].first;
    int b = by_id[es[i]].second;
    if (a != v && !second_time) {
      second_time = true;
      for (int j = 0; j < bad.size(); j++) {
        if(bad[j].first.first != a && !used_bad[j]) {
          used_bad[j] = true;
          ans.push_back(bad[j].second);
        }
      }
    }
    ans.push_back(es[i]);
    if (b != v && !second_time) {
      second_time = true;
      for (int j = 0; j < bad.size(); j++) {
        if(bad[j].first.first != b && !used_bad[j]) {
          used_bad[j] = true;
          ans.push_back(bad[j].second);
        }
      }
    }
  }

  for (int i = 0; i < bad.size(); i++) {
    if (used_bad[i] == false) {
      cout << "No\n";
      return 0;
    }
  }

  cout << "Yes\n";
  for (auto i : ans) {
    cout << i + 1 << "\n";
  }

  return 0;
}
