a=int(input())
x=int(input())
b=int(input())
y=int(input())
t=int(input())
if t<=30:
    a_x=a
else:
    a_x=a+21*x*(t-30)
if t<=45:
    b_x=b
else:
    b_x=b+21*y*(t-45)
print(a_x, b_x)
    