﻿#include <iostream>;

using namespace std;

const int work = 21;

int Option(int a, int x, int T, int free_time) {
    int pay = a;
    if (T <= free_time) 
        return pay;    
    T -= free_time;
    pay += T * x * work;
    return pay;
}

int main() {
    int a, x, b, y, T;
    cin >> a;
    cin >> x;
    cin >> b;
    cin >> y;
    cin >> T;
    int firs = Option(a, x, T, 30);
    int second = Option(b, y, T, 45);
    cout << firs << " " << second;

    return 0;
}