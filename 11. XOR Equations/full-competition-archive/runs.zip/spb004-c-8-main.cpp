﻿#define _CRT_SECURE_NO_WARNINGS
#define IOS ios::sync_with_stdio(0); //cin.tie(0); cout.tie(0);

#include <algorithm>
#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <cmath>
#include <queue>
#include <map>
#include <set>

using namespace std;

#pragma GCC optimize ("-O3")

#define wt int t; cin>>t; while(t--)
#define all(v) v.begin(),v.end()
#define max(a,b) (a>b?a:b)
#define min(a,b) (a<b?a:b)
#define max3(a,b,c) max(max(a,b),max(a,c))
#define min3(a,b,c) min(min(a,b),min(a,c))
#define pi 3.141592653

void a()
{
    vector<string> v = { "ITMO","SPbSU","SPbSU","ITMO","ITMO","SPbSU","ITMO","ITMO","ITMO","ITMO",
        "ITMO","PetrSU, ITMO","SPbSU","SPbSU","ITMO","ITMO","ITMO","ITMO","SPbSU","ITMO",
        "ITMO",
        "ITMO",
        "ITMO",
        "SPbSU",
        "ITMO" };
    int i;
    cin >> i;
    cout << v[i - 1995];

}

void b()
{
    int a, x, b, y, t;
    cin >> a >> x >> b >> y >> t;
    cout << 21 * x * (max(0, t - 30)) + a << ' ' << 21 * y * (max(0, t - 45)) + b;
}

void c()
{
    int n, i = 1, cnt = 0;
    string s;
    cin >> n;

    while (true)
    {
        for (int i = n - 1; i >= n - cnt; i--) //2.1
        {
            cout << i << ' ' << i + 1 << '\n';
            cin >> s;
            if (s == "WIN") return;
        }

        for (int i = 1; i < n - cnt; i++) //2.2
        {
            cout << i << ' ' << n - cnt << '\n';
            cin >> s;
            if (s == "WIN") return;
        }

        cout << 1 << ' ' << 2 << '\n';
        cin >> s;
        if (s == "WIN") return;
        cout << 1 << ' ' << 2 << '\n';
        cin >> s;
        if (s == "WIN") return;

        for (int i = 1; i < n; i++) //1
        {
            cout << i << ' ' << i + 1 << '\n';
            cin >> s;
            if (s == "WIN") return;
        }

        cout << 1 << ' ' << 2 << '\n';
        cin >> s;
        if (s == "WIN") return;

        cnt++;
    }
}

void d()
{

}

void e()
{

}

void f()
{

}

void g()
{

}

void h()
{

}

void i()
{
    int n;

    cin >> n;
    vector<bool> v(1001, false);
    for (int i = 1; i * i <= 1000 && i * i <= n; i++)
    {
        v[i * i] = true;
    }
    int x = -1, y;
    for (int i = 1; i * i <= 1000 && i * i <= n; i++)
    {
        if (v[i * i] && (i * i == n || v[n - i * i]))
        {
            x = i;
            y = sqrt(n - i * i);
            break;
        }
    }
    if (x == -1) cout << "Impossible";
    else
    {

        if (y > x) swap(x, y);
        if (x * x == n)
        {
            cout << 0 << ' ' << 0 << '\n' << x << ' ' << 0 << '\n' << x << ' ' << x << '\n' << 0 << ' ' << x;
        }
        else
            cout << "0 0\n"
            << x << ' ' << y << '\n'
            << x + y << ' ' << y - x << '\n'
            << y << ' ' << -x << '\n';
    }
}

void j()
{

}

void k()
{

}

unsigned long long cnt(long long k, long long n)
{
    unsigned long long res = 1;
    unsigned long long niz = 1;
    for (unsigned long long i = max(k + 1, n - k + 1); i <= n; i++)
    {
        res *= i;
    }
    for (unsigned long long i = 1; i <= min(k, n - k); i++)
    {
        niz *= i;
    }
    return res/niz;
}

void n()
{
    unsigned long long n, k;
    cin >> n >> k;
    unsigned long long ans = 0;
    unsigned long long cur = 0;
    for (unsigned long long i = max(0, k - n); i <= min(n, k); i++)
    {
        cur = cnt(i, n);
        cur += cur % 2;
        if (2 * i != k) cur = cur / 2;
        ans += cur;
    }

    cout << ans;
}

void test()
{
    for (int i = 0; i <= 50; i++)
        cout << cnt(i, 50) << '\n';
}

int main()
{
    IOS

#ifdef ASD
        freopen("a.in", "r", stdin);
    freopen("a.out", "w", stdout);
#endif

#ifdef TEST
    freopen("a.in", "w", stdout);

    test();
#else
    c();
#endif

    return 0;
}