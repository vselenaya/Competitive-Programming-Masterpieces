﻿#include <random>
#include <numeric>
#include <iostream>
#include <ctime>
#include <algorithm>
using namespace std;
 
void shuffle_array(int arr[], int n)
{
 
  unsigned seed = 0;
 
  shuffle(arr, arr + n,
    default_random_engine(seed));
 
  for (int i = 0; i < n; ++i)
    cout << arr[i] << " ";
  cout << endl;
}
 
int main()
{
  int cards = 0;
  cin >> cards;
  int step = 1;
 
  int* arr = new int[cards];
  for (int i = 0; i < cards; i++)
  {
    arr[i] = i+1;
  }
 
  unsigned seed = 0;
  shuffle(arr, arr + cards,
    default_random_engine(seed));
 
 
  while (true)
  {
    srand(time(0));
    int i = rand() % cards + 1;
    int j = rand() % cards + (i + 1);
 
    cout << i << " " << j << endl;
    cout.flush();
 
    string input;
    cin >> input;
 
    if (input == "WIN")
    {
      return 0;
    }
 
    else if (input == "SWAPPED")
    {
      int tmp = arr[i-1];
      arr[i-1] = arr[j-1];
      arr[j-1] = tmp;
    }
 
    else if (input == "STAYED")
    {
    }
     
    // if (step % 2 == 0) 
    // {
    //   int tmp = arr[i-1];
    //   arr[i-1] = arr[j-1];
    //   arr[j-1] = tmp;
    // }
    step++;
  }
}
