#include <iostream>
#include <vector>
#include <set>
#include <deque>
#include <algorithm>
#include <map>
#include <unordered_map>

using namespace std;

vector<multiset<int>> g(200003);
deque<pair<int, int>> cycle;
set<pair<int, int>> added;
map<pair<int, int>, set<int>> edges;
unordered_map<int, int> smaller;

void DFS(int v) {
    while (!g[v].empty() ) {
        int x = *g[v].begin() ;
        g[v].erase(g[v].find(x));
        DFS(x);
        cycle.push_front({v, x});
    }
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, c, a, b, w, ct;
    ct = 0;
    cin >> n >> c;
    smaller[c] = ct; ct++;
    vector<int> indeg(n);
    vector<int> death;
    for (int i = 0; i < n; i++) {
        cin >> a >> b >> w;
        if (smaller.find(a) == smaller.end()) {
            smaller[a] = ct;
            ct++;
        }
        if (smaller.find(b) == smaller.end()) {
            smaller[b] = ct;
            ct++;
        }
        if (w == 0) {
            if (a != c) {
                a = smaller[c];
                b = smaller[c];
                g[a].insert(b);
                edges[{a, b}].insert(i + 1);
                indeg[b]++;
            } else {
                death.push_back(i + 1);
            }
        } else {
            g[smaller[a]].insert(smaller[b]);
            edges[{smaller[a], smaller[b]}].insert(i + 1);
            indeg[smaller[b]]++;
        }
    }
    c = smaller[c];
    for (int i = 0; i < n; i++) {
        if (i != c && indeg[i] > 0) {
            g[i].insert(i);
            for (int j = 0; j < death.size(); j++) {
                edges[{i, i}].insert(death[j]);
                indeg[i]++;
            }
            break;
        }
    }
    for (int i = 0; i < n; i++) {
        if (i != c && indeg[i] != g[i].size()) {
            g[i].insert(c);
            added.insert({c, i});
            indeg[c]++;
            break;
        }
    }
    for (int i = 0; i < n; i++) {
        if (indeg[i] != g[i].size()) {
            cout << "No\n";
            return 0;
        }
    }
    DFS(c);
    if (cycle.size() == n + 1) {
        cout << "Yes\n";
        for (int i = 0; i < cycle.size() - 1; i++) {
            int ed = *edges[cycle[i]].begin();
            //cout << cycle[i].first << ' ' << cycle[i].second << '\n';
            cout << ed << ' ';
        }
    } else {
        cout << "No\n";
    }
    return 0;
}
