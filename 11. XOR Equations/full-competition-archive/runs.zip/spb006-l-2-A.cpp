#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <queue>
#include <deque>
#include <stack>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <cassert>
#include <cstddef>
#include <cstring>
#include <bitset>
#include <random>
#include <memory>
#include <iomanip>

typedef long long ll;
typedef long double ld;

using namespace std;

vector<int> p {3, 0, 2, 1};

vector<int> inv(const vector<int>& p) {
    vector<int> res(p.size());
    for (int i  = 0; i < (int)p.size(); i++) res[p[i]] = i;
    return res;
}

vector<int> apply(const vector<int>& a) {
    vector<int> c = inv(p);
    vector<int> res(a.size());
    for (int i  =0 ; i < (int)res.size(); i++)
        res[i] = p[a[c[i]]];
    return res;
}

vector<int> get(const vector<int>& a) {
    cout << "? ";
    for (int i : a) cout << i + 1 << ' ';
    cout << endl;

    vector<int> ans(a.size());
    // ans = apply(a);
    // for (int i = 0; i < 4; i++) cout << ans[i] << ' ';
    // cout << '\n';

    for (int i = 0; i < (int)a.size(); i++) {
        cin >> ans[i];
        ans[i]--;
    }
    return ans;
}

void out(const vector<int>& a) {
    cout << "! ";
    for (int i : a) cout << i + 1 << ' ';
    cout << endl;
}

int main() {

#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    ios_base::sync_with_stdio(0);

    int test;
    cin >> test;
    while (test--) {
        int n;
        cin >> n;
        vector<int> a(n);
        iota(a.begin(), a.end(), 1);
        a[n - 1] = 0;
        vector<int> b = get(a);
        iota(a.begin(), a.end() - 1, 1);
        a[n - 2] = 0;
        a[n - 1] = n - 1;
        vector<int> c = get(a);

        int now = -1;
        for (int i = 0; i < n; i++) {
            if (c[i] == i)
                now = i;
        }

        // for (int i = 0; i < n; i++) {
            // cout << c[i] << ' ' << b[i] << '\n';
        // }
        assert(now != -1);

        vector<int> ans(n, -1);
        int to_now = n - 1;
        while (ans[now] == -1) {
            ans[now] = to_now;
            to_now = (to_now + 1) % n;

            now = b[now];
        }

        out(inv(ans));

    }


    return 0;
}
