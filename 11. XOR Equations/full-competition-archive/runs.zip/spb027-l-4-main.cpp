#include <iostream>
#include <string>
#include <unordered_map>
using namespace std;
int cnt = 2;
int c[10005];
int n,first1;
bool check(int x){//kuda 1->
  while(c[c[x]]!=first1)
  {
    cnt++;
    x = c[x];
  }
  //cout << cnt;
  if(cnt==n)return true;
  return false;
}


int main()
{
  int pi[10005];
  int t;
  cin >> t;
  for(int j = 1; j<=t; j++)
  {
    cin >> n;
    for(int i = 1; i<=n; i++)pi[i]=0;
    cout << '?' << ' ' << 2 << ' ' << 1 << ' ';
    for(int i = 3; i<=n; i++)
    {
      cout << i << ' ';
    }  
    cout << endl;

    for(int i = 1; i<=n; i++)
    {
      cin >> c[i];
    }
    int first=-1, second=-1;
    for(int i = 1; i<=n; i++)
    {
      if(c[i]!=i && first==-1)
      {
        first = c[i];
      }
      else if(c[i]!=i)
      {
        second = c[i];
      }
    }
    cout << '?' << ' ';
    for(int i = 1; i<n; i++)
    {
      cout << i+1 << ' ';
    }  
    cout << 1 << endl;
    for(int i = 1; i<=n; i++)
    {
      cin >> c[i];
    }
    cnt = 2;
    first1=first;
    //cout << first << ' ' << second << endl;
    pi[1] = first;
    for(int i = 2; i<=n; i++)
    {
      pi[i] = c[first];
      first = pi[i];
    }
    int flag = 0;
    for(int i = 1; i<=n; i++)if(pi[i]==0)flag=1;
    if(flag==1)
    {
      pi[1] = second;
      for(int i = 2; i<=n; i++)
      {
        pi[i] = c[second];
        second = pi[i];
      }
    }
    cout << '!' << ' ';
    for(int i = 1; i<=n; i++)
    {
      cout << pi[i] << ' ';
    }
    cout << endl;
  }
  
}
