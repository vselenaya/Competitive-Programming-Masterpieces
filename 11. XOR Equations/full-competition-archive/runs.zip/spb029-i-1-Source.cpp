#include <iostream>
#include <iomanip>
#include <string>
#include <map>
#include <algorithm>
#include <math.h>

using namespace std;

int main()
{
	long s;
	cin >> s;




	for (int x = 0; x <= s; x++)
		for (int y = 0; y <= s; y++)
		{
			if (x * x + y * y == s)
			{
				cout << "0 0\n";
				cout << x << " " << y << "\n";
				cout << x - y << " " << y + x << "\n";
				cout << -y << " " << x << "\n";

				return 0;
			}
		}

	cout << "Impossible";
	return 0;
}