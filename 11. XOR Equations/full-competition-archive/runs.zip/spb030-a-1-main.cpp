#include <iostream>
#include <string>
using namespace std;
int main()
{
  string *mas=new string [25];
  mas[0]="ITMO\n";
  mas[1]="SPbSU\n";
  mas[2]="SPbSU\n";
  mas[3]="ITMO\n";
  mas[4]="ITMO\n";
  mas[5]="SPbSU\n";
  mas[6]="ITMO\n";
  mas[7]="ITMO\n";
  mas[8]="ITMO\n";
  mas[9]="ITMO\n";
  mas[10]="ITMO\n";
  mas[11]="PetrSU, ITMO\n";
  mas[12]="SPbSU\n";
  mas[13]="SPbSU\n";
  mas[14]="ITMO\n";
  mas[15]="ITMO\n";
  mas[16]="ITMO\n";
  mas[17]="ITMO\n";
  mas[18]="SPbSU\n";
  mas[19]="ITMO\n";
  mas[20]="ITMO\n";
  mas[21]="ITMO\n";
  mas[22]="ITMO\n";
  mas[23]="SPbSU\n";
  mas[24]="ITMO\n";
  int N;
  cin>>N;
  cout<<mas[N-1995];
}
