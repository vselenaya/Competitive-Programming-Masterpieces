﻿#include <math.h>
#include <iostream>
using namespace std;

int main()
{
    int s;
    int x1,y1,x2,y2,x3,y3,x4,y4;
    cin >> s;
    int i = 0;
    int j = 0;
    for (int k = 0; k<=pow(s,1.0/2); k++) {
        for (int m = 0; m<= pow(s,1.0/2); m++) {
            if (k * k + m * m == s && k != m) { i = k; j = m; break; }
        }
    }
    x1 = i;
    y1 = j;
    x2 = x1 - i;
    y2 = y1 + j;
    x3 = x1 + j;
    y3 = y1 + i;
    x4 = x2 + j;
    y4 = y2 + i;
    if (i == 0 && j == 0) {
        cout << "Impossible";
    }
    else { cout << x1 << " " << y1 << "\n" << x2 << " " << y2 << "\n" << x3 << " " << y3 << "\n" << x4 << " " << y4; }
    return 0;
}

