#include <bits/stdc++.h>
//#define FAST_ALLOCATOR_MEMORY 2e8
//#include "optimization.h"
using namespace std;

#define int long long
#define double long double
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
mt19937 rnd(chrono::high_resolution_clock::now().time_since_epoch().count());

vector<int> bad, bsame;
const int N = 1e5;
set<pair<int, int>> g[N];

void no() {
    cout << "No";
    exit(0);
}

signed main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    cout << fixed << setprecision(20);
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    int n, start;
    cin >> n >> start;
    for(int i = 0; i < n; ++i) {
        int a, b, c;
        cin >> a >> b >> c;
        if(c) g[a].insert({b, i});
        else if(a == start) bsame.push_back(i);
        else bad.push_back(i);
    }

    vector<pair<int, int>> st;
    st.push_back({start, -1});
    vector<int> res;
    while(!st.empty()) {
        int u = st.back().first;
        int idx = st.back().second;
        if(g[u].empty()) {
            res.push_back(idx);
            st.pop_back();
        } else {
            st.push_back(*g[u].begin());
            g[u].erase(g[u].begin());
        }
    }
    res.pop_back();
    reverse(res.begin(), res.end());

    for(auto & i : g) {
        if(!i.empty()) no();
    }

    if(res.empty() && !bsame.empty()) no();
    cout << "Yes\n";
    for(auto& i : bad) cout << i + 1 << ' ';
    if(!res.empty()) cout << res[0] + 1 << ' ';
    for(auto& i : bsame) cout << i + 1 << ' ';
    for(int i = 1; i < res.size(); ++i) {
        cout << res[i] + 1 << ' ';
    }
}