#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <map>
#include <string>
#include <sstream>
#include <random>
#include <climits>
#include <iomanip>
#include <queue>
#include <bitset>
#include <cctype>
#include <functional>
#include <complex>
#include <fstream>
#include <unordered_set>
#include <unordered_map>
#include <ctime>
#include <deque>
#include <numeric>
#include <assert.h>
using namespace std;

typedef long long li;

#define forn(i,n) for (li i = 0;i < li(n);i++)
#define ford(i,n) for (li i = li(n)-1;i >=0;i--)
#define fore(i,l,r) for (li i = li(l);i < li(r);i++)
#define forv(v,arr) for (auto& v : (arr))
#define correct(x,n) (((x) >= 0) && ((x) < n))
#define all(a) (a).begin(),(a).end()
#define rnd() (rand() + (RAND_MAX+1)*rand())

//#define x first
//#define y second
//#define x real()
//#define y imag()

using vi = vector<li>;
using vptvi = vector<vi *>;
using pi = pair<li, li>;
using vpi = vector<pi>;
using vvi = vector<vector<li>>;
using ld = long double;
using Point = pair<li, li>;
//using Point = complex<li>;
//using Point = complex<ld>;

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	li a, x, b, y,t;
	cin >> a >> x >> b >> y >> t;
	li p1 = a + 21 * max(0ll, t - 30) * x;
	li p2 = b + 21 * max(0ll, t - 45) * y;
	cout << p1 << " " << p2 << endl;
}