#include <iostream>
using namespace std;

int main() {
    int a, b, x, y, T;
    int FirstOption = 0;
    int SecondOption = 0;
    cin >> a >> x >> b >> y >> T;

    if(T - 30 > 0){
        FirstOption = a + (T - 30) * 21 * x;
    }
    else{
        FirstOption = a;
    }

    if(T - 45 > 0){
        SecondOption = b + (T - 45) * 21 * y;
    }
    else{
        SecondOption = b;
    }
    cout << FirstOption << " " << SecondOption;
    return 0;
}