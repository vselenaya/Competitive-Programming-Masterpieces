#include <bits/stdc++.h>
using namespace std;

#define ll long long int

ll x, y, s;

int find_gip() {
    ll k = sqrt(s);
    for (int i = 1; i <= k; i++) {
     for (int j = i; j <= k; j++){
       if ((i*i+j*j) == s)
        {
           y = i;
           x = j;
           return 1;
        }
     }
    }
    cout << "Impossible\n";
    return 0;
}

int main()
{
    cin >> s;


    if (find_gip()) {
        cout << 0 << " " << x << endl;
        cout << y << " " << 0 << endl;
        cout << y + x << " " << y << endl;
        cout << x << " " << y + x <<endl;
    }
    return 0;
}
