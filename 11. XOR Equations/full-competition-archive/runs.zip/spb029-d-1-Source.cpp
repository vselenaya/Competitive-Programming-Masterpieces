#include <iostream>
#include <iomanip>
#include <string>
#include <map>
#include <algorithm>
#include <math.h>
#include <vector>
#include <unordered_map>

using namespace std;

int main()
{
	long n, w, h, s;
	cin >> n >> w >> h >> s;

	unordered_map<char, vector<vector<int>>> characters;

	for (int i = 0; i < n; i++)
	{
		char char_symbol;
		cin >> char_symbol;

		vector<vector<int>> symbol(h);
		for (int y = 0; y < h; y++)
		{
			vector<int> line(w);
			for (int x = 0; x < w; x++)
			{
				char ch;
				cin >> ch;
				if (ch == '#')
					line[x] = 1;
				else
					line[x] = 0;
			}
			symbol[y] = line;
		}
		characters[char_symbol] = symbol;
	}

	unordered_map<char, int> price;

	for (auto [key, val] : characters)
	{
		vector<int> resource(h);
		vector<int> current_column(h);

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				if (current_column[y] != val[y][x])
					resource[y]++;

				current_column[y] = val[y][x];
			}
		}
		price[key] = *max_element(resource.begin(), resource.end());
	}

	auto x = max_element(price.begin(), price.end(),
		[](const pair<int, int>& p1,
			const pair<int, int>& p2)
			{ return p1.second < p2.second; });
	
	int amount_of_symbols = ceil((double)s / (double)x->second);

	for (int i = 0; i < amount_of_symbols; i++)
		cout << x->first;

	return 0;
}