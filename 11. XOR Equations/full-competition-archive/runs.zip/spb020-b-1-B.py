a = int(input())
x = int(input())
b = int(input())
y = int(input())
T = int(input())

first = a + 21 * (0 if (T - 30) < 0 else (T - 30)) * x
second = b + 21 * (0 if (T - 45) < 0 else (T - 45)) * y

print(first, second)


