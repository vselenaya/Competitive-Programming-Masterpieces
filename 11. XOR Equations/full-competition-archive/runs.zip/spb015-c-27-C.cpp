﻿#include <random>
#include <numeric>
#include <iostream>
#include <ctime>
#include <algorithm>
using namespace std;

int main()
{
  int cards = 0;
  cin >> cards;
  while (true)
  {
    for (int i = 0; i < cards - 1; i++) {
      for (int j = 0; j < cards - i - 1; j++) {
        string input;
        cin >> input;
        if (input == "WIN")
        {
          return 0;
        }
        else {
          cout << i << " " << j << endl;
          cout.flush();
        }
      }
    }
  }
}
