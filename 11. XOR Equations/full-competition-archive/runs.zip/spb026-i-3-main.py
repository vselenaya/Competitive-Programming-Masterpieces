#
import math

if __name__ == '__main__':
    sq=list()
    for i in range(0, 1002):
        sq.append(i*i)
    # print (sq)
    s=int(input())
    flag=0
    for a in range(s+1):
        if (flag==0):
            for b in range(s+1):
                # print(a,b)0000
                if   (a*a+b*b)==s:
                    # print (-10000000,-10000000+a)
                    # print (-10000000+b,-10000000)
                    # print (-10000000+a+b,-10000000+b )
                    # print(-10000000+a,-10000000+a+b)
                    print(0,  a)
                    print (b,0)
                    print (a+b,b )
                    print(a,a+b)
                    flag=1
                    break
        if (flag==1):
            break
    if (flag==0):
        print("Impossible")
