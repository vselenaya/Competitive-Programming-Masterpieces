#include "iostream"
#include "cmath"

int main()
{
    int a,x,b,y,T;
    std::cin >> a >> x >> b >> y >> T;
    std::cout << a + 21*std::max(T- 30, 0)*x << " " << b + 21*std::max(T- 45, 0)*y;
}