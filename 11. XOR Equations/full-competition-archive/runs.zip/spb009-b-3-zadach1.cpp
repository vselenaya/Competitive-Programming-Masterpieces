#include <iostream>
#include <vector>
#include <string>
#include <cmath>

int main() {
	int a, b, x, y, T;
	std::cin >> a >> x;
	std::cin >> b >> y >> T;

	if ((T - 30) <= 0)
		x = a;
	else {
		x = (T - 30)* x * 21 + a;
	}
	std::cout << x << " ";

	if ((T - 45) <= 0)
		y = b;
	else {
		y = (T - 45) * y * 21 + b;
	}
	std::cout << y;

}