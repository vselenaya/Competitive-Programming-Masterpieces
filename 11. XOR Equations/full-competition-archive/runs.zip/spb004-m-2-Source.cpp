#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;


int main() {
	vector<int> cards;
	int n , x , raz=0;
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> x;
		cards.push_back(x);
	}
	sort(cards.begin(), cards.end());
	for (int i = 1; i < n; i++) {
		if (cards[i] - cards[i - 1] > raz) raz = cards[i] - cards[i - 1];
	}
	raz++;
	for (int i = 2; i < n; i++) {
		if (cards[i] - cards[i - 2] <= raz) { raz = 0; break; }
	}
	cout << raz;
}