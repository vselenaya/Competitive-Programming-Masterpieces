#include <iostream>
#include <map>
using namespace std;


int main() {
    map <int, string> ListWinners;

    ListWinners[1995] = "ITMO";
    ListWinners[1996] = "SPbSU";
    ListWinners[1997] = "SPbSU";
    ListWinners[1998] = "ITMO";
    ListWinners[1999] = "ITMO";
    ListWinners[2000] = "SPbSU";
    ListWinners[2001] = "ITMO";
    ListWinners[2002] = "ITMO";
    ListWinners[2003] = "ITMO";
    ListWinners[2004] = "ITMO";
    ListWinners[2005] = "ITMO";
    ListWinners[2006] = "PetrSU, ITMO";
    ListWinners[2007] = "SPbSU";
    ListWinners[2008] = "SPbSU";
    ListWinners[2009] = "ITMO";
    ListWinners[2010] = "ITMO";
    ListWinners[2011] = "ITMO";
    ListWinners[2012] = "ITMO";
    ListWinners[2013] = "SPbSU";
    ListWinners[2014] = "ITMO";
    ListWinners[2015] = "ITMO";
    ListWinners[2016] = "ITMO";
    ListWinners[2017] = "ITMO";
    ListWinners[2018] = "SPbSU";
    ListWinners[2019] = "ITMO";

    int Year;
    cin >> Year;

    for(auto& item : ListWinners){
        if(item.first == Year){
            cout << item.second << endl;
            break;
        }
    }

    return 0;
}

