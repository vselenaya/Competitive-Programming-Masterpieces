#include <bits/stdc++.h>

using namespace std;

#ifdef DEBUG
ifstream in("input");
#define cin in
#else
#define endl '\n'
#endif

#define EPS 0.000000001

void fast_io() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  cout.setf(ios::fixed);
  cout.precision(20);
}

bool is_sqrted(double s) {
  int no_point = sqrt(s);
  return abs(sqrt(s) - (double)no_point) < EPS;
}

int a, b;

bool doit(int s) {
  int sqr = ceil(sqrt((double)s));
  for (a = 1; a <= sqr; ++a) {
    for (b = 0; b <= sqr; ++b) {
      if (a * a + b * b == s) {
        return true;
      }
    }
  }
  return false;
}

void solve() {
  // amin'
  double s;
  cin >> s;
  if (doit(s)) {
    cout << 0 << ' ' << a << endl
         << a << ' ' << a + b << endl
         << a + b << ' ' << b << endl
         << b << ' ' << 0 << endl;
  } else {
    cout << "Impossible" << endl;
  }
}

int main() {
  fast_io();
  solve();
  return 0;
}