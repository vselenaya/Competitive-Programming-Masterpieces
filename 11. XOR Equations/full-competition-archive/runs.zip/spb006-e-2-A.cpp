#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <queue>
#include <deque>
#include <stack>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <cassert>
#include <cstddef>
#include <cstring>
#include <bitset>
#include <random>
#include <memory>
#include <iomanip>

typedef long long ll;
typedef long double ld;

using namespace std;

map<int, map<int, vector<int>>> g;
map<int, vector<pair<int, int>>> all_edges;
map<int, int> sz;
set<pair<int, int>> bad;

vector<int> res;

void find_euler(int v) {
    while (!all_edges[v].empty()) {
        pair<int, int> e = all_edges[v].back();
        all_edges[v].pop_back();
        find_euler(e.first);
    }
    res.push_back(v);
}


int main() {

#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    ios_base::sync_with_stdio(0);

    int n, c;
    cin >> n >> c;

    for (int i = 0; i < n; i++) {
        int a, b, w;
        cin >> a >> b >> w;
        if (w) {
            g[a][b].push_back(i);
            all_edges[a].push_back({b, i});
        }
        else {
            bad.insert({a, i});
        }
    }


    map<int, int> deg_in, deg_out;

    for (auto& s : g) {
        for (auto& x : s.second) {
            deg_in[x.first] += x.second.size();
            deg_out[s.first] += x.second.size();
        }
    }
    deg_in[c]++;


    int bd = -1;
    for (auto& x : deg_in) {
        if (deg_in[x.first] != deg_out[x.first]) {
            if (deg_in[x.first] - 1 == deg_out[x.first] && bd==-1) {
                bd = x.first;
            } else {
                cout << "No\n";
                return 0;
            }
        }
    }

    all_edges[bd].push_back({c, -1});

    find_euler(c);
    reverse(res.begin(), res.end());
    res.pop_back();

    int i = 0;
    for (i = 0; i + 1 < (int)res.size(); i++) {
        if (res[i] == bd && res[i + 1] == c) {
            break;
        }
    }


    rotate(res.begin(), res.begin() + i + 1, res.end());

    vector<int> ans;
    for (int i = 0; i + 1 < (int)res.size(); i++) {
        ans.push_back(g[res[i]][res[i + 1]].back());
        g[res[i]][res[i + 1]].pop_back();

        while (!bad.empty()) {
            auto j = bad.begin();
            if (j->first < res[i]) {
                ans.push_back(j->second);
                bad.erase(j);
            } else break;
        }


        while (!bad.empty()) {
            auto j = bad.end();
            j--;
            if (j->first > res[i]) {
                ans.push_back(j->second);
                bad.erase(j);
            } else break;
        }
    }

    if ((int)ans.size() != n) cout << "No\n";
    else {
        cout << "Yes\n";
        for (int i : ans) cout << i + 1 << ' ';
        cout << '\n';
    }



    return 0;
}
