#include <iostream>
using namespace std;
int main() {
	int a, x, b, y, t, p1, p2;
	cin >> a >> x >> b >> y >> t;
	if (t > 30) p1 = a + 21*(t - 30) * x; else p1 = a;
	if (t > 45) p2 = b + 21*(t - 45) * y; else p2 = b;
	cout << p1 << ' ' << p2;
	return 0;
}