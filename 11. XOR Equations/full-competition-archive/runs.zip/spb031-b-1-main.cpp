#include<bits/stdc++.h>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    int a, x, b, y;
    cin >> a >> x >> b >> y;

    int t;
    cin >> t;

    cout << a + 21 * max((t - 30), 0) *  x << '\n';
    cout << b + 21 * max((t - 45), 0) * y;

    return 0;
}
