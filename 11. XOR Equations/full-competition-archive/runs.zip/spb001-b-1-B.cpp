#include <bits/stdc++.h>

using namespace std;

int main() {

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int a, x, b, y, T, f, g;
    cin >> a >> x >> b >> y >> T;
    f = (T > 30) ? (T - 30) * x * 21 + a : a;
    g = (T > 45) ? (T - 45) * y * 21 + b : b;
    cout << f << ' ' << g;
}
