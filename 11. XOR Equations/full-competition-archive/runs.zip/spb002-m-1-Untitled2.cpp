#include <iostream>
#include <iomanip>
#include <cmath>
#include <algorithm>
#include <set>
#include <iterator>
using namespace std;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    long long n;
    cin >> n;
    long long a[n+1];
    a[0] = 0;
    for(int i = 1; i< n+1; i++)
    {
        long long flag;
        cin >> flag;
        a[i] = flag;
    }
    sort(a, a+n+1);
    long long d = 0;
    for(int i =0; i < n; i++)
    {
        d = max(a[i+1] - a[i], d);
    }
    for(int i = 0; i < n-1; i++)
    {
        if(a[i]+d >= a[i+2])
        {
            d = 0;
            break;
        }
    }
    cout << d;
}
