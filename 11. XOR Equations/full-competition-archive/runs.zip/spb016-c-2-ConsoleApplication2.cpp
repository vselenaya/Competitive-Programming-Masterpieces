﻿#include <iostream>
#include <string>
#include <vector>

using namespace std;

/*bool step(int n)
{
	vector<string> s(2 * n);
	int operations = 0;
	int count = 0;
	vector<pair<int, int> > v;

	for (int i = n; i >= 2; i--) //n-1
	{
		cout << i - 1 << " " << i << endl;
		cin >> s[n - i];
		if (s[n - i] == "WIN") return true;
		if (i - 1 <= e && s[n - i] == "SWAPPED")
		{
			count++;
			v.push_back(make_pair(i - 1, i));
		}
	}
	operations = n - 1;
	int push;
	if (count == 2)
	{
		push = v[1].second;
	}

	if (count == 1)
	{
		push = v[0].second;
	}
	if (count > 0)
	{
		int q = push;
		bool flag = true;
		while (flag)
		{
			cout << q << " " << q + 1 << endl;
			cin >> s[operations];
			if (s[operations] == "WIN") return true;
			operations++;
			q++;
			if (s[operations - 1] == "STAYED") flag = false;
			if (q == n) flag = false;
		}
	}

	int q = n;
	while (operations < 2 * n)
	{
		cout << q - 1 << " " << q << endl;
		cin >> s[operations];
		if (s[operations] == "WIN") return true;
		operations++;
		q--;
		if (q == 1) q = n;
	}
	e++;
	return false;
}

void solve()
{
	int n;
	cin >> n;
	while (!step(n)) {}
}*/

bool step(int n)
{
	for (int i = 1; i < n; i++)
	{
		cout << i << " " << i + 1 << endl;
		string s;
		cin >> s;
		if (s == "WIN") return true;
	}
	for (int i = n; i >= 2; i--)
	{
		cout << i - 1 << " " << i << endl;
		string s;
		cin >> s;
		if (s == "WIN") return true;
	}
	for (int i = 0; i < 2;i++)
	{
		cout << n - 1 << " " << n << endl;
		string s;
		cin >> s;
		if (s == "WIN") return true;
	}
}

int main()
{
	//solve();
	int n;
	cin >> n;
	while (!step(n));
}