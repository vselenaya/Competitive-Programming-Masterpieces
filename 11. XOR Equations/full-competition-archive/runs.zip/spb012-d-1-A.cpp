#include <algorithm>
#include <bitset>
#include <cstdlib>
#include <iostream>
#include <random>
#include <set>
#include <vector>

// #define FAST_ALLOCATOR_MEMORY 256000000
// #include "optimization.h"
#include <bits/stdc++.h>

using namespace std;

// #define USE_INT128
// #define int int64_t

// #undef _DEBUG

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()

#ifdef USE_INT128
#define lint __int128
#define ulint __int128
#else
#define lint int64_t
#define ulint int64_t
#endif

typedef long double ld;
#define f first
#define s second
typedef pair<int, int> pint;

const int inf = 1 << 30;

template <class T>
T mineq(T& a, const T& b) {
    return a = min(a, b);
}

template <class T>
T maxeq(T& a, const T& b) {
    return a = max(a, b);
}

mt19937 rd(533);
// end of default file

int32_t main() {
    // srand(5332017);
    ios::sync_with_stdio(false);
    cin.tie();
    cout.tie();
    cout << fixed;
    cout.precision(4); // !!

#ifdef _DEBUG
    freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
#else
    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
#endif

    int n, w, h, sw;
    cin >> n >> w >> h >> sw;

    vector<char> ch(n);

    int maxv = -1;
    int maxc = -1;
    for (int i = 0; i < n; i++) {
        cin >> ch[i];
        for (int j = 0; j < h; j++) {
            int sw_c = 0;
            string s;
            cin >> s;

            bool on = false;
            s.push_back('.');
            for (auto c : s) {
                bool new_on = (c == '#');
                if (on != new_on) {
                    sw_c++;
                }
                on = new_on;
            }

            if (sw_c > maxv) {
                maxv = sw_c;
                maxc = i;
            }
        }
    }

    int cnt = (sw + maxv - 1) / (maxv);

    for (int i = 0; i < cnt; i++) cout << ch[maxc];
    cout << endl;

    return 0;
}
