#include <bits/stdc++.h>

using namespace std;

int N, x, y;
string q;

int main() {

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    cin >> N;
    while (1) {
        random_device rd;
        mt19937 rng;
        uniform_int_distribution<int> uni(1, N - 1);
        x = uni(rng);
        uniform_int_distribution<int> uni2(x + 1, N - 1);
        y = uni2(rng);
        cout << x << ' ' << y << endl;
        cin >> q;
        if (q[1] == 'I') return 0;
    }

}
