#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
typedef long double ld;
 
mt19937 rnd(time(0));
#define rall(x) (x).rbegin(), (x).rend()
#define all(x) (x).begin(), (x).end()
#define pNN pair <Node *, Node *>
#define SZ(x) (int)(x).size()
#define pii pair <int, int>
#define pb push_back
#define eb emplace_back
#define rev reverse
#define ins insert
#define ers erase
#define S second
#define F first
#define int ll
const int N = 110, INF = 1e9 + 10, M = 1e9 + 7;

void solve() {
    int a, x, b, y, T;
    cin >> a >> x >> b >> y >> T;
    cout << a + (max(0LL, T - 30) * x) * 21 << " " << b + (max(0LL, T - 45) * y) * 21 << endl;
}

signed main () {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cout.precision(12);
    #ifdef fleek$
        assert(freopen("input.txt", "r", stdin));
    #endif
    int t = 1;
    //cin >> t;
    while(t--) solve();
    return 0;
}