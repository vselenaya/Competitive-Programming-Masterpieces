#include <iostream>
using namespace std;
int main() {
	int n; bool f=false;
	//int a[] = { 1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144, 169, 196, 225, 256, 289, 324, 361, 400, 441, 484, 529, 576, 625, 676, 729, 784, 841, 900, 961 };
	cin >> n;
	int i = 31, j=0;
	while (i*i > n) i--;
	for (; i > 0; i--) {
		for (j = 1; j <= i; j++) {
			if (i*i + j*j > n) {
				break;
			}
			if (i*i + j*j == n) {
				f = 1;
				break;
			}
		}
		if (f) break;
	}
	if (f) {
		cout << 0 << ' ' << i << endl;
		cout << j << ' ' << 0 << endl;
		cout << i + j<< ' ' << j << endl;
		cout << i << ' ' << i + j << endl;
	}
	else cout << "Impossible";
	return 0;
}