#include <iostream>
#include <vector>
#include<map>
#include<algorithm>
using namespace std;

//int binsearch(int i, int n, vector < pair<pair<int, int>, int>> v) {
//	bool flag = false;
//	int l = 0; 
//	int r = n-1; 
//	int mid;
//
//	while ((l <= r) && (flag != true)) {
//		mid = (l + r) / 2; // ��������� ��������� ������ ������� [l,r]
//
//		if (v[mid].first.first == i) {
//			flag = true;
//			return mid;
//		}
//		if (v[mid].first.first > i) r = mid - 1; 
//		else l = mid + 1;
//	}
//	return -1;
//}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	int n, c, a, b, w;
	//vector<int> f;
	vector<int> fc;
	//vector<pair<pair<int, int>, int>> sb;
	//vector<pair<int, int>> dsb;
	vector<int> por;
	bool f = 0;
	multimap<int, pair<int, int>> in;

	cin >> n >> c;
	for (int i = 0; i < n; i++) {
		cin >> a >> b >> w;
		if (!w) {
			//dsb.push_back(make_pair(a, i+1));
			if (a == c) {
				fc.push_back(i);
				f = 1;
			}
			else por.push_back(i);
		}
		else {
			//sb.push_back(make_pair(make_pair(a, b), i + 1));
			//if (w == c) f.push_back(i);
			in.emplace(a, make_pair(b, i));
		}
	}
	
	int cur = c;

	while (in.size() > 0) {
		multimap<int, pair<int, int>>::iterator it;
		it = in.find(cur);
		if (it != in.end()) {
			cur = it->second.first;
			por.push_back(it->second.second);
			if (f && cur != c) {
				for (int j = 0; j < fc.size(); j++) {
					por.push_back(fc[j]);
				}
				f = 0;
			}
			in.erase(it);
		}
		else {
			cout << "No";
			return 0;
		}
	}

	if (por.size() == n) {
		cout << "Yes" << endl;
		for (int i = 0; i < n; i++) {
			cout << por[i] + 1 << ' ';
		}
	}
	else cout << "No";

	return 0;
}