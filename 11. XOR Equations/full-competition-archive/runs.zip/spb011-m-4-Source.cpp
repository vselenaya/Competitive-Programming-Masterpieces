#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
	unsigned long long n, card, d;
	unsigned long long temp;
	vector<unsigned long long> cards;
	vector<unsigned long long> div;
	vector<unsigned long long> div1;
	cin >> n;
	for (unsigned long long i = 0; i < n; i++) {
		cin >> card;
		cards.push_back(card);
	}
	sort(cards.begin(), cards.end());

	for (unsigned long long i = 1; i < n; i++) {
		temp = cards[i] - cards[i - 1];
		div.push_back(temp);
	}
	
	unsigned long long maxVal = *max_element(div.begin(), div.end());
	
	//cout << "Max " << maxVal << endl;
	for (unsigned long long i = 1; i < n -1; i++) {
		temp = cards[i + 1] - cards[i - 1];
		div1.push_back(temp);
	}

	//cout << endl;
	/*for (auto el : div1) {
		cout << el << " ";
	}*/
	//cout << endl
	for (auto el : div1) {
		if (el <= maxVal) {
			cout << 0;
			//system("pause");
			return 0;
		}
	}
	cout << maxVal;
	//system("pause");
	return 0;
}