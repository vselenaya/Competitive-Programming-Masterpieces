

N = 51
binoms = [[0 for _ in range(N)] for _ in range(N)]


def calc_binoms():
    binoms[0][0] = 1
    for n in range(1, N):
        binoms[n][0] = 1
        for k in range(1, n + 1):
            binoms[n][k] = binoms[n - 1][k - 1] + binoms[n - 1][k]


def calc_symmentric(n, k):
    if k % 2 == 0:
        return binoms[n // 2][k // 2]
    if n % 2 == 0:
        return 0
    return binoms[n // 2][k // 2]


def calc_total(n, k):
    return binoms[n][k]


if __name__ == '__main__':
    n, k = list(map(int, input().split()))
    gems_min = max(0, k - n)
    gems_max = min(k, n)

    calc_binoms()

    ans = 0
    for m in range(gems_min, gems_max + 1):
        total = calc_total(n, m)
        sym = calc_symmentric(n, m)

        extra = sym + (total - sym) // 2
        if 2 * m == k:
            extra *= 2

        ans += extra

    print(ans)
