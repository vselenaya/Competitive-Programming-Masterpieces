#include <iostream>

using namespace std;

int boubble(int n, string str, int z)
{
	int i = 1;
	while (i < n - z)
	{
		cout << i << " " << i + 1 << endl;
		cin >> str;
		if (str == "WIN")
		{
			return 1;
		}
		i++;
	}

	return 0;
}

int main(void)
{
	int n = 0;
	int i = 1;
	int cyc = 0;
	int z = 0;
	int f = 0;
	double k = 1.0;
	string str;

	cin >> n;
	cyc = n - 1;
	
	if (boubble(n, str, z))
	{
		return 0;
	}
	z++;
	do
	{
		if (i == n)
		{
			if (boubble(n/2, str, z))
			{
				return 0;
			}
			cyc += n / 2 - 1;
			i = 1;
			k = 1.0;
		}
		if (cyc == (2 * n + 1))
		{
			if (boubble(n, str, z))
			{
				return 0;
			}
			f = 1;
			z = 1;
			cyc = n - 1;
			i = 1;
			k = 1.0;
		}
		if (static_cast<int>(n - k - z - i) <= 0)
		{
			if (i == n - z)
			{
				cout << i << " " << i - 1 << endl;
			}
			else
			{
				cout << i << " " << i + 1 << endl;
			}
		}
		else
		{
			cout << i << " " << static_cast<int>(n - k - z) << endl;
		}

		cin >> str;

		i++;
		cyc++;
		k = 1.2473 * i;
	} while (str != "WIN");


	return 0;
}