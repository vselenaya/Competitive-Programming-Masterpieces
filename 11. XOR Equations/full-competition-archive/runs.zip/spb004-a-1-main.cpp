﻿#define _CRT_SECURE_NO_WARNINGS
#define IOS ios::sync_with_stdio(0); //cin.tie(0); cout.tie(0);

#include <algorithm>
#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <cmath>
#include <queue>
#include <map>
#include <set>

using namespace std;

#pragma GCC optimize ("-O3")

#define wt int t; cin>>t; while(t--)
#define all(v) v.begin(),v.end()
#define max(a,b) (a>b?a:b)
#define min(a,b) (a<b?a:b)
#define max3(a,b,c) max(max(a,b),max(a,c))
#define min3(a,b,c) min(min(a,b),min(a,c))
#define pi 3.141592653

void a()
{
	vector<string> v = { "ITMO","SPbSU","SPbSU","ITMO","ITMO","SPbSU","ITMO","ITMO","ITMO","ITMO",
		"ITMO","PetrSU, ITMO","SPbSU","SPbSU","ITMO","ITMO","ITMO","ITMO","SPbSU","ITMO",
		"ITMO",
		"ITMO",
		"ITMO",
		"SPbSU",
		"ITMO" };
	int i;
	cin >> i;
	cout << v[i - 1995];

}

void b()
{

}

void c()
{
	
}

void d()
{
	
}

void e()
{

}

void f()
{

}

void g()
{

}

void h()
{

}

void i()
{

}

void j()
{

}

void k()
{

}

void test()
{
	
}

int main()
{
	IOS

#ifdef ASD
	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);
#endif

#ifdef TEST
	freopen("a.in", "w", stdout);

	test();
#else
	a();
#endif

	return 0;
}