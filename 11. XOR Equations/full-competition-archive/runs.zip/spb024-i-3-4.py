s = int(input())
so = 1
k = 1
mink = -1
maxk = -1

while ((s > so) or ((k // 2)**2 + (k - k // 2)**2 <= s)):
    if (s <= so) and (mink == -1):
        mink = k
    if ((k // 2)**2 + (k - k // 2)**2 <= s):
        maxk = k
    k = k + 1
    so = k * k

flag = True

if (k * k == s):
    print(0, 0)
    print(k, 0)
    print(k, k)
    print(0, k)
else:
    for j in range(mink, maxk + 1):
        k = j
        val = 0
        for i in range(1, k + 1):
            if (((k - i)**2 + i**2) == s):
                val = i
                break

        if (val != 0):
            print(0, k - i)
            print(k - i, k)
            print(k, i)
            print(i, 0)
            flag = False
            break
if (flag):
    print("Impossible")
    