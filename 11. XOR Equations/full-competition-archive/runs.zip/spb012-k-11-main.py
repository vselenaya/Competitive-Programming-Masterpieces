class And:
    def __init__(self, left, right):
        self.right = right
        self.left = left

    def forward(self, val):
        return self.right.forward(val) and self.left.forward(val)


class Or:
    def __init__(self, left, right):
        self.right = right
        self.left = left

    def forward(self, val):
        return self.right.forward(val) or self.left.forward(val)


class Not:
    def __init__(self, child):
        self.child = child

    def forward(self, val):
        return not self.child.forward(val)


class Var:
    def __init__(self, letter):
        self.letter = ord(letter) - ord('a')

    def forward(self, val):
        bit = val & (1 << self.letter)
        if bit == 0:
            return 0
        else:
            return 1


def find_op(str, op):
    brackets = 0
    for i in range(len(str) - 3):
        if str[i] == '(':
            brackets += 1
        elif str[i] == ')':
            brackets -= 1

        if brackets == 0 and str[i] == op[0] and str[i + 1] == op[1]:
            return i

    return -1


def parse_string(s):
    assert len(s) > 0
    try:
        if len(s) == 1:
            return Var(s)

        or_pos = find_op(s, 'or')
        if or_pos != -1:
            left = s[:or_pos-1]
            right = s[or_pos+3:]
            return Or(parse_string(left), parse_string(right))

        and_pos = find_op(s, 'and')
        if and_pos != -1:
            left = s[:and_pos - 1]
            right = s[and_pos + 4:]
            return And(parse_string(left), parse_string(right))

        if s[0] == '(':
            return parse_string(s[1:-1])

        if s[0] == 'n':
            return Not(parse_string(s[4:]))
    except:
        exit(0)

    exit(0)


def get_subset(vals):
    subset = []
    mask = [0] * 256
    for i in range(256):
        if vals[i] == 1 and mask[i] == 0:
            subset.append(i)
            for j in range(256):
                oset = i | j
                mask[oset] = 1
                if vals[oset] == 0:
                    return None

    return subset


def get_letters(val):
    letters = []
    i = 0
    while val > 0:
        if val % 2 == 1:
            letters.append(chr(ord('a') + i))
        val //= 2
        i += 1

    while len(letters) < 8:
        letters.append(letters[0])

    return letters


def out(vals):
    STEP = 8
    field = [[' ' for _ in range(50)] for _ in range(49)]
    row = 0
    start = 0
    side = 1
    for val in vals:
        letters = get_letters(val)
        for i in range(STEP):
            field[row + side][start + i] = letters[i]
            field[row][start + i] = '+'

        row += 2 * side
        if row == 48 or row == 0:
            side *= -1
            for i in range(STEP):
                field[row][start + i] = '+'
            field[row][start + STEP] = '-'
            start += STEP + 1

    for i in range(STEP):
        field[row][start + i] = '+'

    for i in range(start + STEP, 49):
        field[row][i] = '-'

    field[0][48] = '+'
    field[row][48] = '+'
    for i in range(1, row):
        field[i][48] = '|'

    return field


if __name__ == '__main__':
    s = input()

    #print(parse_string('not not a and b'))

    expression = parse_string(s.strip())
    vals = [expression.forward(i) for i in range(256)]

    subset = get_subset(vals)

    if subset is None:
        print("IMPOSSIBLE")
        exit(0)

    if len(subset) == 0:
        print('++')
        exit(0)

    if subset[0] == 0:
        print('+ +')
        exit(0)

    if len(subset) > 75:
        exit(0)

    field = out(subset)
    for i in range(min(49, 2 * len(subset) + 1)):
        for j in range(49):
            print(field[i][j], end="")
        print()
