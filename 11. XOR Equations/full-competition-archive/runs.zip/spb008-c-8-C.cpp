#include <iostream>
#include <string>

int main()
{
    int n;
    std ::cin >> n;
    std::string text = "";
    int count = 0;
    int last_done = 0, curr = last_done + 2;
    int check_taget = 1;
    int repair_taget = 0, repair_curr;
    int state = 0;
    while (text != "WIN")
    {
        if (last_done >= n)
            last_done = 0;
        switch (state)
        {
        case 0: //fix taget
            std::cout << last_done + 1 << " " << curr << std::endl;
            if (curr >= n)
            {
                last_done++;
                curr = last_done + 2;
            }
            else
            {
                curr++;
            }
            std::cin >> text;
            count++;
            break;

        case 1: //check
            std::cout << check_taget << " " << check_taget + 1 << std::endl;
            std::cin >> text;
            count++;
            if (check_taget >= last_done)
            {
                state = 0;
            }
            else
            {
                check_taget++;
            }
            if (text == "SWAPPED")
            {
                repair_taget = check_taget;
                repair_curr = repair_taget + 1;
                state = 2;

                last_done--;
                curr = last_done + 2;
            }
            break;

        case 2: //repair
            std::cout << repair_taget << " " << repair_curr << std::endl;
            if (repair_curr >= n)
            {
                state = 0;
            }
            else
            {
                repair_curr++;
            }
            std::cin >> text;
            count++;
            break;

        default:
            break;
        }
        if (count % (2 * n) == 0)
        {
            curr = last_done + 2;
            state = 1;
            check_taget = 1;
        }
    }
}