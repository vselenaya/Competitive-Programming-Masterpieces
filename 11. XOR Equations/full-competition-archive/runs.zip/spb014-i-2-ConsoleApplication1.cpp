﻿#include <iostream>;

using namespace std;


bool IsPosbl(double sq, size_t &i, size_t &j) {
	double q = 0;
	i = 1;
	j = 1;
	for (; sq > q; i++)
	{
		for (j = 1; sq > q; j++)
			q = sqrt(j * j + i * i);
		if (sq == q) {
			j--;
			return true;
		}

		q = 0;
		if (i >= 32)
			return false;
	}
	return false;
}

int main() {
	int s;
	size_t i, j;
	size_t &ref_i = i;
	size_t &ref_j = j;
	cin >> s;
	double sq = sqrt(s);
	if (sq == (long long)sq) {
		cout << "0 0" << endl;
		cout << "0 " << sq << endl;
		cout << sq << " 0" << endl;
		cout << sq << " " << sq << endl;
	}	
	else if (IsPosbl(sq, ref_i, ref_j)){
		cout << 0 << " " << i << endl;
		cout << j << " " << 0 << endl;
		cout << i << " " << i + j << endl;
		cout << i + j << " " << j << endl;
	}
	else {
		cout << "Impossible";
	}
	return 0;
}