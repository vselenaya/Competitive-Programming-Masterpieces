#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <queue>
#include <deque>
#include <stack>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <cassert>
#include <cstddef>
#include <cstring>
#include <bitset>
#include <random>
#include <memory>
#include <iomanip>

typedef long long ll;
typedef long double ld;

using namespace std;

int p, n, m, s, t;
const int MX = 26;
vector<pair<int, int>> gram[MX];
vector<int> term[MX];
vector<pair<int, int>> g[MX];
int matr[MX][MX];

void read() {
    for (int i = 0; i < MX; i++) {
        for (int j = 0; j < MX; j++) {
            matr[i][j] = -1;
        }
    }

    cin >> p;
    string str;
    getline(cin, str);
    for (int i = 0; i < p; i++) {
        getline(cin, str);
        if (str.length() == 6) {
            term[str[0] - 'A'].push_back(str[5] - 'a');
        } else {
            gram[str[0] - 'A'].push_back({str[5] - 'A', str[6] - 'A'});
        }
    }
    cin >> n >> m >> s >> t;
    s--, t--;
    for (int i = 0; i < m; i++) {
        int a, b;
        char c;
        cin >> a >> b >> c;
        a--, b--;
        g[a].push_back({b, c - 'a'});
        matr[a][b] = c - 'a';
    }

}

struct vert {
    int a, b, l;

    bool operator <(const vert& o) const {
        if (a != o.a) return a < o.a;
        if (b != o.b) return b < o.b;
        return l < o.l;
    }
};

const ll MASK = (1ll << 60) - 1;
const ll INF = MASK;

struct my_long {
    ll l, r;

    friend my_long operator+(const my_long& a, const my_long& b) {
        my_long c{a.l + b.l, a.r + b.r};
        c.r += c.l >> 60;
        c.l &= MASK;
        return c;
    }

    friend my_long operator-(const my_long& a) {
        return my_long({-a.l, -a.r});
    }

    bool operator<(const my_long& o) const {
        if (r != o.r) return r < o.r;
        return l < o.l;
    }


    bool operator!=(const my_long& o) {
        return l != o.l || r != o.r;
    }
};

void print(const my_long& a) {
    vector<int> pw(64);
    vector<int> ans(64);
    pw[0] = 1;
    for (int i = 0; i < 60; i++) {
        if (a.l & (1ll << i)) {
            for (int j = 0; j < 64; j++) {
                ans[j] += pw[j];
                if (ans[j] >= 10) {
                    ans[j + 1] += 1;
                    ans[j] -= 10;
                }
            }
        }

        for (int j = 0; j < 64; j++) {
            pw[j] *= 2;
        }
        for (int j = 0; j < 64; j++) {
            if (pw[j] >= 10) {
                pw[j + 1] += 1;
                pw[j] -= 10;
            }
        }
    }


    for (int i = 0; i < 60; i++) {
        if (a.r & (1ll << i)) {
            for (int j = 0; j < 64; j++) {
                ans[j] += pw[j];
                if (ans[j] >= 10) {
                    ans[j + 1] += 1;
                    ans[j] -= 10;
                }
            }
        }

        for (int j = 0; j < 64; j++) {
            pw[j] *= 2;
        }
        for (int j = 0; j < 64; j++) {
            if (pw[j] >= 10) {
                pw[j + 1] += 1;
                pw[j] -= 10;
            }
        }
    }

    while (ans.size() >= 1 && ans.back() == 0) {
        ans.pop_back();
    }

    for (int i = (int)ans.size() - 1; i >= 0; i--) {
        cout << ans[i];
    }
    cout << '\n';
}

my_long d[MX][MX][MX];

my_long get_d(const vert& q) {
    return d[q.a][q.b][q.l];
}

void solve() {
    for (int i = 0; i < MX; i++) {
        for (int j = 0; j < MX; j++) {
            for (int k = 0; k < MX; k++)  {
                d[i][j][k] = {INF, INF};
            }
        }
    }

//    priority_queue<pair<my_long, vert>> q;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < MX; k++) {
                for (int c : term[k]) {
                    if (matr[i][j] == c) {
                        d[i][j][k] = {1, 0};
//                        q.push({-d[i][j][k], {i, j, k}});
                    }
                }
            }
        }
    }

    for (int any = 1; any;) {
        any = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    for (int T = 0; T < MX; T++) {
                        for (const pair<int, int>& item : gram[T]) {
                            my_long tmp = d[i][k][item.first] + d[k][j][item.second];
                            if (tmp < d[i][j][T]) {
                                d[i][j][T] = tmp;
                                any = 1;
                            }
                        }
                    }
                }
            }
        }
    }

    if (d[s][t]['S' - 'A'] != my_long({INF, INF})) {
        my_long ans = d[s][t]['S' - 'A'];
        print(ans);
    } else {
        cout << "NO\n";
    }

}

int main() {

#ifdef DEBUG
    freopen("input.txt", "r", stdin);
#endif
    ios_base::sync_with_stdio(0);


    read();
    solve();

    return 0;
}
