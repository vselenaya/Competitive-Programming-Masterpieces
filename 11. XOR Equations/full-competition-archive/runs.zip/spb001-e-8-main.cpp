#include <iostream>
#include <vector>
#include <set>
#include <deque>
#include <algorithm>
#include <map>
#include <unordered_map>

using namespace std;

vector<multiset<int>> g(400003);
deque<pair<int, int>> cycle;
pair<int, int> added;
map<pair<int, int>, set<int>> edges;
unordered_map<int, int> smaller;

void DFS(int v) {
    while (!g[v].empty() ) {
        int x = *g[v].begin() ;
        g[v].erase(g[v].find(x));
        DFS(x);
        cycle.push_front({v, x});
    }
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, c, a, b, w, ct, ed;
    ct = 0;
    cin >> n >> c;
    smaller[c] = ct; ct++;
    vector<int> indeg(400003);
    vector<int> death;
    c = smaller[c];
    for (int i = 0; i < n; i++) {
        cin >> a >> b >> w;
        if (smaller.find(a) == smaller.end()) {
            smaller[a] = ct;
            ct++;
        }
        if (smaller.find(b) == smaller.end()) {
            smaller[b] = ct;
            ct++;
        }
        a = smaller[a]; b = smaller[b];
        if (w == 0) {
            if (a != c) {
                a = c;
                b = c;
                g[a].insert(b);
                edges[{a, b}].insert(i + 1);
                indeg[b]++;
            } else {
                death.push_back(i + 1);
            }
        } else {
            g[a].insert(b);
            edges[{a, b}].insert(i + 1);
            indeg[b]++;
        }
    }
    for (int i = 0; i < 400003; i++) {
        if (i != c && indeg[i] > 0) {
            for (int j = 0; j < death.size(); j++) {
                g[i].insert(i);
                edges[{i, i}].insert(death[j]);
                indeg[i]++;
            }
            break;
        }
    }
    added = {-1, -1};
    if (indeg[c] != g[c].size()) {
        for (int i = 0; i < 400003; i++) {
            if (i != c && indeg[i] != g[i].size()) {
                g[i].insert(c);
                added = {i, c};
                indeg[c]++;
                break;
            }
        }
    }
    for (int i = 0; i < 400003; i++) {
        if (indeg[i] != g[i].size()) {
            cout << "No\n";
            return 0;
        }
    }
    DFS(c);
    pair<int, int> p = {-1, -1};
    if ((cycle.size() == n + 1 && added != p) || (cycle.size() == n && added == p)) {
        cout << "Yes\n";
        int i = 0;
        while (added != cycle[i] && i < n) { i++; }
        for (int j = i + 1; j < cycle.size(); j++) {
            ed = *edges[cycle[j]].begin();
            cout << ed << ' ';
            edges[cycle[j]].erase(ed);
        }
        for (int j = 0; j < i; j++) {
            ed = *edges[cycle[j]].begin();
            cout << ed << ' ';
            edges[cycle[j]].erase(ed);
        }
    } else {
        cout << "No\n";
    }
    return 0;
}

/*
7 4
4 2 1
2 3 1
3 4 1
4 2 1
1 2 0
4 3 0
4 5 0

7 4
4 2 1
2 3 1
3 1 1
1 2 1
2 3 0
1 3 0
4 4 0
 */
