import math
s=int(input())
x=int(math.sqrt(s))
c=x+1
for i in range(x+1):
    if math.sqrt(s-pow(i,2))==int(math.sqrt(s-pow(i,2))):
        c=i
        d=int(math.sqrt(s-pow(i,2)))
        break
if c==x+1:
    print("Impossible")
else:
    x1=int(x)
    x2=x1+c
    y1=x1
    y2=y1+d
    x3=x1+d
    y3=y1-c
    x4=x1+c+d
    y4=y1-c+d
    print(x1, y1)
    print(x2, y2)
    print(x3, y3)
    print(x4, y4)
    