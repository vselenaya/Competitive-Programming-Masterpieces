#include <iostream>

using namespace std;
#define ll long long
int main()
{
	ll a, x, b, y, T;
	cin >> a >> x >> b >> y >> T;

	ll q1, q2, v1, v2;
	v1 = (T - 30);
	if (v1 < 0)
		v1 = 0;
	v2 = (T - 45);
	if (v2 < 0)
		v2 = 0;

	q1 = a + 21 * v1 *x;
	q2 = b + 21 * v2*y;
	cout << q1 << " " << q2 << "\n";
	//system("pause");

	return 0;
}