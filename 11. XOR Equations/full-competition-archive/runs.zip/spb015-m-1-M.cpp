#include <iostream>

using namespace std;

int main() {
	int count = 0;
	int *arr;
	int *diff;
	
	cin >> count;
	arr = new int[count];
	diff = new int[count-1];
	
	for (int i = 0; i < count; i++)
	{
		cin >> arr[i];
	}

	int temp = 0;
	
	for (int i = 0; i < count - 1; i++) {
		for (int j = 0; j < count - i - 1; j++) {
			if (arr[j] > arr[j + 1]) {
				temp = arr[j];
				arr[j] = arr[j + 1];
				arr[j + 1] = temp;
			}
		}
	}


	int minDif = INT_MAX;
	for (int i = 1; i < count; i++)
	{
		diff[i - 1] = arr[i] - arr[i - 1];
		if (diff[i-1] < minDif && diff[i-1] > arr[0])
		{
			minDif = diff[i - 1];
		}
	}

	for (int i = 0; i < count -1; i++)
	{
		if (diff[i] > minDif)
		{
			minDif = 0;
			break;
		}
	}
	
	if (minDif == INT_MAX)
	{
		minDif = 0;
	}
	cout << minDif;
}