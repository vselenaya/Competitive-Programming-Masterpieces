#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
	long long n, card, d;
	long long temp;
	vector<long long> cards;
	vector<long long> div;
	vector<long long> div1;
	cin >> n;
	for (long long i = 0; i < n; i++) {
		cin >> card;
		cards.push_back(card);
	}
	sort(cards.begin(), cards.end());

	for (long long i = 1; i < n; i++) {
		temp = cards[i] - cards[i - 1];
		div.push_back(temp);
	}
	
	int maxVal = *max_element(div.begin(), div.end());

	for (long long i = 1; i < n -1; i++) {
		temp = cards[i + 1] - cards[i - 1];
		div1.push_back(temp);
	}

	for (auto el : div1) {
		if (el <= maxVal) {
			cout << 0;
			system("pause");
			return 0;
		}
	}
	cout << maxVal;
	system("pause");
	return 0;
}