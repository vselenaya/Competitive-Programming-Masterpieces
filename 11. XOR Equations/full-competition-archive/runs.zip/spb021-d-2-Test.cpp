#include <iostream>
#include <algorithm>
#include <vector>
#include <cmath>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, w, h, s;
    cin >> n >> w >> h >> s;

    int maxSwCount = 0;
    char letter;

    for (int i = 0; i < n; i++) {
        char letterSym;
        cin >> letterSym;
        for (int height = 0; height < h; height++) {
            int swCount = 0;
            char tempSym = '.';
            for (int width = 0; width < w; width++) {
                char sym;
                cin >> sym;
                if (sym != tempSym)
                    swCount++;
                tempSym = sym;
            }
            if (tempSym != '.')
                swCount++;

            if (swCount > maxSwCount) {
                maxSwCount = swCount;
                letter = letterSym;
            }
        }
    }

    int lCount = (s % maxSwCount == 0) ? s / maxSwCount : s / maxSwCount + 1;
    for (int i = 0; i < lCount; i++)
        cout << letter;

    return 0;
}