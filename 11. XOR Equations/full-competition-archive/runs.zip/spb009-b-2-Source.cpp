#include <iostream>

int main()
{
	long int a, b;
	long int x, y;
	long int T;

	std::cin >> a >> x;
	std::cin >> b >> y;
	std::cin >> T;

	int temp;
	temp = ((T - 30) * x) * 21 + a;

	if (T - 30 <= 0)
		std::cout << x << " ";
	else
		std::cout << temp << " ";

	temp = ((T - 45) * y) * 21 + b;

	if (T - 45 <= 0)
		std::cout << y;
	else
		std::cout << temp;

	return 0;
}