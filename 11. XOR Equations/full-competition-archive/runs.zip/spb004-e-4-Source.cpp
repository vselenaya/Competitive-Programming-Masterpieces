#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;


int main() {
	int n, c , ps=0, pe=1;
	cin >> n >> c;
	vector<int> a(n), b(n), w(n), p;

	for (int i = 0; i < n; i++) {
		cin >> a[i] >> b[i] >> w[i];
	}


	while (ps != pe) {
		for (int i = 0; i < n; i++) {
			if (w[i] == 0 && a[i] != c) {
				p.push_back(i + 1);
				w[i] = 6;
			}
		}
		for (int i = 0; i < n; i++) {
			if (w[i] == 1 && a[i] == c) {
				for (int j = i; j < n; j++) {
					if (w[i]!=6) { p.push_back(i + 1); w[i] = 6; c = b[i];}
				}
			}
		}
		ps = pe;
		pe = p.size();
	}

	if (n == 1 && w[0] == 1 && c == a[0]) { cout << "YES" << endl << "1"; }
	else if (p.size() == n)
	{
		cout << "YES" << endl;
		for (int i = 0; i < n; i++) {
			cout << p[i] << " ";
		}
	}
	else cout << "NO";
}