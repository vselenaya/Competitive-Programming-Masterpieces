#include <iostream>
using namespace std;

int main()
{
  int square = 0;
  cin >> square;
  for (int a = 1; a <= square; a += 1)
  {
    if (a * a == square) {
      cout << 0 << " " << 0 << endl;
      cout << 0 << " " << a << endl;
      cout << a << " " << 0 << endl;
      cout << a << " " << a << endl;
      return 0;
    }
    for (int b = 1; b < square; b += 1)
    {
      
      if (a * a + b * b == square)
      {
        cout << 0 << " " << b << endl;
        cout << a << " " << 0 << endl;
        cout << b << " " << a + b << endl;
        cout << a+b << " " << a << endl;
        return 0;
      }
    }
  }
  cout << "Impossible";
}
