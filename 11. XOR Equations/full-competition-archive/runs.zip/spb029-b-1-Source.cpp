#include <iostream>
#include <iomanip>
#include <string>
#include <map>

using namespace std;

int main()
{
	int a, x, b, y, T;

	cin >> a >> x >> b >> y >> T;

	int resA = 0;
	int resB = 0;

	resA = a + max(0, T - 30) * x * 21;
	resB = b + max(0, T - 45) * y * 21;

	cout << resA << " " << resB;

	return 0;
}