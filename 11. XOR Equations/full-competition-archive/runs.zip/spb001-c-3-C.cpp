#include <bits/stdc++.h>

using namespace std;

int N, x = 1, y;
string q;

int main() {

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    cin >> N;
    y = N + 1;
    while (1) {
        y--;
        if (y == x) x++, y = N;
        if (x == N) x = 1;
        cout << x << ' ' << y << endl;
        cin >> q;
        if (q[1] == 'I') return 0;
    }

}
