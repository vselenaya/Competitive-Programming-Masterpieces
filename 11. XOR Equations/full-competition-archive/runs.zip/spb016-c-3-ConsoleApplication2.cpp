﻿#include <iostream>
#include <string>
#include <vector>

using namespace std;

bool step(int n)
{
	for (int i = 1; i < n; i++)
	{
		cout << i << " " << i + 1 << endl;
		fflush(stdout);
		string s;
		cin >> s;
		if (s == "WIN") return true;
	}
	for (int i = n; i >= 2; i--)
	{
		cout << i - 1 << " " << i << endl;
		fflush(stdout);
		string s;
		cin >> s;
		if (s == "WIN") return true;
	}
	for (int i = 0; i < 2;i++)
	{
		cout << n - 1 << " " << n << endl;
		fflush(stdout);
		string s;
		cin >> s;
		if (s == "WIN") return true;
	}
	return false;
}

int main()
{
	int n;
	cin >> n;
	while (!step(n));
}