#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
	int n, w, h;
	long long s;
	char el, ch;;
	cin >> n >> w >> h >> s;
	//s--;
	string res, temp, str;
	map<char, int> myMap;
	vector<int> array;
	for (int i = 0; i < n; i++) {
		cin >> ch;
		
		for (int j = 0; j < h; j++) {
			//getline(cin, str);
			cin >> str;
			int counter = 0;
			str += ".";
			str = "." + str;
			for (int k = 0; k < w + 2; k++) {
				if (str[k] == '.' && str[k+1] == '#' || str[k] == '#' && str[k + 1] == '.') {
					counter++;
				}
				
			}
			
			array.push_back(counter);
		}
		int max = *max_element(array.begin(), array.end());
		myMap[ch] = max;
		array.clear();

	}
	char Res;
	long long maxVal = -10000000;
	for (auto el : myMap) {
		if (el.second > maxVal) {
			Res = el.first;
			maxVal = el.second;
		}
	}

	int result = s / maxVal;
	if (s - result* maxVal != 0) {
		result++;
	}
	for (int i = 0; i < result; i++) {
		cout << Res;
	}

	return 0;
}