#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int n,a,b;
    cin >> n;
    for (int i = 1; i < n ; i++)
    {
        for(int j = 0; j < i ; j++)
            {
                if (i * i + j * j == n){
                a = i;
                b = j;
                cout << 0 << " " << 0 << endl;
                cout << a << " " << b << endl;
                cout << -b << " "<< a << endl;
                cout << a-b << " "<< b+a << endl;
                return 0;
            }
        }

    }
    cout << "Impossible";
    return 0;
}
