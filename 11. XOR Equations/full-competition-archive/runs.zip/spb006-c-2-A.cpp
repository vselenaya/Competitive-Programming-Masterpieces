#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
typedef long double ld;

#define pb push_back
#define forn(i, n) for (int i = 0; i < (int)(n); i++)
#define forrn(i, s, n) for (int i = (int)(s); i < (int)(n); i++)
#define PYMOD(a, m) ((((a) % (m)) + (m)) % (m))
#define all(v) v.begin(), v.end()
#define rall(v) v.rbegin(), v.rend()
#define mp make_pair
#define ff first
#define ss second

int n;
const int maxn = 57;

#ifdef LOCAL

int a[maxn];

void init() {
    cin >> n;
    for (int i = 0; i < n; i++) {
        // cin >> a[i];
        a[i] = n - i;
    }
}

int op = 0;

mt19937 rnd(time(0));

bool swp(int i, int j) {
    // cout << i + 1 << " " << j + 1 << endl;
    if (a[i] > a[j]) {
        swap(a[i], a[j]);
        // cout << "SWAPPED" << endl;
    } else {
        // cout << "STAYED" << endl;
    }
    if (is_sorted(a, a + n)) {
        cout << "WIN" << endl;
        cout << op << '\n';
        return true;
    }
    op++;
    if (op % (2 * n) == 0) {
        uniform_int_distribution<int> dist(0, n);
        int ia = dist(rnd), ja = dist(rnd);
        while (ia == ja)
            ja = dist(rnd);
        // cout << "SWP " << ia << " " << ja << endl;
        swap(a[ia], a[ja]);
    }
    return false;
}

#else

void init() {
    cin >> n;
}

bool swp(int i, int j) {
    cout << i + 1 << " " << j + 1 << endl;
    cout.flush();
    string s;
    cin >> s;
    return s == "WIN";
}

#endif

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    // Code here:

    init();
    while (true) {
        for (int i = n - 1; i >= 0; i--) {
            if (swp(i, i + 1))
                return 0;
        }
        if (swp(0, 1))
            return 0;


        for (int i = 0; i + 1 < n; i++) {
            if (swp(i, i + 1))
                return 0;
        }
        if (swp(0, 1))
            return 0;
    }

    return 0;
}
