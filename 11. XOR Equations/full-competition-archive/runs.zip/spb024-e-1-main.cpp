#include <iostream>
#include <string>
#include <vector>
#include <functional>
#include <algorithm>
#include <map>
#include <unordered_set>

struct wish_t {
  int a;
  int b;
  bool w;
};

std::unordered_set<int> foo(std::vector<wish_t>& wishes, int c, std::unordered_set<int> ans = {}) {
  for (int i = 0; i < wishes.size(); ++i) {
    if (!wishes[i].w && wishes[i].a != c && ans.count(i) == 0) {
      ans.insert(i);
    }
  }

  for (int i = 0; i < wishes.size(); ++i) {
    if (wishes[i].w && wishes[i].a == c && ans.count(i) == 0) {
      auto s = ans;
      s.insert(i);
      s = foo(wishes, wishes[i].b, s);
      if (s.size() == wishes.size()) {
        return s;
      }
    }
  }

  return ans;
}


int main(int, char* []) {
  int n = 0;
  int c = 0;
  std::cin >> n >> c;
  std::vector<wish_t> wishes(n);

  int a = 0;
  int b = 0;
  int w = 0;
  for (int i = 0; i < n; ++i) {
    std::cin >> a >> b >> w;
    wishes[i] = { a, b, w };
  }

  auto ans = foo(wishes, c);
  if (ans.size() == n) {
    std::cout << "Yes\n";
    std::vector<int> a(ans.begin(), ans.end());
    for (auto itr = a.rbegin(); itr != a.rend(); ++itr) {
      std::cout << (*itr + 1) << ' ';
    }
  }
  else {
    std::cout << "No\n";
  }
  return 0;
}
