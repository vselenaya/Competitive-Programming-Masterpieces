#include <iostream>
#include <iomanip>
#include <string>
#include <map>
#include <algorithm>
#include <math.h>
#include <vector>
#include <unordered_map>
//#include <fstream>
//#include <cstdio>

using namespace std;


int main()
{
    string input;

    int n;
    cin >> n;
    int counter = 0;
    while (counter <= 10000)
    {
        for (int i = 0; i < n; i++)
        {
            for (int j = i; j < n - 1; j++)
            {
                cout << j + 1 << " " << j + 2 << endl;

                cin >> input;

                if (input == "WIN")
                    return 0;
            }
        }
        counter++;

    }

    return 0;
}