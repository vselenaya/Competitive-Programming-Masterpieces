#include <iostream>
#include <map>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    uint16_t a, x, b, y, T;

    cin >> a >> x >> b >> y >> T;

    size_t first = (T <= 30) ? a : ((T-30) * x * 21 + a);
    size_t second = (T <= 45) ? b : ((T-45) * y * 21 + b);

    cout << first << " " << second;

    return 0;
}


