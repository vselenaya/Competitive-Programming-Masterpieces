#include <bits/stdc++.h>

using namespace std;

#ifdef DEBUG
ifstream in("input");
#define cin in
#else
#define endl '\n'
#endif

#define EPS 0.000000001

void fast_io() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  cout.setf(ios::fixed);
  cout.precision(20);
}

int a, x, b, y;
int t;

int calc_for_1(int t) {
  t -= 30;
  return (t > 0 ? t * x : 0);
}

int calc_for_2(int t) {
  t -= 45;
  return (t > 0 ? t * y : 0);
}

void solve() {
  // amin'

  cin >> a >> x >> b >> y;
  cin >> t;
  int ans1 = a, ans2 = b;
  for (int i = 0; i < 21; ++i) {
    ans1 += calc_for_1(t);
    ans2 += calc_for_2(t);
  }
  cout << ans1 << ' ' << ans2 << endl;
}

int main() {
  fast_io();
  solve();
  return 0;
}