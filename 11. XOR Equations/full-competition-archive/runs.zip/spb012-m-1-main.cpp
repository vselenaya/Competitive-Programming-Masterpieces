#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

int main() {
  int n;
  cin >> n;
  vector<int> a(n);
  for (int i = 0; i < n; i++) {
    cin >> a[i];
  }

  a.push_back(0);

  sort(a.begin(), a.end());

  int maxgap = 0;
  for (int i = 1; i <= n; i++) {
    maxgap = max(maxgap, a[i] - a[i - 1]);
  }

  for (int i = 2; i <= n; i++) {
    if (a[i] - a[i - 2] <= maxgap) {
      cout << 0 << "\n";
      return 0;
    }
  }

  cout << maxgap << "\n";
  return 0;
}
