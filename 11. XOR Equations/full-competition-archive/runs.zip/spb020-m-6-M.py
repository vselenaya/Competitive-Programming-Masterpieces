n = int(input())
s = input()
pipe = [int(x) for x in s.split()]

pipe.sort()

min_d = pipe[0]
max_d = pipe[1]


for i in range(len(pipe) - 2):
    dlt_min = pipe[i + 1] - pipe[i]
    dlt_max = pipe[i + 2] - pipe[i]

    if dlt_min > min_d:
        min_d = dlt_min
    if dlt_max < max_d:
        max_d = dlt_max

dlt_min = pipe[-1] - pipe[-2]
if not (dlt_min < max_d):
    min_d = max_d + 1

if min_d <= max_d:
    print(min_d)
else:
    print(0)
