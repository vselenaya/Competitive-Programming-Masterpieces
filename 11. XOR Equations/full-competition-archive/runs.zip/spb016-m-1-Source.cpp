#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <map>
#include <string>
#include <sstream>
#include <random>
#include <climits>
#include <iomanip>
#include <queue>
#include <bitset>
#include <cctype>
#include <functional>
#include <complex>
#include <fstream>
#include <unordered_set>
#include <unordered_map>
#include <ctime>
#include <deque>
#include <numeric>
#include <assert.h>
using namespace std;

typedef long long li;

#define forn(i,n) for (li i = 0;i < li(n);i++)
#define ford(i,n) for (li i = li(n)-1;i >=0;i--)
#define fore(i,l,r) for (li i = li(l);i < li(r);i++)
#define forv(v,arr) for (auto& v : (arr))
#define correct(x,n) (((x) >= 0) && ((x) < n))
#define all(a) (a).begin(),(a).end()
#define rnd() (rand() + (RAND_MAX+1)*rand())

//#define x first
//#define y second
//#define x real()
//#define y imag()

using vi = vector<li>;
using vptvi = vector<vi *>;
using pi = pair<li, li>;
using vpi = vector<pi>;
using vvi = vector<vector<li>>;
using ld = long double;
using Point = pair<li, li>;
//using Point = complex<li>;
//using Point = complex<ld>;

void out_point(li x, li y)
{
	cout << x << " " << y << endl;
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n;
	cin >> n;
	vi a(n);
	forv(v, a)
		cin >> v;
	sort(all(a));

	li max_d = 10000000000, min_d = 0;

	forn(i, n - 1)
		min_d = max(min_d, a[i + 1] - a[i]);
	forn(i, n - 2)
		max_d = min(max_d, a[i + 2] - a[i] - 1);

	cout << (min_d <= max_d ? min_d : 0) << endl;
}