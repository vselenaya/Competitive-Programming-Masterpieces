﻿#include <iostream>
#include <math.h>
#include <string>
using namespace std;

int main(void) {

	int a, x, b, y, t, m = 0, n = 0;

	cin >> a >> x >> b >> y >> t;

	if (t > 30) { m = 21 * ((t - 30) * x); }
	m += a;

	if (t > 45) { n = 21 * ((t - 45) * y); }
	n += b;

	cout << m << ' ' << n;

	return 0;
}