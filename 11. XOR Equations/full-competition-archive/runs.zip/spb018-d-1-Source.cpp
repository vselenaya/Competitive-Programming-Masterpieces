#include <iostream>
#include <vector>
#include<algorithm>
using namespace std;
int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	int n, w, h, s, t;
	char c, maxc='a';
	char a[30][30];
	int max=0, num=0;
	cin >> n >> w >> h >> s;
	for (int i = 0; i < n; i++) {
		cin >> c;
		for (int k = 0; k < h; k++) {
			num = 0;
			cin >> a[k][0];
			if (a[k][0] == '#') num++;
			for (int m = 1; m < w; m++) {
				cin >> a[k][m];
				if (a[k][m] != a[k][m - 1]) num++;
			}
			if (a[k][w - 1] == '#') num++;
			if (num > max) {
				max = num;
				maxc = c;
			}
		}
	}
	if (s % max) t = s / max + 1;
	else t = s / max;
	for (int i = 0; i < t; i++) {
		cout << maxc;
	}
	return 0;
}