a = ['ITMO','SPbSU','SPbSU','ITMO','ITMO','SPbSU','ITMO','ITMO','ITMO','ITMO','ITMO','PetrSU, ITMO','SPbSU','SPbSU','ITMO','ITMO','ITMO','ITMO','SPbSU','ITMO','ITMO','ITMO','ITMO','SPbSU','ITMO']
b = int(input())
i = b - 1995
if (i >= 0 and i <= 24):
    print(a[i])