﻿#include <stdio.h>
#include <stdlib.h>
#include <iostream>


using namespace std;
void quickSort(long long* arr, int left, int right)
{
  long long pivot; // разрешающий элемент
  int l_hold = left; //левая граница
  int r_hold = right; // правая граница
  pivot = arr[left];
  while (left < right) // пока границы не сомкнутся
  {
    while ((arr[right] >= pivot) && (left < right))
      right--; // сдвигаем правую границу пока элемент [right] больше [pivot]
    if (left != right) // если границы не сомкнулись
    {
      arr[left] = arr[right]; // перемещаем элемент [right] на место разрешающего
      left++; // сдвигаем левую границу вправо
    }
    while ((arr[left] <= pivot) && (left < right))
      left++; // сдвигаем левую границу пока элемент [left] меньше [pivot]
    if (left != right) // если границы не сомкнулись
    {
      arr[right] = arr[left]; // перемещаем элемент [left] на место [right]
      right--; // сдвигаем правую границу вправо
    }
  }
  arr[left] = pivot; // ставим разрешающий элемент на место
  pivot = left;
  left = l_hold;
  right = r_hold;
  if (left < pivot) // Рекурсивно вызываем сортировку для левой и правой части массива
    quickSort(arr, left, pivot - 1);
  if (right > pivot)
    quickSort(arr, pivot + 1, right);
}

int main()
{
  int n;
  long long d, tmp = 0, check = 0;
  cin >> n;
  long long* arr = new long long[n];
  for (int i = 0; i < n; i++) {
    cin >> arr[i];
  }
  quickSort(arr, 0, n - 1);
  long long temp = 0;
  for (int i = 0; i < n; i++) {
    tmp = arr[i] - temp;
    if (check < tmp) {
      check = tmp;
    }
    temp = arr[i];
  }
  temp = 0;
  for (int i = 0; i < n-2; i++) {
    long long che1 = arr[i];
    long long che2 = arr[i + 1];
    long long che3 = arr[i + 2];
    if ((che3 - check <= che1) && (che2 - check <= che1)) {
      cout << 0;
      return 0;
    }
  }
  cout << check;
  return 0;

}
