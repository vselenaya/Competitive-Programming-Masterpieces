#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main()
{
    int n, tmp, ans, mi, ma;
    cin >> n;
    vector<int> v;
    for(int i = 0; i < n; i++)
    {
        cin >> tmp;
        v.push_back(tmp);
    }
    sort(v.begin(),v.end());
    mi = v[1];
    ma = v[0];
    if (v[1] - v[0] > ma) ma = v[1] - v[0];
	for (int i = 2; i < n; i++) {
        if (v[i] - v[i - 1] > ma)
        {
            ma = v[i] - v[i - 1];
        }
		if (v[i] - v[i - 2] < mi)
		{
            mi = v[i] - v[i - 2];
		}
	}
	if (ma < mi) cout << ma;
	else cout << 0;
return 0;
}
