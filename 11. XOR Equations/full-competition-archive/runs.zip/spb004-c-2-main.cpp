﻿#define _CRT_SECURE_NO_WARNINGS
#define IOS ios::sync_with_stdio(0); //cin.tie(0); cout.tie(0);

#include <algorithm>
#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <cmath>
#include <queue>
#include <map>
#include <set>

using namespace std;

#pragma GCC optimize ("-O3")

#define wt int t; cin>>t; while(t--)
#define all(v) v.begin(),v.end()
#define max(a,b) (a>b?a:b)
#define min(a,b) (a<b?a:b)
#define max3(a,b,c) max(max(a,b),max(a,c))
#define min3(a,b,c) min(min(a,b),min(a,c))
#define pi 3.141592653

void a()
{
	vector<string> v = { "ITMO","SPbSU","SPbSU","ITMO","ITMO","SPbSU","ITMO","ITMO","ITMO","ITMO",
		"ITMO","PetrSU, ITMO","SPbSU","SPbSU","ITMO","ITMO","ITMO","ITMO","SPbSU","ITMO",
		"ITMO",
		"ITMO",
		"ITMO",
		"SPbSU",
		"ITMO" };
	int i;
	cin >> i;
	cout << v[i - 1995];

}

void b()
{
	int a, x, b, y,t;
	cin >> a >> x >> b >> y >> t;
	cout << 21 * x * (max(0, t - 30)) + a << ' ' << 21 * y * (max(0, t - 45)) + b;
}

void c()
{
	int n, i = 1;
	string s;
	cin >> n;
	while (true)
	{
		for (int i = 1; i < n; i++)
		{
			cout << i << ' ' << i + 1 << '\n';
			i++;
			cin >> s;
			if (s == "WIN") return;
		}

		for (int i = n; i > 0; i--)
		{
			cout << i - 1 << ' ' << i << '\n';
			cin >> s;
			if (s == "WIN") return;
		}
	}
}

void d()
{
	
}

void e()
{

}

void f()
{

}

void g()
{

}

void h()
{

}

void i()
{

}

void j()
{

}

void k()
{

}

void test()
{
	
}

int main()
{
	IOS

#ifdef ASDF
	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);
#endif

#ifdef TEST
	freopen("a.in", "w", stdout);

	test();
#else
	c();
#endif

	return 0;
}