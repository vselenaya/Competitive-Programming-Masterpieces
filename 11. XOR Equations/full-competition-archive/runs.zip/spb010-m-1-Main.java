package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static int a = -1;
    public static int b = -1;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt() + 1;
        long max = Long.MIN_VALUE;
        long min = Long.MAX_VALUE;
        long[] mas = new long[n];
        mas[0] = 0;
        for(int i = 1; i < n; i++){
            mas[i] = sc.nextLong();
        }
        Arrays.sort(mas);
        for(int i = 0; i < n-2; i++){
            max = Math.max(mas[i+1] - mas[i], max);
            min = Math.min(mas[i+2] - mas[i], min);
            if(min <= max){
                System.out.println(0);
                return;
            }
        }
        max = Math.max(mas[n-1] - mas[n-2], max);

        if(min <= max){
            System.out.println(0);
            return;
        }
        System.out.println(max);

    }
}