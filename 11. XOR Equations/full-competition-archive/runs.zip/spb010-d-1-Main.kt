import kotlin.math.ceil

fun main(args: Array<String>) {
    val firstLine = readLine()!!
        .split(" ")
        .map { it.toInt() }

    val n = firstLine[0]
    val w = firstLine[1]
    val h = firstLine[2]
    val s = firstLine[3]

    // символ к списку строк, его составляющих
    val maxPossibleSwitches = getMaxPossibleSwitches(w);
    val chars = readChars(n, h)
    val switchiestChar = getSwitchiestChar(chars, maxPossibleSwitches)
    val count = ceil(s.toDouble() / switchiestChar.second).toInt()

    print(switchiestChar.first.toString().repeat(count))
}

fun getMaxPossibleSwitches(w: Int) = 2 * ((1 + w) / 2)

fun getSwitchiestChar(chars: Map<Char, List<String>>, limit: Int): Pair<Char, Int> {
    var max = chars.keys.first() to 0

    for ((char, lines) in chars) {
        val switches = maxSwitches(lines, limit)
        if (switches == limit) {
            return char to switches
        }
        if (switches > max.second) {
            max = char to switches
        }
    }

    return max
}

fun maxSwitches(char: List<String>, limit: Int): Int =
    char.map { line ->
        val switches = countSwitches(line)
        if (switches == limit) return switches
        switches
    }
        .max()!!

fun countSwitches(line: String): Int {
    var count = 0
    ".$line.".reduce { acc, c ->
        if (acc != c) count++
        c
    }
    return count
}

fun readChars(n: Int, h: Int) = IntRange(1, n)
    .map { readChar(h) }
    .toMap()


fun readChar(h: Int) =
    readLine()!![0] to IntRange(1, h).map { readLine()!! }