#include <iostream>
#include <cmath>

int main(int, char *[]) {
  int n, w, h, s;
  std::cin >> n >> w >> h >> s;

  char symbol;
  int max = 0;
  char maxSymbol;
  for (int i = 0; i < n; ++i) {
    std::cin >> symbol;
    char c, l = '.';
    int switches = 0;

    for (int j = 0; j < h; ++j) {
      switches = 0;

      for (int g = 0; g < w; ++g) {
        std::cin >> c;
        if (c != l) {
          ++switches;
          l = c;
        }
      }

      if (l != '.') {
        ++switches;
      }

      if (switches > max) {
        max = switches;
        maxSymbol = symbol;
      }
    }
  }

  int count = std::ceil(s / max);
  for (int i = 0; i < count; ++i) {
    std::cout << maxSymbol;
  }

  return 0;
}
