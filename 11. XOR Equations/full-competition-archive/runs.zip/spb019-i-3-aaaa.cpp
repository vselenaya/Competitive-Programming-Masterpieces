﻿
#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    int s;
    bool was_broken = false;
    int x1, y1, x2, y2, x3, y3, x4, y4;
    cin >> s;
    int i = 0;
    int j = 0;
    for (int k = 0; k <= sqrt(s); k++) {
        for (int m = 0; m <= sqrt(s); m++) {
            if (k * k + m * m == s && k != m) { i = k; j = m; was_broken = true;
            break;
            }
        }
        if (was_broken)
            break;
    }
    x1 = i;
    y1 = j;
    x2 = x1 - i;
    y2 = y1 + j;
    x3 = x1 + j;
    y3 = y1 + i;
    x4 = x2 + j;
    y4 = y2 + i;
    if (i == 0 && j == 0) {
        cout << "Impossible";
    }
    else { cout << x1 << " " << y1 << '\n' << x2 << " " << y2 << '\n' << x3 << " " << y3 << '\n' << x4 << " " << y4; }
}
