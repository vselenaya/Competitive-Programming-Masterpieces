#include <iostream>
#include <vector>
#include <string>
#include <cmath>

int main() {
	int n, d = 0, max=0, j;
	int size,temp=0, tempTrue, stack = 0;
	std::cin >> size;
	std::vector<int> arr;
	std::vector<int> arr2;
	for (int i = 0; i < size; i++)
	{
		std::cin >> n;
		arr.push_back(n);
	}
	arr2 = arr;
	
	for (int i = 0; i < size; i++)
	{
		if (arr[i] > max)
			max = arr[i];
	}

	for (j = 0; j < max; j++) {
		tempTrue = temp;
		
		for (int i = 0; i < arr.size(); i++) {

			if ((arr[i] - stack) <= d)
			{
				stack = arr[i];
				temp++;
				arr.erase(arr.begin() + i);
				i--;
			}
		}

		if (temp == size)
			break;

		if (temp == tempTrue)
		{
			d++;
			temp = 0;
			arr = arr2;
			stack = 0;
		}
	}
	if (j == max)
		d = 0;

	std::cout << d;
}