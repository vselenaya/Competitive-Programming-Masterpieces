package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    int y = sc.nextInt();
    if(y == 1995 || y == 1998 || y == 1999 || (y <= 2005 && y >= 2001) || (y >=2009 && y<=2012) || (y <=2017 && y >= 2014) || y == 2019)
        System.out.println("ITMO");
    else if(y == 2006)
        System.out.println("PetrSU, ITMO");
    else if(y == 1996 || y == 1997 || y == 2000 || y == 2007 || y == 2008 || y == 2013 || y == 2018)
        System.out.println("SPbSU");
    }
}
