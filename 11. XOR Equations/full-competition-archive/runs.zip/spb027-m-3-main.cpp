#include "bits/stdc++.h"

using namespace std;

#define ll long long

int main() {
    ios::sync_with_stdio();
    cin.tie();
    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);
    int n;
    cin >> n;
    vector <ll> a(n + 1);
    a[0] = 0;
    for (int i = 1; i <= n; i ++) cin >> a[i];
    sort(a.begin(), a.end());
    ll dif1 = 0;
    ll dif2 = 1e9 + 7;
    for (int i = 0; i < n; i ++) {
        dif1 = max(dif1, a[i + 1] - a[i]);
        if (i != n - 1) {
            dif2 = min(dif2, a[i + 2] - a[i]);
        }
    }
    if (dif1 < dif2) {
        cout << dif1 << '\n';
    }
    else {
        cout << 0 << '\n';
    }
    return 0;
}