import math

inp_data = input().split(' ')

n = int(inp_data[0])
w = int(inp_data[1])
h = int(inp_data[2])
s = int(inp_data[3])


def calc_count(supchar):
    out_count = []
    for i in supchar:
        count = 0
        sust = False
        cur_sust = False
        for j in i:
            if j == '#':
                cur_sust = True
            else:
                cur_sust = False
            if sust != cur_sust:
                count += 1
                sust = cur_sust
        if cur_sust:
            count += 1
        out_count.append(count)
    return out_count


def max2(z):
    s = 0
    b = 0
    for x in range(len(z)):
        if z[x] > s:
            s = z[x]
            b = x
    return b


class SupChar:
    def __init__(self, char_code, supchar):
        self.char_code = char_code
        self.supchar = supchar
        tmp = calc_count(self.supchar)
        self.stats = max(tmp)
        self.istats = max2(tmp)


def comp(f):
    return f[0]

list_chars = []
stat_global = []

for i in range(n):
    char = input()
    supfont = []
    for j in range(h):
        supfont.append(input())
    list_chars.append(SupChar(char, supfont))


for i in list_chars:
    stat_global.append((i.stats, i.char_code))

our_max = max(stat_global, key=comp)

count_of_symb = math.ceil(s / our_max[0])
print(count_of_symb * our_max[1])
