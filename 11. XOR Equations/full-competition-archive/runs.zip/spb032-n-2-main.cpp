#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;

mt19937 rnd(time(0));
#define rall(x) (x).rbegin(), (x).rend()
#define all(x) (x).begin(), (x).end()
#define pNN pair <Node *, Node *>
#define SZ(x) (int)(x).size()
#define pii pair <int, int>
#define pb push_back
#define eb emplace_back
#define rev reverse
#define ins insert
#define ers erase
#define S second
#define F first
const int N = 51, INF = 1e9 + 10, M = 1e9 + 7;

ull c[N][N];

void calc() {
    for (int i = 0; i < N; ++i) {
        c[i][0] = 1;
    }
    for (int i = 0; i < N; ++i) {
        for (int j = 1; j < N; ++j) {
            if (j > i) {
                c[i][j] = 0;
                continue;
            }
            c[i][j] = c[i - 1][j - 1] + c[i - 1][j];
        }
    }
}

ull palindromes(int n, int k) {
    if (n % 2 == 0 && k % 2 == 1) {
        return 0;
    }
    return c[n / 2][k / 2];
}

void solve() {
    calc();
    int n, k;
    cin >> n >> k;
    ull ans = 0;
    for (int i = 0; i <= min(n, k); ++i) {
        ull delta = 0;
        if (i + n >= k) {
            if (k % 2 == 0 && i == k / 2) {
                delta = c[n][i] + palindromes(n, i);
            } else {
                delta = c[n][i] - (c[n][i] - palindromes(n, i)) / (ull)2; 
            }
        }
        ans += delta;
    }
    cout << ans;

}

signed main () {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cout.precision(12);
    #ifdef fleek$
        assert(freopen("input.txt", "r", stdin));
    #endif
    int t = 1;
    //cin >> t;
    while(t--) solve();
    return 0;
}