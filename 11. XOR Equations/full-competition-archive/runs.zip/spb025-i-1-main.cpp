#include <bits/stdc++.h>

using namespace std;

int main()
{
  ios_base::sync_with_stdio(0);
  cin.tie(0), cout.tie(0);

  int s, a, b;
  cin >> s;

  if (sqrt(s)*sqrt(s) == s){
    cout << "0 0" << endl << "0 " << sqrt(s) << endl << sqrt(s) << " " << sqrt(s) << endl << sqrt(s) << " 0";
    return 0;
  }
  else{
    for (int i = 1; i*i <= s; i++)
      for (int j = i; j*j <= s; j++)
        if (i*i + j*j == s){
          cout << "0 0" << endl << i << " " << j << endl << i + j << " " << j - i << endl << j << " " << -i;
          return 0;
        }
  }

  cout << "Impossible";
  return 0;
}
