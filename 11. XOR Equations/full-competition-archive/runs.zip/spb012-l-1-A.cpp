#include <algorithm>
#include <bitset>
#include <cstdlib>
#include <iostream>
#include <random>
#include <set>
#include <vector>

// #define FAST_ALLOCATOR_MEMORY 256000000
// #include "optimization.h"
#include <bits/stdc++.h>

using namespace std;

// #define USE_INT128
// #define int int64_t

// #undef _DEBUG

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()

#ifdef USE_INT128
#define lint __int128
#define ulint __int128
#else
#define lint int64_t
#define ulint int64_t
#endif

typedef long double ld;
#define f first
#define s second
typedef pair<int, int> pint;

const int inf = 1 << 30;

template <class T>
T mineq(T& a, const T& b) {
    return a = min(a, b);
}

template <class T>
T maxeq(T& a, const T& b) {
    return a = max(a, b);
}

mt19937 rd(533);
// end of default file

vector<int> mult(vector<int> p1, vector<int> p2) {
    vector<int> ans(p1.size());
    for (int i = 0; i < ans.size(); i++) {
        ans[i] = p1[p2[i]];
    }
    return ans;
}

vector<int> inv(vector<int> p) {
    vector<int> ans(p.size());
    for (int i = 0; i < p.size(); i++)
        ans[p[i]] = i;
    return ans;
}

vector<int> id(int n) {
    vector<int> res(n);
    for (int i = 0; i < n; i++)
        res[i] = i;
    return res;
}

// const int N = 5;
// const vector<int> F = { 3, 0, 4, 2, 1 };

// vector<int> make_ask(vector<int> a) {
//     cout << "? ";
//     for (auto& i : a) cout << i + 1 << ' ';
//     cout << endl;

//     return mult(inv(F), mult(a, F));
// }

vector<int> make_ask(vector<int> a) {
    cout << "? ";
    for (auto& i : a) cout << i + 1 << ' ';
    cout << endl;

    vector<int> ans(a.size());
    for (auto& i : ans) {
        cin >> i;
        i--;
    }
    return ans;
}

void make_ans(vector<int> a) {
    cout << "! ";
    for (auto& i : a) cout << i + 1 << ' ';
    cout << endl;
}

void solve() {
    int n;
    cin >> n;

    vector<int> ask_c(n);
    for (int i = 0; i + 1 < n; i++)
        ask_c[i] = i + 1;
    ask_c[n - 1] = 0;
    ask_c = make_ask(ask_c);
    vector<int> ask_s = id(n);
    swap(ask_s[0], ask_s[1]);
    ask_s = make_ask(ask_s);

    vector<vector<int>> affected_ci(n);

    vector<int> ask_ci = id(n);

    for (int i = 0; i < n; i++) {
        vector<int> ask_csc = mult(ask_ci, mult(ask_s, inv(ask_ci)));

        for (int j = 0; j < n; j++) {
            if (ask_csc[j] != j)
                affected_ci[i].push_back(j);
        }

        ask_ci = mult(ask_ci, ask_c);
    }

    vector<int> f_inv(n);
    for (int i = 0; i < n; i++) {
        int j = i + 1;
        if (j == n)
            j = 0;

        for (auto k : affected_ci[i]) {
            if (find(all(affected_ci[j]), k) != affected_ci[j].end()) {
                f_inv[j] = k;
            }
        }
    }

    auto f = inv(f_inv);
    make_ans(f);
}

int32_t main() {
    // srand(5332017);
    ios::sync_with_stdio(false);
    cin.tie();
    cout.tie();
    cout << fixed;
    cout.precision(4); // !!

#ifdef _DEBUG
    // // init();
    freopen("input.txt", "r", stdin);
    // int seed;
    // cin >> seed;
    // rd = mt19937(seed);
    // // freopen("output.txt", "w", stdout);
#else
    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
#endif

    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
        solve();


    return 0;
}
