n=int(input())
s=input().split()
err=0
ms=[0 for i in range(n)]
for i in range(n):
    ms[i]=int(s[i])
mss=sorted(ms)
maxx=0 
for i in range(n-1):
    if mss[i+1]-mss[i]>maxx:
        maxx=mss[i+1]-mss[i]
if mss[0]>maxx:
    maxx=mss[0]
for i in range(2,n):
    if maxx<mss[i]-mss[i-2]:
        continue
    else:
        err=1
        break
if maxx>=mss[1]:
    err=1
if err==0:
    print(maxx)
else:
    print("0")
