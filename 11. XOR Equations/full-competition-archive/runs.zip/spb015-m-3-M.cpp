#include <iostream>

using namespace std;

int main() {
	int count = 0;
	int *arr;
	
	cin >> count;
	arr = new int[count];
	
	for (int i = 0; i < count; i++)
	{
		cin >> arr[i];
	}

	int temp = 0;
	
	for (int i = 0; i < count - 1; i++) {
		for (int j = 0; j < count - i - 1; j++) {
			if (arr[j] > arr[j + 1]) {
				temp = arr[j];
				arr[j] = arr[j + 1];
				arr[j + 1] = temp;
			}
		}
	}


	int maxDif = 0;
	for (int i = 1; i < count; i++)
	{
		if (maxDif < arr[i] - arr[i - 1])
		{
			maxDif = arr[i] - arr[i - 1];
		}
	}

	for (int i = 0; i < count - 2; i++)
	{
		if (i == 0)
		{
			if (maxDif >= arr[1])
			{
				maxDif = 0;
				break;
			}
		}
		else
		{
			if (arr[i] + maxDif >= arr[i + 2])
			{
				maxDif = 0;
				break;
			}
		}
	}
	
	cout << maxDif;
}