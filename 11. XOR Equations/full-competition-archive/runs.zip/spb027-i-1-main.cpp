#include "bits/stdc++.h"

using namespace std;

#define ll long long

int main() {
    ios::sync_with_stdio();
    cin.tie();
    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);
    ll s, x, y;
    cin >> s;
    x = y = -100;
    for (int i = 0; i <= sqrt(s) + 3; i ++) {
        for (int j = 0; j <= sqrt(s) + 3; j ++) {
            if (i * i + j * j == s) {
                x = i;
                y = j;
            }
        }
    }
    if (x == -100) {
        cout << "Impossible" << '\n';
    }
    else {
        cout << x << ' ' << 0 << '\n';
        cout << 0 << ' ' << y << '\n';
        cout << y << ' ' << x + y << '\n';
        cout << x + y << ' ' << x << '\n';
    }
    return 0;
}