﻿#include <map>
#include <iostream>
#include <cassert>

using namespace std;
int main()
{

  int a, x, b, y, T;
  int tmp = 0, days = 21, res = 0;
  cin >> a >> x >> b >> y >> T;
  tmp = T - 30;
  cout << tmp * 21 * x + a << " ";
  tmp = T - 45;
  cout << tmp * 21 * y + b;
  return 0;

}