#include "bits/stdc++.h"

using namespace std;

#define ll long long

int main() {
    ios::sync_with_stdio();
    cin.tie();
    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);
    int n;
    cin >> n;
    string ans;
    int cnt = 0;
    for (int i = 2; i <= n; i ++) {
        cout << 1 << ' ' << i << endl;
        cin >> ans;
        if (ans == "WIN") {
            return 0;
        }
    }
    for (int i = 3; i <= n; i++) {
        cout << 2 << ' ' << i << endl;
        cin >> ans;
        if (ans == "WIN") {
            return 0;
        }
    }
    for (int i = 0; i < 3; i ++) {
        cout << 1 << ' ' << 2 << endl;
        cin >> ans;
        if (ans == "WIN") {
            return 0;
        }
    }
    int k = 2;
    int bad_elem;
    while (true) {
        bad_elem = -1;
        cnt = 0;
        for (int i = 1; i < k; i++) {
            cout << i << ' ' << i + 1 << endl;
            cnt++;
            cin >> ans;
            if (ans == "WIN") {
                return 0;
            }
            if (ans == "SWAPPED") {
                bad_elem = i + 1;
                break;
            }
        }
        if (bad_elem != -1 || bad_elem == k) {
            for (int i = k + 1; i <= n; i ++) {
                cout << bad_elem << ' ' << i << endl;
                cnt++;
                cin >> ans;
                if (ans == "WIN") {
                    return 0;
                }
            }
            for (int i = k; i >= bad_elem + 1; i --) {
                cout << bad_elem << ' ' << i << endl;
                cnt ++;
                cin >> ans;
                if (ans == "WIN") {
                    return 0;
                }
            }
            cout << bad_elem - 1 << ' ' << bad_elem << endl;
            cnt ++;
            cin >> ans;
            if (ans == "WIN") {
                return 0;
            }
        }
        else { //bad_elem == -1
            for (int i = k + 1; i <= n; i++) {
                cout << k << ' ' << i << endl;
                cnt++;
                cin >> ans;
                if (ans == "WIN") {
                    return 0;
                }
            }
        }
        for (int i = k + 2; i <= n; i ++) {
            cout << k + 1 << ' ' << i << endl;
            cnt++;
            cin >> ans;
            if (ans == "WIN") {
                return 0;
            }
        }
        while (cnt < 2 * n) {
            cnt++;
            cout << 1 << ' ' << 2 << endl;
            cin >> ans;
            if (ans == "WIN") {
                return 0;
            }
        }
        k++;
    }
    return 0;
}