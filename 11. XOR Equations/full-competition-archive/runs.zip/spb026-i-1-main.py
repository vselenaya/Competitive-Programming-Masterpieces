#
import math

if __name__ == '__main__':
    sq=list()
    for i in range(1, 1000):
        sq.append(i*i)
    # print (sq)
    s=int(input())
    flag=0
    for a in range(s):
        if (a in sq and flag==0):
            for b in range(s):
                if   (a*a+b*b)==s:
                    print (0,a)
                    print (b,0)
                    print (a+b,b )
                    print(a,a+b)
                    flag=1
                    break
        if (flag==1):
            break
    if (flag==0):
        print("Impossible")
