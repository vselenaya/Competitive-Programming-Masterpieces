import math
s = int(input())
x1 = x2 = y1 = y2 = 0
if (math.ceil(math.sqrt(s)) == math.sqrt(s)):
    print("\n 0\t0\n", math.sqrt(s),"\t0\n","0\t",math.sqrt(s),"\n",math.sqrt(s),"\t",math.sqrt(s))
else:
    for i in range(math.ceil(math.sqrt(s))):
        sideBigger = math.ceil(math.sqrt(s))
        if (math.sqrt(math.pow(sideBigger-1,2)+math.pow(i,2)) == math.sqrt(s)):
            y2 = i
            x2 = math.ceil(math.sqrt(s)) - 1
            break
if (x2 == 0):
    print("Impossible")
else:
    x3 = x2 - y2
    y3 = y2 + x2
    y4 = x2
    x4 = -y2
    print(x1,"\t",y1,"\n",x2,"\t",y2,"\n",x3,"\t",y3,"\n",x4,"\t",y4)