#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
typedef long double ld;

#define pb push_back
#define forn(i, n) for (int i = 0; i < (int)(n); i++)
#define forrn(i, s, n) for (int i = (int)(s); i < (int)(n); i++)
#define PYMOD(a, m) ((((a) % (m)) + (m)) % (m))
#define all(v) v.begin(), v.end()
#define rall(v) v.rbegin(), v.rend()
#define mp make_pair
#define ff first
#define ss second

const int maxn = 3179;
ld c[maxn];

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    // Code here:

    int d;
    ld p;
    cin >> d >> p;
    forn(i, d) {
        cin >> c[i];
    }

    int pos_ans = 0, neg_ans = 0;
    forn(i, d) {
        ld sum = 0, sum_sq = 0;
        forrn(j, i + 1, d) {
            ld cc = c[j] - c[j - 1];
            sum += cc;
            sum_sq += cc * cc;
            if (j - i + 1 < 3)
                continue;
            ld A = sum / (j - i);
            ld D = sqrt(sum_sq / (j - i) - A * A);
            if (sum_sq * (j - i) == sum * sum) {
                if (A > 0) {
                    pos_ans++;
                }
                if (A < 0) {
                    neg_ans++;
                }
            } else {
                if (A >= p * D) {
                    pos_ans++;
                }
                if (A <= -p * D)
                    neg_ans++;
            }
        }
    }

    cout << pos_ans << " " << neg_ans << endl;

    return 0;
}
