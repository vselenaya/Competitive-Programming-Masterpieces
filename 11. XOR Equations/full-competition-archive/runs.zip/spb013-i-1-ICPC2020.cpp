﻿// ICPC2020.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <cmath>
#include <iostream>


using namespace std;
int main()
{
	double s;
	cin >> s;
	s = sqrt(s);
	if (fmod(s,1) == 0) {
		cout << 0 + s << " " << 0 << endl;
		cout << 0 << " " << 0 << endl;
		cout << 0 << " " << 0 + s << endl;
		cout << s << " " << s;
		return 0;
	}
	else{
		
		for (int i = 1; i < 32; i++) {
			for (int j = 31; j > 0; j--) {
				if (static_cast<double>(i * i + j * j) == round(pow(s,2))) {
						cout << j << " " << 0 << endl;
						cout << 0 << " " << i << endl;
						cout << 2*j << " " << i << endl;
						cout << 2*i << " " << j;
						return 0;
				}
			}
		}
	}
	cout << "Impossible";
	return 0;

}