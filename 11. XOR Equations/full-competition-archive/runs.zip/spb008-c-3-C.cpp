#include <iostream>
#include <string>

int main()
{
    int n;
    std ::cin >> n;
    std::string text = "";
    int last = n;
    bool f = true;
    int pos = 1;
    while (text != "WIN")
    {
        if (f || pos >= n)
        {
            std::cout << last - 1 << " " << last << std::endl;
            if (last - 1 == 1)
            {
                f = !f;
                pos++;
            }
            last = (last - 1 == 1) ? (n) : (last - 1);
            std::cin >> text;
        }
        else
        {
            std::cout << last - 1 << " " << last << std::endl;
            if (last - 1 == pos)
                f = !f;
            last = (last - 1 == pos) ? (n) : (last - 1);
            std::cin >> text;
        }
    }
}