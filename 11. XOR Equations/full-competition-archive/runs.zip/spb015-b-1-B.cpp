#include <iostream>
using namespace std;

class BikeRentalOption {
public:
	int monthFee;
	int costOfMinutesAbove;

	unsigned long Calculate(const int TMinutesPerDay, const int daysNum, int minutesWithoutAdditionalFee) {
		unsigned long sum = monthFee;
		if (TMinutesPerDay > minutesWithoutAdditionalFee)
			sum += costOfMinutesAbove * (TMinutesPerDay - minutesWithoutAdditionalFee) * daysNum;

		return sum;
	}
};

int main() {
	BikeRentalOption firstOption;
	BikeRentalOption secondOption;

	cin >> firstOption.monthFee;
	cin >> firstOption.costOfMinutesAbove;
	cin >> secondOption.monthFee;
	cin >> secondOption.costOfMinutesAbove;

	int TMinutesPerDay;
	cin >> TMinutesPerDay;

	cout << firstOption.Calculate(TMinutesPerDay, 21, 30) << " " << secondOption.Calculate(TMinutesPerDay, 21, 45);
}