#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

int main()
{
    int n;
    cin >> n;
    vector<int> data(n + 1);
    data[0] = 0;
    for (int i = 0;i < n;i++)
    {
        cin >> data[i + 1];
    }
    
    sort(data.begin(), data.end());
    
    
    int d = 0;
    vector<int> data_diff(data.size() - 1);
    for (int i = 1; i < data.size();i++)
    {
        data_diff[i - 1] = data[i] - data[i - 1];
        d = max(d, data_diff[i - 1]);
    }
    for (int i = 1;i < data_diff.size();i++)
    {
        if (data_diff[i - 1] + data_diff[i] <= d)
        {
            std::cout << 0;
            return 0;
        }
    }

    std::cout << d;
}