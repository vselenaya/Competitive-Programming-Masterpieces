a = int(input())
x = int(input())
b = int(input())
y = int(input())
T = int(input())

print(a + 21 * (T - 30) * x, b + 21 * (T - 45)* y) 
