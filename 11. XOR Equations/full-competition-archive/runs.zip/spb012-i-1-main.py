

if __name__ == '__main__':
    s = int(input())
    for a in range(50):
        for b in range(50):
            if a ** 2 + b ** 2 == s:
                print('0 0')
                print(f'{a} {b}')
                print(f'{b} {-a}')
                print(f'{a + b} {b- a}')
                exit(0)

    print('Impossible')
