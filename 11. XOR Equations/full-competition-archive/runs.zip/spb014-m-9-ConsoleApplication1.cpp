﻿#include <iostream>
#include <cassert>

using namespace std;

int main()
{
    long long count;
    cin >> count;
    long long* array = new long long[count];
    long long* old_array = new long long[count];

    for (long long i = 0; i < count; i++) {
        cin >> array[i];
        old_array[i] = array[i];
    }

    long long temp, current = 0;

    for (long long i = 0; i < count - 1; ++i)
    {
        for (long long j = 0; j < count - 1; ++j)
        {
            if (array[j + 1] < array[j])
            {
                temp = array[j + 1];
                array[j + 1] = array[j];
                array[j] = temp;
            }
        }
    }

    long long tempgap, gap = 0;

    for (long long i = 0; i < count - 1; i++) {
        tempgap = array[i + 1] - array[i];
        if (tempgap > gap)
            gap = tempgap;
    }

    long long min = gap;

    if (gap <= array[0])
        gap = array[0];

    int twice = 0;
    for (size_t i = 0; i < count; i++)
    {
        if (old_array[i] < gap && twice < 2) {
            min = old_array[i];
            twice++;
        }
        else if (twice >= 2) {
            cout << 0;            
            return 0;
        }
    }

    cout << gap;
    return 0;
}