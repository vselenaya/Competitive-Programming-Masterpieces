#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> pii;
typedef pair<long long, long long> pll;
typedef long long ll;
typedef unsigned int ui;
typedef unsigned long long ull;
typedef long double ld;

const int inf = 1e9;
const ll inf64 = 1e18;

int main() {

#ifdef DEBUG
    freopen("input.txt", "r", stdin);
#endif

    ios_base::sync_with_stdio(0);
    cin.tie(0);

    int n;
    cin >> n;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++)
        cin >> a[i];

    sort(a.begin(), a.end());

    int l = 1, r = inf + 10;

    for (int i = 1; i < n; i++) {
        int x0 = a[i - 1];
        int x1 = a[i];
        int x2 = a[i + 1];
        r = min(r, x2 - 1 - x0);
        l = max(l, x1 - x0);
    }

    l = max(l, a[n] - a[n - 1]);

    if (l <= r)
        cout << l << "\n";
    else
        cout << 0 << "\n";

    return 0;
}
