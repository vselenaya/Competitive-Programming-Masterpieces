#include <bits/stdc++.h>

using namespace std;

#ifdef DEBUG
ifstream in("input");
#define cin in
#else
#define endl '\n'
#endif

#define EPS 0.000000001

void fast_io() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  cout.setf(ios::fixed);
  cout.precision(20);
}

int year;
vector<string> v = {
    "ITMO", "SPbSU", "SPbSU", "ITMO", "ITMO",         "SPbSU", "ITMO",
    "ITMO", "ITMO",  "ITMO",  "ITMO", "PetrSU, ITMO", "SPbSU", "SPbSU",
    "ITMO", "ITMO",  "ITMO",  "ITMO", "SPbSU",        "ITMO",  "ITMO",
    "ITMO", "ITMO",  "SPbSU", "ITMO",
};

void solve() {
  // amin'
  cin >> year;
  cout << v[year - 1995] << endl;
}

int main() {
  fast_io();
  solve();
  return 0;
}