#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <queue>
#include <deque>
#include <stack>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <cassert>
#include <cstddef>
#include <cstring>
#include <bitset>
#include <random>
#include <memory>
#include <iomanip>

typedef long long ll;
typedef long double ld;

using namespace std;

int p, n, m, s, t;
const int MX = 26;
vector<pair<int, int>> gram[MX];
vector<int> term[MX];
vector<pair<int, int>> g[MX];
int matr[MX][MX];

void read() {
    for (int i = 0; i < MX; i++) {
        for (int j = 0; j < MX; j++) {
            matr[i][j] = -1;
        }
    }

    cin >> p;
    string str;
    getline(cin, str);
    for (int i = 0; i < p; i++) {
        getline(cin, str);
        if (str.length() == 6) {
            term[str[0] - 'A'].push_back(str[5] - 'a');
        } else {
            gram[str[0] - 'A'].push_back({str[5] - 'A', str[6] - 'A'});
        }
    }
    cin >> n >> m >> s >> t;
    s--, t--;
    for (int i = 0; i < m; i++) {
        int a, b;
        char c;
        cin >> a >> b >> c;
        a--, b--;
        g[a].push_back({b, c - 'a'});
        matr[a][b] = c - 'a';
    }

}


ll INF = 1e18 + 7;
ll d[MX][MX][MX];
bool used[MX][MX][MX];

struct vert {
    int a, b, l;

    bool operator <(const vert& o) const {
        if (a != o.a) return a < o.a;
        if (b != o.b) return b < o.b;
        return l < o.l;
    }
};

ll get_d(const vert& q) {
    return d[q.a][q.b][q.l];
}

void solve() {
    for (int i = 0; i < MX; i++) {
        for (int j = 0; j < MX; j++) {
            for (int k = 0; k < MX; k++)  {
                d[i][j][k] = INF;
            }
        }
    }

    priority_queue<pair<ll, vert>> q;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < MX; k++) {
                for (char c : term[k]) {
                    if (matr[i][j] == c) {
                        d[i][j][k] = 1;
                        q.push({-d[i][j][k], {i, j, k}});
                    }
                }
            }
        }
    }


    while (!q.empty()) {
        pair<ll, vert> v = q.top();
        q.pop();

        if (-v.first != get_d(v.second)) continue;

        for (int tp = 0; tp < MX; tp++) {
            for (const pair<int, int>& t: gram[tp]) {
                if (t.first == v.second.l) {
                    for (int to = 0; to < n; to++) {
                        if (ll dist = d[v.second.a][v.second.b][t.first] + d[v.second.b][to][t.second]; dist < d[v.second.a][to][tp]) {
                            d[v.second.a][to][tp] = dist;
                            q.push({-dist, {v.second.a, to, tp}});
                        }
                    }
                }
                if (t.second == v.second.l) {
                    for (int to = 0; to < n; to++) {
                        if (ll dist = d[to][v.second.a][t.first] + d[v.second.a][v.second.b][t.second]; dist < d[to][v.second.b][tp]) {
                            d[to][v.second.b][tp] = dist;
                            q.push({-dist, {to, v.second.b, tp}});
                        }
                    }
                }
            }
        }

    }

    if (d[s][t]['S' - 'A'] == INF) {
        cout << "NO\n";
    } else {
        cout << d[s][t]['S' - 'A'] << '\n';
    }

}

int main() {

#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    ios_base::sync_with_stdio(0);


    read();
    solve();

    return 0;
}
