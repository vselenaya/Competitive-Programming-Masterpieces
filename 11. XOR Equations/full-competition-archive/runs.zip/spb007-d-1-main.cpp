#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

char c[100];
string a[100][30];
ll mx[30];

int main()
{
    ll n, w, h, s;
    cin >> n >> w >> h >> s;

    for (int i = 0; i < n; ++i) {
        cin >> c[i];
        for (int y = 0; y < h; ++y) {
            cin >> a[i][y];
        }
    }
    ll ai = 0, ay = 1, mx = 0;
    for (int i = 0; i < n; ++i) {
        for (int y = 0; y < h; ++y) {
            ll sum = 0;
            if(a[i][y][0] == '#') {
                sum++;
            }
            for (int x = 1; x < w; ++x) {
                if(a[i][y][x] != a[i][y][x-1]) {
                    sum++;
                }
            }
            if(a[i][y][w-1] == '#') {
                sum++;
            }
            if(sum > mx) {
                mx = sum;
                ai = i;
                ay = y;
            }
        }


    }
    ll as = s;
    while(as > 0) {
        cout << c[ai];
        as -= mx;
    }
    cout << endl;

    return 0;
}
