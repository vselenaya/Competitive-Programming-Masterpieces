#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <stack>
#include <queue>
#include <algorithm>
#include <cmath>

using namespace std;

int main()
{
    map<int, pair<int, int>> m;
    for (int i = 1; i < 25; ++i) {
        for (int j = 1; j < 25; ++j) {
            m[i * i + j * j] = {i, j};
        }
    }

    int s;
    cin >> s;


    auto f = m.find(s);
    if (f != m.end())
    {
        int x = f->second.first, y = f->second.second;
        cout << 0 << ' ' << 0 << endl;
        cout << x << ' ' << y << endl;
        cout << x - y << ' ' << y + x << endl;
        cout << -y << ' ' << x << endl;
    }
    else
    {
        cout << "Impossible" << endl;
    }

    return 0;
}

/*
int main1() {
    int n;
    cin >> n;
    cin.get();

    int c = 0;
    string s;


    for (int k = 0; k < n; ++k) {

        for (int j = 0; j < n - k - 1; ++j) {
            cout << j + 1 << ' ' << j + 2;
            getline(cin, s);

            if (s == "WIN")
                return 0;
        }

        for (int i = 0; i < n - k + 1; ++i) {
            cout << 1 << ' ' << 2;
            getline(cin, s);
        }

        for (int i = n - 1; i >= n - (c + 1); --i) {
            cout << 1 << ' ' << i + 1;
            getline(cin, s);
            if (s != "STAYED") {
                c = i;
                break;
            }
        }


    }
    return 0;
}
*/