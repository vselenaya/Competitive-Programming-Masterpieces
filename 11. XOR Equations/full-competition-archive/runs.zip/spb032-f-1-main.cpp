#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;

mt19937 rnd(time(0));
#define rall(x) (x).rbegin(), (x).rend()
#define all(x) (x).begin(), (x).end()
#define pNN pair <Node *, Node *>
#define SZ(x) (int)(x).size()
#define pii pair <int, int>
#define pb push_back
#define eb emplace_back
#define rev reverse
#define ins insert
#define ers erase
#define S second
#define F first
#define int ll
const int N = 3100, INF = 1e9 + 10, M = 1e9 + 7;

ld EPS = 1e-9;

int c[N];
int x[N];
ld P;
int ans[2];


void check(ld A, ld D) {
    if (fabs(A) < EPS) {
        return;
    }
    if (fabs(D) < EPS) {
        if (A < 0.0) {
            ++ans[1];
        } else {
            ++ans[0];
        }
        return;
    } 
    if (A / D >= P) {
        ++ans[0];
    }
    if (A / D <= -P) {
        ++ans[1];
    }
}

void calc(int l, int r) {
    ld A = 0.0;
    for (int i = l; i <= r; ++i) {
        A += x[i];
    }
    A /= (r - l + 1);
    ld D = 0.0;
    for (int i = l; i <= r; ++i) {
        D += ((ld)x[i] - A) * ((ld)x[i] - A);
    }
    D /= (ld)(r - l + 1);
    D = sqrtl(D);
    check(A, D);
}


void solve() {
    int n;
    cin >> n >> P;
    for (int i = 0; i < n; ++i) {
        cin >> c[i];
    }
    for (int i = 0; i < n - 1; ++i) {
        x[i] = c[i + 1] - c[i];
    }
    --n;

    for (int i = 0; i < n; ++i) {
        int sum = x[i];
        int sum_sq = x[i] * x[i];
        for (int j = i + 1; j < n; ++j) {
            sum += x[j];
            sum_sq += x[j] * x[j];
            int cnt = j - i + 1;
            ld A = (ld)sum / (ld)(cnt);
            ld D = (ld)(sum_sq) - 2.0 * A * (ld)(sum) + A * A * (ld)(j - i + 1);
            D /= (ld)(cnt);
            D = sqrtl(D);
            check(A, D);
        }
    }
    /*for (int i = 0; i < n; ++i) {
        for (int j = i + 1; j < n; ++j) {
            calc(i, j);
        }
    }*/
    cout << ans[0] << " " << ans[1] << endl; 
}  

signed main () {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cout.precision(12);
    #ifdef fleek$
        assert(freopen("input.txt", "r", stdin));
    #endif
    int t = 1;
    //cin >> t;
    while(t--) solve();
    return 0;
}